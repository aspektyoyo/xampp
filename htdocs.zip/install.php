<?php

use ASweb\RRO\Client\Client;
use Model\Apteka;
use Model\Document;
use Model\OfflineNumber;
use Model\Rro;
use Model\Shift;
use Model\User;

require ('app/init/path.php');
require ('env.php');
require ('init/autoload.php');
require ('init/system-scripts.php');
require ("init/debug.php");

set_time_limit(0);

function createDB() {
    $ok = 0;
    $servername = Env::db_server();
    $username = Env::db_login();
    $password = Env::db_pass();
    
    // Create connection
    $conn = new mysqli($servername, $username, $password);
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    if($_POST['reinstall'] == 1) {
      $sql = "DROP DATABASE rro";
      $status = $conn->query($sql);
    }  
    try {
      // Create database
      $sql = "CREATE DATABASE rro CHARACTER SET utf8 COLLATE utf8_general_ci";
      $status = $conn->query($sql);
      if ($status !== TRUE) {
        if ($conn->errno == 1007) {
          // DB exists
          $error = 2;
          if($_POST['reinstall'] != 1) {
            return $error;
          }
        } else {
          // Другая ошибка
          return -1;
        }
      }
    } catch (Exception $e) {
      return 2;
    }
    
    
    $conn->query("USE rro");
    // Create tables

    $apteka_table = "CREATE TABLE `apteka` (
      `id` int NOT NULL,
      `user` int(11) NOT NULL DEFAULT 0,
      `number` int NOT NULL DEFAULT '0',
      `name` varchar(255) NOT NULL DEFAULT '',
      `address` varchar(255) NOT NULL DEFAULT '',
      `comment` varchar(1000) NOT NULL DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

    $doc_table = "CREATE TABLE `document` (
      `id` int(11) NOT NULL,
      `rro` int(11) NOT NULL DEFAULT 0,
      `user` int(11) NOT NULL DEFAULT 0,
      `shift` int(11) NOT NULL DEFAULT 0,
      `action_type` varchar(50) NOT NULL DEFAULT '',
      `local_number` int(11) NOT NULL DEFAULT 0,
      `local_local_number` INT NOT NULL DEFAULT '0',
      `fiscal_number` varchar(255) NOT NULL DEFAULT '',
      `name` varchar(255) NOT NULL DEFAULT '',
      `tstamp` int(11) NOT NULL DEFAULT 0,
      `time_string` varchar(255) NOT NULL DEFAULT '',
      `signed` int(11) NOT NULL DEFAULT 0,
      `sent` int(11) NOT NULL DEFAULT 0,
      `sync` int(11) NOT NULL DEFAULT 0,
      `last` int(11) NOT NULL DEFAULT 0,
      `received` int(11) NOT NULL DEFAULT 0,
      `xml` text NOT NULL,
      `request` longtext DEFAULT NULL,
      `response` longtext NOT NULL,
      `prev_hash` VARCHAR(255) NOT NULL DEFAULT '',
      `hash` varchar(255) NOT NULL DEFAULT '',
      `is_offline` tinyint(1) NOT NULL DEFAULT 0,
      `no_internet` int(11) NOT NULL DEFAULT 0,
      `url` varchar(255) NOT NULL DEFAULT '',
      `customer_email` varchar(255) NOT NULL DEFAULT '',
      `customer_phone` varchar(255) NOT NULL DEFAULT '',
      `customer_sent` int(11) NOT NULL DEFAULT 0,
      `md5` varchar(255) NOT NULL DEFAULT '',
      `error` int(11) NOT NULL DEFAULT 0,
      `is_deleted` int(11) NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

    $offline_table = "CREATE TABLE `offline_id` (
      `id` int(11) NOT NULL,
      `rro` int(11) NOT NULL DEFAULT 0,
      `offline_session` int(11) NOT NULL DEFAULT 0,
      `fn` varchar(255) NOT NULL DEFAULT '',
      `used` tinyint(4) NOT NULL DEFAULT 0,
      `use_tstamp` int(11) NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

    $rro_table = "CREATE TABLE `rro` (
      `id` int NOT NULL,
      `user` int(11) NOT NULL DEFAULT 0,
      `token` varchar(255) NOT NULL DEFAULT '',
      `org` int NOT NULL DEFAULT '0',
      `apteka` int NOT NULL DEFAULT '0',
      `org_name` varchar(255) NOT NULL DEFAULT '',
      `address` varchar(255) NOT NULL DEFAULT '',
      `name` varchar(255) NOT NULL DEFAULT '',
      `tin` varchar(255) NOT NULL DEFAULT '',
      `ipn` varchar(255) NOT NULL DEFAULT '',
      `di` varchar(255) NOT NULL DEFAULT '',
      `num_fiscal` varchar(255) NOT NULL DEFAULT '',
      `shift` int NOT NULL DEFAULT '0',
      `shift_opened` int NOT NULL DEFAULT '0',
      `advertising` int NOT NULL DEFAULT '0',
      `offline` int NOT NULL DEFAULT '0',
      `no_internet` int NOT NULL DEFAULT '0',
      `blocked` tinyint(1) NOT NULL DEFAULT '0',
      `error` int NOT NULL DEFAULT '0',
      `last_online` int NOT NULL DEFAULT '0',
      `last_online_level` int NOT NULL DEFAULT '0',
      `bussy` int NOT NULL DEFAULT '0',
      `timer36` int NOT NULL DEFAULT '0',
      `timer168` int NOT NULL DEFAULT '0',
      `timer_updated` int NOT NULL DEFAULT '0',
      `timer168_nulled` int NOT NULL DEFAULT '0',
      `timer_duplicate` INT NOT NULL DEFAULT '0',
      `mac` varchar(255) NOT NULL DEFAULT '',
      `prev_mac` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '',
      `to_offline_sent` int NOT NULL DEFAULT '0',
      `hybrid` int NOT NULL DEFAULT '0'
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;";

    $shift_table = "CREATE TABLE `shift` (
      `id` int(11) NOT NULL,
      `rro` int(11) NOT NULL DEFAULT 0,
      `shift_number` int(11) NOT NULL DEFAULT 0,
      `name` varchar(255) NOT NULL DEFAULT '',
      `state` int(11) NOT NULL DEFAULT 0,
      `opened` int(11) NOT NULL DEFAULT 0,
      `open_tstamp` int(11) NOT NULL DEFAULT 0,
      `close_tstamp` int(11) NOT NULL DEFAULT 0,
      `offline_tstamp` int(11) NOT NULL DEFAULT 0,
      `offline` int(11) NOT NULL DEFAULT 0,
      `offline_timeline` varchar(255) NOT NULL DEFAULT '',
      `totals` varchar(255) NOT NULL DEFAULT '',
      `cashier` int(11) NOT NULL DEFAULT 0,
      `balance_open` double NOT NULL DEFAULT 0,
      `balance_close` double NOT NULL DEFAULT 0,
      `last` tinyint(1) NOT NULL DEFAULT 0,
      `sync` int(11) NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

  $user_table = "CREATE TABLE `user` (
    `id` int(11) NOT NULL,
    `user` int(11) NOT NULL DEFAULT 0,
    `rro` int(11) NOT NULL DEFAULT 0,
    `token` varchar(255) NOT NULL DEFAULT '',
    `sign_token` varchar(255) NOT NULL DEFAULT '',
    `full_name` varchar(255) NOT NULL DEFAULT '',
    `uuid` varchar(255) NOT NULL DEFAULT '',
    `inn` varchar(255) NOT NULL DEFAULT '',
    `email` varchar(255) NOT NULL DEFAULT '',
    `pass` varchar(255) NOT NULL DEFAULT '',
    `edrpou` varchar(20) NOT NULL DEFAULT '',
    `drfo` varchar(20) NOT NULL DEFAULT '',
    `last_online` int(11) NOT NULL DEFAULT 0,
    `subject_key_id` varchar(255) NOT NULL DEFAULT ''
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

  $answer_table = "CREATE TABLE `answer` (
    `id` int(11) NOT NULL,
    `tstamp` int(11) NOT NULL DEFAULT 0,
    `request` LONGTEXT NOT NULL,
    `answer` LONGTEXT NOT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
  
  $time_log_table = "CREATE TABLE `time_log` (
    `id` int(11) NOT NULL,
    `rro` int(11) NOT NULL DEFAULT 0,
    `request` text DEFAULT NULL,
    `points` text DEFAULT NULL,
    `tstamp` int(11) NOT NULL DEFAULT 0,
    `total` float NOT NULL DEFAULT 0,
    `db_requests` int(11) NOT NULL DEFAULT 0,
    `queries` longtext DEFAULT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

  $indexes = "
      ALTER TABLE `apteka` ADD UNIQUE KEY `id` (`id`);
      ALTER TABLE `document` ADD PRIMARY KEY (`id`);
      ALTER TABLE `offline_id` ADD PRIMARY KEY (`id`);
      ALTER TABLE `rro` ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `fn` (`num_fiscal`);
      ALTER TABLE `shift` ADD PRIMARY KEY (`id`);
      ALTER TABLE `user` ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `email` (`email`);
      ALTER TABLE `document` MODIFY `id` int NOT NULL AUTO_INCREMENT;
      ALTER TABLE `offline_id` MODIFY `id` int NOT NULL AUTO_INCREMENT;
      ALTER TABLE `rro` MODIFY `id` int NOT NULL AUTO_INCREMENT;
      ALTER TABLE `shift` MODIFY `id` int NOT NULL AUTO_INCREMENT;
      ALTER TABLE `user` MODIFY `id` int NOT NULL AUTO_INCREMENT;
      ALTER TABLE `answer` ADD PRIMARY KEY (`id`);
      ALTER TABLE `answer` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
      ALTER TABLE `time_log` ADD UNIQUE KEY `id` (`id`);
      ALTER TABLE `time_log` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
      ALTER TABLE `document`
        ADD INDEX `idx_rro` (`rro`),
        ADD INDEX `idx_shift` (`shift`),
        ADD INDEX `idx_action_type` (`action_type`),
        ADD INDEX `idx_local_local_number` (`local_local_number`),
        ADD INDEX `idx_fiscal_number` (`fiscal_number`),
        ADD INDEX `idx_tstamp` (`tstamp`),
        ADD INDEX `idx_sent` (`sent`),
        ADD INDEX `idx_is_deleted` (`is_deleted`);";

    if ($conn->query($apteka_table) !== TRUE) {
      echo "<br>error apteka<br>";
      $ok = -1;
    }

    if ($conn->query($doc_table) !== TRUE) {
      echo "<br>error doc<br>";
      $ok = -1;
    }
  
    if ($conn->query($rro_table) !== TRUE) {
      echo "<br>error rro<br>";
      $ok = -1;
    }
    
    if ($conn->query($offline_table) !== TRUE) {
      echo "<br>error offline<br>";
      $ok = -1;
    }
    
    if ($conn->query($shift_table) !== TRUE) {
      echo "<br>error shift<br>";
      $ok = -1;
    }
    
    if ($conn->query($user_table) !== TRUE) {
      echo "<br>error user<br>";
      $ok = -1;
    }
    
    if ($conn->query($answer_table) !== TRUE) {
      echo "<br>error answer<br>";
      $ok = -1;
    }

    if ($conn->query($time_log_table) !== TRUE) {
      echo "<br>error timelog<br>";
      $ok = -1;
    }

    if ($conn->multi_query($indexes) !== TRUE) {
      echo "<br>error indexes<br>";
      $ok = -1;
    }
    $conn->close();

    return $ok;
}

function syncDb()
{
  require_once ("init/db.php");

  $ok = true;
  $apteka = $_POST['apteka'];
  $days = (int) $_POST['days'];

  $url = Env::server_url()."/api/sync/install?token=apteka911servicetoken&apteka=".$apteka."&days=".$days;

  $curl = curl_init();
  curl_setopt($curl, CURLOPT_FAILONERROR, true);
  curl_setopt($curl, CURLOPT_MAXCONNECTS, 1);
  curl_setopt($curl, CURLOPT_MAXREDIRS, 10);
  curl_setopt($curl, CURLOPT_TIMEOUT, 30);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
  curl_setopt($curl, CURLOPT_URL, $url);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
  $result = curl_exec($curl);
  $info = curl_getinfo($curl);
  curl_close($curl);

  if ($info['http_code'] == 200) {
    $MApteka = new Apteka();
    $MRRO = new Rro();
    $MShift = new Shift();
    $MDocument = new Document();
    $MOfflineIds = new OfflineNumber();
    $MUser = new User();

    $result = json_decode($result, true);

    if(!$result) {
      return false;
    }
    
    $MApteka->insert([
      "id" => $apteka,
    ]);

    foreach ($result['users'] as $user) {
      $MUser->insert($user);
    }

    foreach ($result['rro'] as $rro) {
      $rro['timer_updated'] = time();
      unset($rro['visible']);
      $MRRO->insert($rro);
    }

    foreach ($result['shifts'] as $rro) {
      $MShift->insert($rro);
    }

    foreach ($result['documents'] as $rro) {
      $rro['sync'] = 1;
      $MDocument->insert($rro);
    }

    foreach ($result['offlineids'] as $id) {
      $MOfflineIds->insert($id);
    }
  } else {
    $ok = false;
  }

  return $ok;
}

if ($_POST['submit']) {
  if ($_POST['reinstall'] == 2) {
    echo "<h2>Установка прервана</h2>";
    die();
  }

  $installed = false;

  echo "Создание базы данных...";
  
  $status = createDB();
  if ($status == 0) {    
    echo "<font color=\"green\">OK</font>";
  } elseif($status == 2) {
    $installed = true;
    echo "<font color=\"red\">ERROR</font>";
  } else {
    echo "<font color=\"red\">ERROR</font>";
    die();
  }

  if ($installed && !isset($_POST['reinstall'])) {
    echo "<div style=\"margin: 20px auto;\">
    <h2>Программа уже установлена. Переустановить?</h2>
    <font color=\"red\">Все локальные данные будут утеряны</font>
    <br><br>
    <form action=\"/install.php\" method=\"post\">
	    <input type=\"hidden\" name=\"reinstall\" value=\"1\" />
      <input type=\"hidden\" name=\"apteka\" value=\"".$_POST['apteka']."\" />
      <input type=\"hidden\" name=\"days\" value=\"".$_POST['days']."\" />
	    <input type=\"submit\" name=\"submit\" value=\"Да\" />
    </form>

    <form action=\"/install.php\" method=\"post\">
	    <input type=\"hidden\" name=\"reinstall\" value=\"2\" />
      <input type=\"hidden\" name=\"apteka\" value=\"".$_POST['apteka']."\" />
      <input type=\"hidden\" name=\"days\" value=\"".$_POST['days']."\" />
	    <input type=\"submit\" name=\"submit\" value=\"Нет\" />
    </form>
    </div>";
    die();
  }

  
  if ($installed === false || $_POST['reinstall']) {
    echo "<br><br>";
    echo "Синхронизация базы данных...";

    if (syncDB()) {
      echo "<font color=\"green\">OK</font>";
    } else {
      echo "<font color=\"red\">ERROR</font>";
    }  
  } else {
    echo "<font color=\"red\">ERROR</font>";
  }
} else {?>
<div style="margin: 20px auto;">
<h2>Установка программы</h2>
<br>
Введите id Аптеки и нажмите кнопку "Установить"
<br><br>
<form action="/install.php" method="post" enctype="multipart/form-data">
	<input type="hidden" name="install" value="1" />
	id аптеки <input type="text" name="apteka" value="" /> <br><br>
  Чеки за последние <input type="text" name="days" value="14" /> дней <br><br>
	<input type="submit" name="submit" value="Установить" />
</form>

<br><br>
<h3><a href="/installone.php">Добавить Фискальный регистратор</a></h3>
<br>
</div>
<?php
}