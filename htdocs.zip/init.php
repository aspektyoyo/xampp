<?php
require_once ("init/debug.php");
require_once ("init/autoload.php");
require_once ("ASweb/Func.php");
require_once ("init/db.php");

require_once ("init/helpers.php");
require_once ("vendor/autoload.php");
