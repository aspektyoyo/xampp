<?php
namespace Model;

use ASweb\MVC\Model\Model;

class Admin extends Model
{
	protected $name = 'admins';
	protected $depends = [];
	protected $relations = [];
	protected $visibility = 0;
	public $par = 0;

}
