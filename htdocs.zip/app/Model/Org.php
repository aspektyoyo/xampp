<?php
namespace Model;

use ASweb\MVC\Model\Model;

class Org extends Model
{
	protected $name = 'org';
	protected $depends = [];
	protected $relations = [];
	protected $prod_vars;
	protected $visibility = 0;
	public $par = 0;
}