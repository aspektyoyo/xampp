<?php
namespace Model;

use ASweb\MVC\Model\Model;

class Document extends Model
{
	protected $name = 'document';
	protected $depends = [];
	protected $relations = [];
	protected $multylang = 1;
	protected $visibility = 1;

	public $par = 0;
}
