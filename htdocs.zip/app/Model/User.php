<?php
namespace Model;

use ASweb\MVC\Model\Model;

class User extends Model
{
	public $type;

	protected $name = 'user';
	protected $depends = [];
	protected $relations = [];
	protected $visibility = 1;
	public $par = 0;
}
