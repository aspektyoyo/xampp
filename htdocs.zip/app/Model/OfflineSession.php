<?php
namespace Model;

use ASweb\MVC\Model\Model;

class OfflineSession extends Model
{
	protected $name = 'offline_session';
	protected $depends = [];
	protected $relations = [];
	protected $prod_vars;
	protected $visibility = 0;
	public $par = 0;
}
