<?php
namespace Model;

use ASweb\MVC\Model\Model;

class Rro extends Model
{
	protected $name = 'rro';
	protected $depends = [];
	protected $relations = [];
	protected $multylang = 1;
	protected $visibility = 1;

	public $par = 0;
}
