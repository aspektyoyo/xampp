<?php
namespace Model;

use ASweb\MVC\Model\Model;

class Answer extends Model
{
	protected $name = 'answer';
	protected $depends = [];
	protected $relations = [];
	protected $prod_vars;
	protected $visibility = 0;
	public $par = 0;
}