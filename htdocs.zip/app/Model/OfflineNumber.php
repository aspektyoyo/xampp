<?php
namespace Model;

use ASweb\MVC\Model\Model;

class OfflineNumber extends Model
{
	protected $name = 'offline_id';
	protected $depends = [];
	protected $relations = [];
	protected $prod_vars;
	protected $visibility = 0;
	public $par = 0;
}