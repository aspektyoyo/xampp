<?php
namespace Model;

use ASweb\MVC\Model\Model;

class Lang extends Model
{
	protected $name = 'lang';
	protected $depends = ["translate"];
	protected $relations = [];
	protected $visibility = 1;
	public $par = 0;
}
