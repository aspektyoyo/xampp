<?php
namespace Model;

use ASweb\MVC\Model\Model;

class Apteka extends Model
{
	protected $name = 'apteka';
	protected $depends = [];
	protected $relations = [];
	protected $prod_vars;
	protected $visibility = 0;
	public $par = 0;
}