<?php
namespace Model;

use ASweb\MVC\Model\Model;

class Sett extends Model
{
	protected $name = 'sett';
	protected $depends = [];
	protected $relations = [];
	protected $multylang = 1;
	protected $visibility = 0;

	public $par = 0;
}
