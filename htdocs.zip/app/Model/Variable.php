<?php
namespace Model;

use ASweb\MVC\Model\Model;

class Variable extends Model
{
	private $model;
	private $field;

	protected $name = 'var';
	protected $depends = [];
	protected $relations = [];
	protected $visibility = 0;
	public $par = 0;

	public function __construct(string $model = '', string $field = '')
	{
		$this->model = $model;
		$this->field = $field;

		parent::__construct();
	}

	public function getall(array $options = [])
	{
		if (isset($options['where']) && $this->model && $this->field) {
			$options['where'] .= " and `model` = '$this->model' and `field` = '$this->field'";
		} elseif ($this->model && $this->field) {
			$options['where'] .= " `model` = '$this->model' and `field` = '$this->field'";
		}

		return parent::getall($options);
	}
}