<?php
namespace Model;

use ASweb\MVC\Model\Model;

class Shift extends Model
{
	protected $name = 'shift';
	protected $depends = [];
	protected $relations = [];
	protected $multylang = 1;
	protected $visibility = 1;
	public $par = 0;
}