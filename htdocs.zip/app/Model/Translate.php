<?php
namespace Model;
use ASweb\Db\Db;
use ASweb\MVC\Model\Model;

class Translate extends Model
{
	protected $name = 'translate';
	protected $depends = [];
	protected $relations = [];
	protected $visibility = 0;
	public $par = 0;

	public function translate($id, $table, $lang)
	{
		return $this->getall(array("where" => "`obj_id` = '".Db::nq($id)."' and `table` = '".Db::nq($table)."' and `lang` = '".Db::nq($lang)."'"));
	}
}
