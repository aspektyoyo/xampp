<?php
namespace Controller;

use ASweb\Api\Api;
use ASweb\MVC\Controller\AbstractController;

class Main extends AbstractController
{
    public function indexAction()
    {
        echo "It works";
        die();
    }

    public function route()
    {
        return 'indexAction';
    }
}

