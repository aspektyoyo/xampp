<?php
namespace Controller;

use ASweb\MVC\Controller\AbstractController;

class Page extends AbstractController
{
    public function indexAction()
    {
        $this->response->error404('404');
    }

    public function route()
    {
        return 'indexAction';
    }
}