<?php
namespace Controller\Api;

use Env;
use Error;
use Model\Org;
use Model\User;
use Model\Apteka;
use ASweb\Log\Session;
use ASweb\Log\TimeLog;
use Model\DocumentAll;
use ASweb\RRO\Server\RRO;
use Model\Rro as ModelRro;
use ASweb\RRO\Server\Shift;
use ASweb\RRO\Client\Document;
use ASweb\RRO\Client\Response;
use ASweb\RRO\Exception\Offline;
use ASweb\RRO\Client\ArrayResponse;
use ASweb\RRO\Client\ErrorResponse;
use Model\Document as ModelDocument;
use ASweb\RRO\Server\Shift as ServerShift;
use ASweb\MVC\Controller\ApiAbstractController;
use ASweb\RRO\Server\Document as ServerDocument;

class Export extends ApiAbstractController
{
    private $_method;
    private $_token;
    private $_request;
    private $_duplicate_check;

    private $_from;
    private $_to;
    private $_fn;
    private $_local_number;
    
    public function rro()
    {
        $Rro = new ModelRro();
        $Org = new Org();
        $Apteka = new Apteka();
        $User = new User();

        $rro = $Rro->get(RRO::getInstance()->getId());
        $apteka = $Apteka->get($rro->apteka);
        $org = $Org->get($rro->apteka);
        $users = $User->getall(["where" => "rro = ".$rro->id]);
        
        $rro->apteka = $apteka;
        $rro->org = $org;
        $rro->users = $users;

        $this->response->json(json_encode($rro, JSON_UNESCAPED_UNICODE));
    }

    public function user()
    {
        $Rro = new ModelRro();
        $Org = new Org();
        $Apteka = new Apteka();
        $User = new User();

        $rro = $Rro->get(RRO::getInstance()->getId());
        $apteka = $Apteka->get($rro->apteka);
        //$org = $Org->get($rro->apteka);
        $user = $User->getone(["where" => "rro = ".$rro->id]);
        
        $user->rro = $rro;
        //$user->org = $org;
        $user->apteka = $apteka;

        $this->response->json(json_encode($user, JSON_UNESCAPED_UNICODE));
    }

    public function zReports()
    {
        $documents = []; 
        $Document = new ModelDocument();
        $Rro = new ModelRro();
        $Org = new Org();
        $Apteka = new Apteka();
        $User = new User();

        $tstamp_from = strtotime($this->_from);
        $tstamp_to = strtotime($this->_to);
        
        if ($this->_fn) {
            $docs = $Document->getall(["where" => "rro = ".RRO::getInstance()->getId()." and fiscal_number = '".$this->_fn."' and is_deleted = 0 and action_type = 'zReport'"]);
        } else {
            $docs = $Document->getall(["where" => "rro = ".RRO::getInstance()->getId()." and tstamp > $tstamp_from and tstamp < $tstamp_to and is_deleted = 0 and action_type = 'zReport'"]);
        }
        
        foreach ($docs as $k => $line) {
            $rro = $Rro->get($line->rro);
            //$org = $Org->get($rro->org);
            $apteka = $Apteka->get($rro->apteka);
            $user = $User->get(RRO::getInstance()->getUserId());
            
            $zReport = json_encode(["report" => Shift::getInstance()->getReport2($line->rro, $line->shift)], JSON_UNESCAPED_UNICODE);
            $send = $line->sent;
            //$request = json_decode(base64_decode($line->request));
            $request = json_decode($zReport);
            
            $company = "";//$org->name; // юр лицо в работе
            $pharmacy = $apteka->name . ' - ' . $apteka->address;
            $pharmacy2 = str_replace(",", "", $pharmacy); // Торгова точка (Аптека)
            $time = $line->tstamp;
            $date = date('d.m.Y H:m:s', $time); //Дата
            $inn = $user->inn; // ЄДРПОУ/ІНН
            $num_fiscal = $rro->num_fiscal; // ФН ПРРО
            $fn = $line->fiscal_number;
            $realSum = $request->report->real->sum; // Дані z - звітів з ПРРО (загальний обіг)
            $realSum = str_replace(".", ",", $realSum);
            $realCash = $request->report->real->pay_form[0]->sum; // ГОТІВКА
            $realCash = str_replace(".", ",", $realCash);
            $realCredit1 = $request->report->real->pay_form[1]->sum; // БЕЗГОТІВКА.1
            $realCredit1 = str_replace(".", ",", $realCredit1);
            $realCredit2 = $request->report->real->pay_form[2]->sum; // БЕЗГОТІВКА.2
            $realCredit2 = str_replace(".", ",", $realCredit2);
            $realCredit3 = $request->report->real->pay_form[3]->sum; // БЕЗГОТІВКА.3
            $realCredit3 = str_replace(".", ",", $realCredit3);
            $realTax2 = $request->report->real->tax->{0}->turnover; // ОБІГ ПДВ 0%
            $realTax2 = str_replace(".", ",", $realTax2);
            $realTax1 = $request->report->real->tax->{7}->turnover; // ОБІГ ПДВ 7%
            $realTax1 = str_replace(".", ",", $realTax1);
            $realTax = $request->report->real->tax->{20}->turnover; // ОБІГ ПДВ 20%
            $realTax = str_replace(".", ",", $realTax);
            $allRealTaxSum = $request->report->real->tax->{20}->sum + $request->report->real->tax->{7}->sum + $request->report->real->tax->{0}->sum; // Податок загальний
            $allRealTaxSum = str_replace(".", ",", $allRealTaxSum);
            $realTax0 = $request->report->real->tax->{0}->sum; // База 0%
            $realTax0 = str_replace(".", ",", $realTax0);
            $realTax7 = $request->report->real->tax->{7}->sum; // База 7%
            $realTax7 = str_replace(".", ",", $realTax7);
            $realTax20 = $request->report->real->tax->{20}->sum; // База 20%
            $realTax20 = str_replace(".", ",", $realTax20);
            $retSum = $request->report->ret->sum; // Повернення Z-звітів з ПРРО
            $retSum = str_replace(".", ",", $retSum);
            $retTax2 = $request->report->ret->tax->{0}->turnover; // База 0%
            $retTax2 = str_replace(".", ",", $retTax2);
            $retTax1 = $request->report->ret->tax->{7}->turnover; // База 7%
            $retTax1 = str_replace(".", ",", $retTax1);
            $retTax = $request->report->ret->tax->{20}->turnover; // База 20%
            $retTax = str_replace(".", ",", $retTax);
            $retTax0 = $request->report->ret->tax->{0}->sum; // База 0%
            $retTax0 = str_replace(".", ",", $retTax0);
            $retTax7 = $request->report->ret->tax->{7}->sum; // База 7%
            $retTax7 = str_replace(".", ",", $retTax7);
            $retTax20 = $request->report->ret->tax->{20}->sum; // База 20%
            $retTax20 = str_replace(".", ",", $retTax20);
            $link = "https://e-cash.e-dorado.com.ua/admin/adm_document.php?info=1&id=".$line->id;
                   
            $documents[] = [
                'Юр лицо' => $company,
                'Торгова точка (Аптека)' => $pharmacy2,
                'Дата' => $date,
                'ЄДРПОУ/ІНН' => $inn,
                'ФН ПРРО' => $num_fiscal,
                'ФН чека' => $fn,
                'Номер зміни' => $line->shift,
                'report' => $request->report,
                'Отправка' => $send,
                'Ссылка' => $link
            ];            
        }
        
        $this->response->json(json_encode($documents, JSON_UNESCAPED_UNICODE));
    }

    public function zReport()
    {
        $Document = new ModelDocument();

        if (!$this->_fn) {
            echo "Неверный ФН";
            die();
        }

        $doc = $Document->getone(["where" => "rro = ".RRO::getInstance()->getId()." and fiscal_number = '".$this->_fn."' and is_deleted = 0 and action_type = 'zReport'"]);

        if (!$doc->id) {
            echo "Неверный ФН";
            die();
        }
        
        $report = ServerShift::getInstance()->getReport2($doc->rro, $doc->shift);
        $report['document'] = $doc;

        $response = new ArrayResponse($report);

        RRO::getInstance()->endTransaction();
        $this->response->json($response);
    }

    public function toJson()
    {       
        $documents = [];
        $Document = new ModelDocument();
        $tstamp_from = strtotime($this->_from);
        $tstamp_to = strtotime($this->_to);
        
        if ($this->_fn) {
            $docs = $Document->getall(["where" => "rro = ".RRO::getInstance()->getId()." and fiscal_number = '".$this->_fn."'"]);
        } elseif($this->_local_number) {
            $docs = $Document->getall(["where" => "rro = ".RRO::getInstance()->getId()." and local_local_number = '".$this->_local_number."'"]);
        } elseif ($tstamp_from && $tstamp_to) {
            $docs = $Document->getall(["where" => "rro = ".RRO::getInstance()->getId()." and tstamp > $tstamp_from and tstamp < $tstamp_to and is_deleted = 0 and action_type in ('sale', 'saleReturn')"]);
        } else {
            $shift_number = RRO::getInstance()->getCurrentShiftNumber();
            $docs = $Document->getall(["where" => "`shift` = ".$shift_number." and rro = ".RRO::getInstance()->getId()." and is_deleted = 0 and action_type in ('sale', 'saleReturn')"]);
        }
        
        foreach ($docs as $doc) {
            $data = [
                "type" => $doc->action_type,
                "fn" => $doc->fiscal_number,
                "shift" => $doc->shift,
                "tstamp" => $doc->tstamp,
                "time_string" => $doc->time_string,
                "prodnum" => ServerDocument::getProdNum($doc),
                "sum" => ServerDocument::getSum($doc),
                "discount" => ServerDocument::getDiscount($doc),
                "payments" => ServerDocument::getPayments($doc),
                "taxes" => ServerDocument::getTaxes($doc),
                "request" => json_decode(base64_decode($doc->request)),
            ];
            $documents[] = $data;
        }

        $this->response->json(json_encode($documents, JSON_UNESCAPED_UNICODE));
    }

//----------------------------------------------------------------    
    public function error404Action()
    {
        $response = new ErrorResponse("Такого метода нет");
        $this->response->json($response);
    }

    public function authError()
    {
        $response = new ErrorResponse("Неверный токен");
        $this->response->json($response);
    }

    public function bussyError()
    {
        $response = new ErrorResponse("РРО занято. Выполняется предыдущий запрос");
        $this->response->json($response);
    }

    public function blockedError()
    {
        $response = new ErrorResponse("РРО заблокировано. Возможно таймер 36ч или 168ч достиг максимального значения");
        $this->response->json($response);
    }

    public function shiftClosedError()
    {
        $response = new ErrorResponse("Смена закрыта");
        $this->response->json($response);        
    }

    public function shiftOpenedError()
    {
        $response = new ErrorResponse("Смена уже открыта");        
        $this->response->json($response);
    }

    public function duplicateError()
    {
        $response = [
            "ORDERNUM" => $this->_duplicate_check->fiscal_number,
            "local_number" => $this->_duplicate_check->local_local_number,
            "ERROR" => "Check Duplicate",
        ];

        $this->response->json(json_encode($response));
    }

    public function wrongCheckError()
    {
        $response = new ErrorResponse("Check Request Error");
        $this->response->json($response);
    }

	public function route()
	{
        $this->_token = $this->request->g('token') ?? $this->request->g('api_token') ?? $this->request->j('api_token') ?? null;
        $this->_from = $this->request->g('from');
        $this->_to = $this->request->g('to');
        $this->_fn = $this->request->g('fn');
        $this->_local_number = $this->request->g('local_number');
        $this->_request = $this->request->j();

        if (!$this->_token || ($this->_token && RRO::getInstance()->authByToken($this->_token) == false)) {
            return 'authError';
        }
        
        if (RRO::getInstance()->isBussy()) {
            return 'bussyError';
        }
              
        if ($this->args[2] == 'zreport') {            
            return 'zReport';
        }

        if ($this->args[2] == 'zreports') {            
            return 'zReports';
        }

        if ($this->args[2] == 'json') {
            return 'toJson';
        }

        if ($this->args[2] == 'rro') {
            return 'rro';
        }

        if ($this->args[2] == 'user') {
            return 'user';
        }

        return 'error404Action';
	}
}