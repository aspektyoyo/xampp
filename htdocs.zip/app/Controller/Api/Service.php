<?php
namespace Controller\Api;

use Env;
use Model\Document;
use ASweb\RRO\Server\RRO;
use ASweb\RRO\Client\Client;
use ASweb\RRO\Client\Response;
use ASweb\RRO\Exception\Error;
use ASweb\RRO\Exception\Offline;
use ASweb\RRO\Client\ErrorResponse;
use ASweb\RRO\Server\Check as ServerCheck;
use ASweb\MVC\Controller\ApiAbstractController;
use ASweb\MVC\View\View;
use ASweb\RRO\Service\ClearBase;
use Exception;
use Model\Apteka;
use Model\Org;
use Model\Rro as ModelRro;
use Model\User;

class Service extends ApiAbstractController
{
    private $_method;
    private $_request;
    private $_cash_in_box;
    private $_duplicate_check;

    // отправить все чеки, которые не ушли
    public function flush()
    {
        set_time_limit(0);
        $User = new User();
        $Document = new Document();
        $Rro = new ModelRro();
        $users = $User->getall();

        foreach ($users as $k => $v) {            
            $r = $Rro->get($v->rro);
            RRO::getInstance()->authByToken($v->token);
            $local_number = (int) Client::get('/api/service/localnumber');

            $Document->update([
                "sync" => 1
            ],[
                "where" => "local_number = ".$local_number
            ]);

            echo $r->num_fiscal.": ";
            try {
                if(Client::sendPrevious(0)) {
                    echo "<font color=\"green\">отправлено</font>";
                } else {
                    echo "<font color=\"red\">ошибка</font>";
                }                
            } catch (Exception $e) {
                echo "<font color=\"red\">ошибка</font>";
            }
            echo "<br>";
        }
    }

    public function clearBase()
    {
        $token = $this->request->g('token') ?? $this->request->g('api_token') ?? $this->request->j('api_token') ?? null;

        if ($token && RRO::getInstance()->authByToken($token) == false) {
            return 'authError';
        }

        ClearBase::clear(RRO::getInstance()->getId());
        echo "<font color=\"green\">Done!</font>";
    }

//----------------------------------------------------------------
    public function error404Action()
    {
        $result["error"] = "Wrong url: ".implode("/", $this->args);
        $result["message"] = "Такого метода нет";

        $this->response->setHeader('HTTP/1.0 404 Not Found');
        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }

    public function authError()
    {
        $result["error"] = "Auth error";
        $result["message"] = "Неверный токен";

        $this->response->setHeader('HTTP/1.0 403 Forbidden');
        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }

    public function bussyError()
    {
        $result["error"] = "Bussy";
        $result["message"] = "РРО занято. Выполняется предыдущий запрос";

        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }

    public function blockedError()
    {
        $result["error"] = "Blocked";
        $result["message"] = "РРО заблокировано. Возможно таймер 36ч или 168ч достиг максимального значения";

        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }

    public function duplicateError()
    {
        $result["local_number"] = $this->_duplicate_check->local_local_number;
        $result["ORDERNUM"] = $this->_duplicate_check->fiscal_number ? $this->_duplicate_check->fiscal_number : "mYHdjrgZyBY";
        $result["error"] = "Check Duplicate";
        $result["message"] = "Дублирование чека";
        $result["fiscal_number"] = $this->_duplicate_check->fiscal_number ? $this->_duplicate_check->fiscal_number : "mYHdjrgZyBY";
        $result["sum"] = $this->request->j('total_sum');
        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }
    
    public function shiftClosedError()
    {
        $response = new ErrorResponse("Смена закрыта");
        $this->response->json(json_encode($response, JSON_UNESCAPED_UNICODE));
    }

    public function cashMinusError()
    {
        $result["error"] = "Box minus error";
        $result["message"] = "В кассе недостаточно денег. Баланс ".$this->_cash_in_box." грн";

        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }
    
	public function route()
	{
        if ($this->args[2] == 'flush') {
            return 'flush';
        }

        if ($this->args[2] == 'clear') {
            return 'clearBase';
        }
	}
}