<?php

namespace Controller\Api;

use Env;
use Func;
use ASweb\Api\Api;
use ASweb\RRO\Server\RRO;
use ASweb\RRO\Client\Client;
use ASweb\RRO\Client\Response;
use ASweb\RRO\Exception\Error;
use ASweb\RRO\Server\Document;
use Model\Shift as ModelShift;
use ASweb\RRO\Exception\Offline;
use ASweb\RRO\Service\ClearBase;
use ASweb\RRO\Client\ArrayResponse;
use ASweb\RRO\Client\ErrorResponse;
use ASweb\RRO\Server\OfflineSession;
use Model\Document as ModelDocument;
use ASweb\RRO\Server\Shift as ServerShift;
use ASweb\MVC\Controller\ApiAbstractController;

class Shift extends ApiAbstractController
{
    private $_token;
    private $_request;

    // Пинг
    public function ping()
    {
        RRO::getInstance()->startTransaction();
        try {            
            $response = Client::send(0, Client::METHOD_PING, $this->_request);
           // RRO::getInstance()->toOnline();
        } catch (Offline $e) {
            RRO::getInstance()->toOffline();
            $response = new ErrorResponse($e->getMessage());
        }
        RRO::getInstance()->endTransaction();

        $this->response->json($response);
    }

    // x-Отчет
    public function xReport()
    {
        RRO::getInstance()->startTransaction();

        // Если смена не открыта
        if (RRO::getInstance()->isShiftOpened() == 0) {
            $response = new ErrorResponse("Смена закрыта");
        } else {      
            try {
                // ServerShift::getInstance()->checkFn(RRO::getInstance()->getId(), RRO::getInstance()->getCurrentShiftNumber());
                if ($_GET['shift']) {
                    $report = ServerShift::getInstance()->getReport2(RRO::getInstance()->getId(), $_GET['shift']);
                } else {
                    $report = ServerShift::getInstance()->getReport2(RRO::getInstance()->getId(), RRO::getInstance()->getCurrentShiftNumber());
                }  
                
                $response = new ArrayResponse($report);
            } catch (Offline $e) {                
                $response = new ErrorResponse("Нет соединения с сервером");
            }            
        }       

        RRO::getInstance()->endTransaction();
        $this->response->json($response);
    }

    // Баланс
    public function balance()
    {
        RRO::getInstance()->startTransaction();

        try {
            $balance = ServerShift::getInstance()->getBalance(RRO::getInstance()->getId());
            $response = new ArrayResponse([
                "balance" => $balance
            ]);
        } catch (Offline $e) {                
            $response = new ErrorResponse("Нет соединения с сервером");
        }            

        RRO::getInstance()->endTransaction();
        $this->response->json($response);
    }

    // Открытие смены
    public function openShift()
    {
        RRO::getInstance()->startTransaction();

        // Если смена уже открыта. Ошибка
        if (RRO::getInstance()->isShiftOpened() == 1) {
            $response = new ErrorResponse("Смена уже открыта");        
            $this->response->json($response);
            return;
        }
        
        // Сохраняем запрос и получаем id чека из базы
        $check_id = RRO::getInstance()->saveRequest(Client::METHOD_OPEN, $this->_request);

        // Если смена закрыта, то выполняем запрос
        try {
            $response = Client::send($check_id, Client::METHOD_OPEN, $this->_request);
            $checkFN = $response->ORDERNUM;
            $sent = 1;
        } catch (Offline $e) {
            $checkFN = RRO::getInstance()->getOfflineFN();
            $sent = 0;
            $response = new Response($checkFN);
        }

        // Открываем смену
        RRO::getInstance()->openShift();

        // Сохраняем чек
        RRO::getInstance()->saveCheck($check_id, $checkFN, $sent);

        RRO::getInstance()->endTransaction();
        $this->response->json($response);
    }

    // z-Отчет. Закрытие смены
    public function zReport()
    {        
        // Если смена не открыта. Ошибка
        if (RRO::getInstance()->isShiftOpened() == 0) {
            $response = new ErrorResponse("Смена закрыта");
            $this->response->json($response);
            return;
        }

        ClearBase::clear(RRO::getInstance()->getId());
        RRO::getInstance()->startTransaction();

        $report = ServerShift::getInstance()->getReport2();
        
        // Сохраняем запрос и получаем id чека из базы
        $check_id = RRO::getInstance()->saveRequest(Client::METHOD_ZREPORT, $this->_request);
        try {
            $response = Client::send($check_id, Client::METHOD_ZREPORT, $this->_request);
            $checkFN = $response->ORDERNUM;
            $sent = 1;
        } catch (Offline $e) {
            $checkFN = RRO::getInstance()->getOfflineFN();
            $sent = 0;
            $response = new Response($checkFN);
        }
        $Document = new ModelDocument();
        $check = $Document->get($check_id);
        // Закрываем смену
        RRO::getInstance()->closeShift($check);

        // Сохраняем чек
        RRO::getInstance()->saveCheck($check_id, $checkFN, $sent);        
            
        RRO::getInstance()->endTransaction();
        $this->response->json($response);
    }

//----------------------------------------------------------------------------
    public function error404Action()
    {
        $result["error"] = "Wrong url: " . implode("/", $this->args);
        $result["message"] = "Такого метода нет";

        $this->response->setHeader('HTTP/1.0 404 Not Found');
        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }

    public function authError()
    {
        $result["error"] = "Auth error";
        $result["message"] = "Неверный токен";

        $this->response->setHeader('HTTP/1.0 403 Forbidden');
        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }

    public function bussyError()
    {
        $result["error"] = "Bussy";
        $result["message"] = "РРО занято. Выполняется предыдущий запрос";

        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }

    public function blockedError()
    {
        $result["error"] = "Blocked";
        $result["message"] = "РРО заблокировано. Возможно таймер 36ч или 168ч достиг максимального значения";

        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }

    public function route()
    {
        $this->_token = $this->request->g('token') ?? $this->request->g('api_token') ?? $this->request->j('api_token') ?? null;
        $this->_request = $this->request->j();

        if ($this->_token && RRO::getInstance()->authByToken($this->_token) == false) {
            return 'authError';
        }

        if (RRO::getInstance()->isBussy()) {
            return 'bussyError';
        }

        if ($this->args[2] == '') {            
            $action = $this->request->j('action_type') ?? $this->request->g('action');
            if ($action == 'OPEN_SHIFT') {
                return 'openShift';
            } elseif ($action == 'Z_REPORT') {
                return 'zReport';
            }
        } elseif ($this->args[2] == 'xReport') {
            return 'xReport';
        } elseif ($this->args[2] == 'balance') {
            return 'balance';
        } elseif ($this->args[2] == 'ping') {
            return 'ping';
        }

        return 'error404Action';
    }
}