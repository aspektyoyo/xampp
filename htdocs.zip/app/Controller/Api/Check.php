<?php
namespace Controller\Api;

use Env;
use Func;
use Model\Org;
use Model\User;
use Model\Apteka;
use Dompdf\Dompdf;
use Model\Document;
use ASweb\MVC\View\View;
use ASweb\RRO\Server\RRO;
use Model\Rro as ModelRro;
use ASweb\RRO\Client\Client;
use chillerlan\QRCode\QRCode;
use ASweb\RRO\Client\Response;
use ASweb\RRO\Exception\Error;
use ASweb\RRO\Exception\Offline;
use ASweb\RRO\Client\ErrorResponse;
use ASweb\RRO\Server\Check as ServerCheck;
use ASweb\MVC\Controller\ApiAbstractController;
use ASweb\RRO\Server\Shift;
use ASweb\RRO\Service\ClearBase;

class Check extends ApiAbstractController
{
    private $_method;
    private $_request;
    private $_cash_in_box;
    private $_duplicate_check;

    // Новый чек. Внесение, выдача, продажа, возврат
    public function newCheck()
    {
        RRO::getInstance()->startTransaction();

        // Сохраняем запрос и получаем id чека из базы
        $check_id = RRO::getInstance()->saveRequest($this->_method, $this->_request);

        try {
            if ($this->_method == Client::METHOD_ZREPORT) {
                ClearBase::clear(RRO::getInstance()->getId());
            }
            
            $response = Client::send($check_id, $this->_method, $this->_request);
            $checkFN = $response->ORDERNUM;
            $sent = 1;
            RRO::getInstance()->saveCheck($check_id, $checkFN, $sent);
        } catch (Offline $e) {
            $checkFN = RRO::getInstance()->getOfflineFN();
            $sent = 0;
            $response = new Response($checkFN);
            RRO::getInstance()->saveCheck($check_id, $checkFN, $sent);
        } catch (Error $e) {
            $Document = new Document();
            $check = $Document->get($check_id);

            $response = json_encode([
                $result["local_number"] = $check->local_local_number,
                $result["ORDERNUM"] = $check->fiscal_number,
                $result["error"] = $e->getMessage(),
                $result["message"] = $e->getMessage(),
                $result["fiscal_number"] = $check->fiscal_number,
            ], JSON_UNESCAPED_UNICODE);
        }
        
        RRO::getInstance()->endTransaction();
        $this->response->json($response);
    }   

    // Отослать чек на Email или телефон
    public function sendToCustomer()
    {                
        $result = ["status" => "sent"];
        $this->response->json(json_encode($result));
    }

//----------------------------------------------------------------
    public function checkInfo()
    {
        //require (Env::path().'/app/init/view.php');
        $view = new View(Env::path());
        $view->setBasePath(Env::path()."/app/view");
        // $view->path = "/public";
        // $view->globalpath = Env::path();

        $id = (string) $_GET['fn'];
        $Document = new Document();
        $view->document = $Document->getone(["where" => "fiscal_number = '".$id."'"]);
        $MRRO = new ModelRro();
        $MUser = new User();
        $MApteka = new Apteka();
        //$MOrg = new Org();
    
        $view->rro = $MRRO->get(intval($view->document->rro));
        $view->user = $MUser->getone(["where" => "rro = ".$view->document->rro]);
        $view->apteka = $MApteka->get(intval($view->rro->apteka));
        //$view->org = $MOrg->get(intval($view->rro->org));
    
        echo $view->render("check-info.php");
        die();
    }

    public function checkPdf()
    {        
        $view = new View(Env::path());
        $view->setBasePath(Env::path()."/app/view");
        // $view->path = "/public";
        // $view->globalpath = Env::path();

        $id = (string) $_GET['fn'];
        $Document = new Document();
        $view->document = $Document->getone(["where" => "fiscal_number = '".$id."'"]);
        $MRRO = new ModelRro();
        $MUser = new User();
        $MApteka = new Apteka();
        //$MOrg = new Org();
    
        $view->rro = $MRRO->get(intval($view->document->rro));
        $view->user = $MUser->getone(["where" => "rro = ".$view->document->rro]);
        $view->apteka = $MApteka->get(intval($view->rro->apteka));
        //$view->org = $MOrg->get(intval($view->rro->org));
        $view->QR = new QRCode();        
        
        $html = $view->render("check-info-pdf.php");
        
        $dompdf = new Dompdf();
        $dompdf->loadHtml($html);
        $options = $dompdf->getOptions();
        $options->setDefaultFont('DejavuSans.ttf');
        $options->set(array(
            'isRemoteEnabled' => true,
            'isHtml5ParserEnabled' => true
        ));        
        $dompdf->setOptions($options);

        $paper = [0, 0, 145, 100];
        $dompdf->setPaper($paper);
        $dompdf->render();
        $page_count = $dompdf->getCanvas()->get_page_number();
        
        $dompdf = new Dompdf();
        $dompdf->loadHtml($html);
        $options = $dompdf->getOptions();
        $options->setDefaultFont('DejavuSans.ttf');
        $options->set(array(
            'isRemoteEnabled' => true,
            'isHtml5ParserEnabled' => true
        ));        
        $dompdf->setOptions($options);
        $paper = [0, 0, 145, 100 * ($page_count - 3)];
        $dompdf->setPaper($paper);
        $dompdf->render();

        header("Content-type:application/pdf");
        echo $dompdf->output();
        die();
    }

    public function xPdf()
    {        
        $view = new View(Env::path());
        $view->setBasePath(Env::path()."/app/view");

        $MRRO = new ModelRro();
        $MUser = new User();
        $MApteka = new Apteka();

        $view->items = $view->report = Shift::getInstance()->getReport2(RRO::getInstance()->getId(), RRO::getInstance()->getCurrentShiftNumber(), false, false);
        $view->rro = $MRRO->get(RRO::getInstance()->getId());
        $view->user = $MUser->getone(["where" => "rro = ".RRO::getInstance()->getId()]);
        $view->apteka = $MApteka->get(intval($view->rro->apteka));
        $view->QR = new QRCode();        
        
        $html = $view->render("x-info-pdf.php");
        
        $dompdf = new Dompdf();
        $dompdf->loadHtml($html);
        $options = $dompdf->getOptions();
        $options->setDefaultFont('DejavuSans.ttf');
        $options->set(array(
            'isRemoteEnabled' => true,
            'isHtml5ParserEnabled' => true
        ));        
        $dompdf->setOptions($options);

        $paper = [0, 0, 145, 100];
        $dompdf->setPaper($paper);
        $dompdf->render();
        $page_count = $dompdf->getCanvas()->get_page_number();
        
        $dompdf = new Dompdf();
        $dompdf->loadHtml($html);
        $options = $dompdf->getOptions();
        $options->setDefaultFont('DejavuSans.ttf');
        $options->set(array(
            'isRemoteEnabled' => true,
            'isHtml5ParserEnabled' => true
        ));        
        $dompdf->setOptions($options);
        $paper = [0, 0, 145, 100 * ($page_count - 3)];
        $dompdf->setPaper($paper);
        $dompdf->render();

        header("Content-type:application/pdf");
        echo $dompdf->output();
        die();
    }
//----------------------------------------------------------------
    public function checkRound()
    {
        $id = (string) $_GET['fn'];
        $Document = new Document();
        $document = $Document->getone(["where" => "fiscal_number = '".$id."'"]);
        
        $request = json_decode(base64_decode($document->request), true);
        $payments = $request['payments'];
        $cash = 0;
        $noround = 0;

        foreach ($payments as $sum) {
            if ($sum['code'] == '0') {
                $cash = $sum['sum'];
                if ($sum['noround']) {
                    $noround = 1;
                }
            }
        }
    
        $cash_rounded = round($cash, 1);
        $r = (float) $cash_rounded - (float) $cash;
        if ($noround) {
            $document->round = 0;
        } else {
            $document->round = Func::fmtmoney($r);
        }        

        $this->response->json(json_encode($document));
    }
//----------------------------------------------------------------
    public function error404Action()
    {
        $result["error"] = "Wrong url: ".implode("/", $this->args);
        $result["message"] = "Такого метода нет";

        $this->response->setHeader('HTTP/1.0 404 Not Found');
        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }

    public function authError()
    {
        $result["error"] = "Auth error";
        $result["message"] = "Неверный токен";

        $this->response->setHeader('HTTP/1.0 403 Forbidden');
        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }

    public function bussyError()
    {
        $result["error"] = "Bussy";
        $result["message"] = "РРО занято. Выполняется предыдущий запрос";

        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }

    public function blockedError()
    {
        $result["error"] = "Blocked";
        $result["message"] = "РРО заблокировано. Возможно таймер 36ч или 168ч достиг максимального значения";

        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }

    public function duplicateError()
    {
        $result["local_number"] = $this->_duplicate_check->local_local_number;
        $result["ORDERNUM"] = $this->_duplicate_check->fiscal_number ? $this->_duplicate_check->fiscal_number : "mYHdjrgZyBY";
        $result["error"] = "Check Duplicate";
        $result["message"] = "Дублирование чека";
        $result["fiscal_number"] = $this->_duplicate_check->fiscal_number ? $this->_duplicate_check->fiscal_number : "mYHdjrgZyBY";
        $result["sum"] = $this->request->j('total_sum');
        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }
    
    public function shiftClosedError()
    {
        $response = new ErrorResponse("Смена закрыта");
        $this->response->json(json_encode($response, JSON_UNESCAPED_UNICODE));
    }

    public function cashMinusError()
    {
        $result["error"] = "Box minus error";
        $result["message"] = "В кассе недостаточно денег. Баланс ".$this->_cash_in_box." грн";

        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }
    
	public function route()
	{
        $this->_token = $this->request->g('token') ?? $this->request->g('api_token') ?? $this->request->j('api_token') ?? null;
        $this->_request = $this->request->j();

        if ($this->args[2] == 'info') {
            return 'checkInfo';
        }

        if ($this->args[2] == 'pdf') {
            return 'checkPdf';
        }

        if ($this->args[2] == 'round') {
            return 'checkRound';
        }

        if ($this->_token && RRO::getInstance()->authByToken($this->_token) == false) {
            return 'authError';
        }

        if (RRO::getInstance()->isBussy()) {
            return 'bussyError';
        }

        if (RRO::getInstance()->isBlocked()) {
            //return 'blockedError';
        }

        if ($this->args[2] == 'xpdf') {
            return 'xPdf';
        }

        $Document = new Document();
        if (RRO::getInstance()->getTimerDuplicate() > 0) {
            $last_sale_document = $Document->getone(["where" => "`rro` = ".RRO::getInstance()->getId()." and action_type = 'sale'", "order" => "id desc"]);
        
            if ($last_sale_document->tstamp > (time() - RRO::getInstance()->getTimerDuplicate())) {
                $last_sale_request = json_decode(base64_decode($last_sale_document->request), true);
                $sum_request = $this->request->j('total_sum');
                $sum_last_sale = $last_sale_request['total_sum'];
                if ($sum_request == $sum_last_sale) {
                    return 'duplicateError';
                }
            }
        }

        if ($this->request->j('local_number')) {
            $this->_duplicate_check = $Document->getone(["where" => "local_local_number = ".intval($this->request->j('local_number'))." and `rro` = ".RRO::getInstance()->getId()." and action_type != 'toOffline' and tstamp > ".(time() - 10 * 86400).""]);
            if ($this->request->j('local_number') && $this->_duplicate_check) {
                return 'duplicateError';
            }
        }

        if (RRO::getInstance()->isShiftOpened() == 0) {
            return 'shiftClosedError';
        }

        $action = $this->request->j('action_type') ?? $this->request->g('action');

        if ($this->args[2] == 'service' && $action == 'SERVICE_INPUT') {
            $this->_method = Client::METHOD_SERVICE_INPUT;
            return 'newCheck';
        } elseif ($this->args[2] == 'service' && $action == 'SERVICE_OUTPUT') {
            $this->_method = Client::METHOD_SERVICE_OUTPUT;
            try {
                $response = Client::send(0, Client::METHOD_XREPORT, $this->_request);
                if ($response && $this->request->j('sum') > $response->response()['cash_in_box']) {
                    $this->_cash_in_box = $response->response()['cash_in_box'];
                    //return 'cashMinusError';
                }
            } catch (Offline $e) {
                return 'newCheck';
            }
            
            return 'newCheck';
        } elseif ($this->args[2] == 'sale' && $action == 'Z_SALE') {
            $this->_method = Client::METHOD_SALE;
            return 'newCheck';
        } elseif ($this->args[2] == 'sale' && $action == 'RETURN') {
            $this->_method = Client::METHOD_RETURN;
            return 'newCheck';
        } elseif ($this->args[2] == 'send-to-customer') {
            return 'sendToCustomer';
        }
            
        return 'error404Action';
	}
}