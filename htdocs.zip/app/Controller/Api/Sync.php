<?php
namespace Controller\Api;

use Env;
use Model\Shift;
use Model\OfflineNumber;
use ASweb\RRO\Server\RRO;
use Model\Rro as ModelRro;
use ASweb\RRO\Client\Client;
use Model\Document as ModelDocument;
use ASweb\MVC\Controller\ApiAbstractController;
use ASweb\RRO\Client\ErrorResponse;
use ASweb\RRO\Exception\Offline;

class Sync extends ApiAbstractController
{
    private $_token;

    public function offlineidsAction()
    {
        $MOfflineIds = new OfflineNumber();

        try {
            $response = Client::send(0, Client::METHOD_GET_OFFLINE_IDS, $this->_request);
            foreach ($response['ids'] as $id) {
                if ($MOfflineIds->getone(["where" => "`fn` = '".$id."'"])) {
                } else {
                    $MOfflineIds->insert([
                        "rro" => RRO::getInstance()->getId(),
                        "fn" => $id,
                        "used" => 0,
                        "use_tstamp" => 0,
                    ]);
                }
            }
        } catch (Offline $e) {
            $response = new ErrorResponse("Нет связи с сервером");
        }

        $this->response->json($response);
    }

    public function authError()
    {
        $result["error"] = "Auth error";
        $result["message"] = "Неверный токен";

        $this->response->setHeader('HTTP/1.0 403 Forbidden');
        $this->response->json(json_encode($result, JSON_UNESCAPED_UNICODE));
    }

	public function route()
	{
        $this->_token = $this->request->g('token') ?? $this->request->g('api_token') ?? $this->request->j('api_token') ?? null;
        $this->_request = $this->request->j();

        if ($this->_token && RRO::getInstance()->authByToken($this->_token) == false) {
            return 'authError';
        }
        
        if ($this->args[2] == 'getOfflineIds') {
            return 'offlineidsAction';
        } else {
            return 'syncAction';
        }
	}
}

