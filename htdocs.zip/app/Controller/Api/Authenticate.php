<?php
namespace Controller\Api;

use ASweb\Api\Api;
use ASweb\MVC\Controller\ApiAbstractController;
use Env;
use Model\User;

class Authenticate extends ApiAbstractController
{
    public function indexAction()
	{
        $email = $this->request->j('email') ?? $this->request->g('email');
        $pass = $this->request->j('password') ?? $this->request->g('password');

        $User = new User();
        $user = $User->getone(["where" => "`email` = '".$email."' and `pass` = '".$pass."'"]);

        // Синхронизируем РРО с сервером
        $ok = true;
        $res = Api::get("/sync?token=".$user->token);
        if (!empty($res['error'])) {
            $ok = false;
        }

        if ($user) {
            $response = [
                "token" => $user->token,
                "user" => [
                    "full_name" => $user->full_name,
                    "uuid" => $user->uuid,
                    "email" => $user->email,
                    "edrpou" => $user->edrpou,
                    "drfo" => $user->drfo,
                    "last_online" => date('m-d-Y h:i:s', $user->last_online), //Дата останнього запиту до сервера поточним користувачем
                    "subject_key_id" => $user->subject_key_id
                ] 
            ];
        } else {
            $response = [
                "token" => null,
                "user" => null,
                "error" => "Auth error",
                "message" => "Неверный email или пароль",
            ];
        }
        $this->response->json(json_encode($response, JSON_UNESCAPED_UNICODE));
    }

	public function route()
	{
		return 'indexAction';
	}
}

