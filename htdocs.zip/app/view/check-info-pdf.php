<?php

use ASweb\RRO\Server\Shift;
use ASweb\RRO\Server\Document;

$name = $this->rro->org_name;
$ipn = $this->rro->ipn;
$apteka = $this->rro->name;
$address = $this->rro->address;
$fiscal = $this->rro->num_fiscal;
$localNumber = $this->document->local_number;
$fn = $this->document->fiscal_number;

$a = $this->document->request;
$b = base64_decode($a);

$items = json_decode($b);
$report = $items->action_type;
$header = urldecode($_GET['header']);
$footer = urldecode($_GET['footer']);

if ($report == 'Z_REPORT' || $this->document->action_type == 'zReport') {    
    $time = $items->tstamp;
    $date = date('d.m.Y H:i:s', $time);
        
    $items = Shift::getInstance()->getReport2($this->document->rro, $this->document->shift, false, false);
    if ($_GET['test']) {
        print_r($items);
        die();
    }
    
//    $items = json_decode($zReport);
    $cash = $items['real']['pay_form'][0]['sum'];
    $z1 = number_format($cash, 2, '.', '');

    $b1 = $items['real']['pay_form'][1]['sum'];
    $b2 = $items['real']['pay_form'][2]['sum'];
    $b3 = $items['real']['pay_form'][3]['sum'];

    $round_up = $items['real']['pay_form'][0]['round_up'];
    $round_down = $items['real']['pay_form'][0]['round_down'];
    
    $ret_round_up = $items['ret']['pay_form'][0]['round_up'];
    $ret_round_down = $items['ret']['pay_form'][0]['round_down'];

    $credit_card = $b1 + $b2 + $b3;
    $z2 = number_format($credit_card, 2, '.', '');

    $orders = $items['real']['orders_count'];

    $pdv20 = $items['real']['tax'][20]['sum'];
    $z3 = number_format($pdv20, 2, '.', '');

    $pdv7 = $items['real']['tax'][7]['sum'];
    $z4 = number_format($pdv7, 2, '.', '');

    $pdv0 = $items['real']['tax'][0]['sum'];
    $z5 = number_format($pdv0, 2, '.', '');

    $cash_r = $items['ret']['pay_form'][0]['sum'];
    $c1 = number_format($cash_r, 2, '.', '');

    $b1_r = $items['ret']['pay_form'][1]['sum'];
    $b2_r = $items['ret']['pay_form'][2]['sum'];
    $b3_r = $items['ret']['pay_form'][3]['sum'];

    $b1_s = $items['ret']['tax'][20]['sum'];
    $b2_s = $items['ret']['tax'][7]['sum'];
    $b3_s = $items['ret']['tax'][0]['sum'];

    $z9 = number_format($b1_s, 2, '.', '');
    $z10 = number_format($b2_s, 2, '.', '');
    $z11 = number_format($b3_s, 2, '.', '');

    $b1_p = $items['ret']['tax'][20]['turnover'];
    $z12 = number_format($b1_p, 2, '.', '');
    $b2_p = $items['ret']['tax'][7]['turnover'];
    $z13 = number_format($b2_p, 2, '.', '');
    $b3_p = $items['ret']['tax'][0]['turnover'];
    $z14 = number_format($b3_p, 2, '.', '');

    $excise_real = $items['real']['tax']['excise'];
    $excise_ret = $items['ret']['tax']['excise'];
    
    $credit_card_r = $b1_r + $b2_r + $b3_r;
    $c2 = number_format($credit_card_r, 2, '.', '');

    $orders_r = $items['ret']['orders_count'];

    $pdv20_r = $items['real']['tax'][20]['turnover'];
    $z6 = number_format($pdv20_r, 2, '.', '');

    $pdv7_r = $items['real']['tax'][7]['turnover'];
    $z7 = number_format($pdv7_r, 2, '.', '');

    $pdv0_r = $items['real']['tax'][0]['turnover'];
    $z8 = number_format($pdv0_r, 2, '.', '');

    $cash_in_box_start = $items['cash_in_box_start'];
    $c3 = number_format($cash_in_box_start, 2, '.', '');

    $cash_in_box = $items['cash_in_box'];
    $c4 = number_format($cash_in_box, 2, '.', '');

    $service_input = $items['service_input'];
    $s3 = number_format($service_input, 2, '.', '');

    $service_output = $items['service_output'];
    $s4 = number_format($service_output, 2, '.', '');

    $summa = $credit_card + $cash;
    $summa_round = $items['real']['sum'];//$credit_card + round($cash, 1);
    $total_sum = number_format(($summa_round + $round_down - $round_up), 2, '.', '');
    
    $ret_summa_round = $items['ret']['sum'];
    $ret_total_sum = number_format(($ret_summa_round + $ret_round_down - $ret_round_up), 2, '.', '');

    $s2 = number_format($summa, 2, '.', '');
    $s2_round = number_format($summa_round, 2, '.', '');

    $summa_pdf = $pdv20 + $pdv7 + $pdv0;
    foreach ($excise_real as $k => $v) {
        $summa_pdf += $v['sum'];
    }
    
    $s1 = number_format($summa_pdf, 2, '.', '');

    echo "
<style>
@page { margin: 0px; }
html { margin: 0px; }

body{
    font-family: DejaVu Sans;
    padding: 2px;
    margin: 0;
    line-height: 6px;
    text-transform: uppercase;
}
.container,.qr__container{
    width: 100%;
    display: flex;
}
.qr__container{
    justify-content: center;
    align-items: center;
}
.invoice-container{
    width: 100%;
    //position: absolute;
    right: 0;
}
.head{
    border-bottom: 1px solid rgba(126, 124, 124, 0.3) ;
    display: flex;
    flex-direction: row;
    padding: 5px;
    justify-content: space-between;
}
.head__cross{
    margin-right: 5px;
}

.content{
    max-height: 89vh;
    overflow-y: scroll;

    display: flex;
    flex-wrap: wrap;
    font-size: 8px;
    //max-width: 450px;
    padding-bottom: 50px;
}
.content__header{
    text-align: center;
    border-width: 1px 1px 0 1px;
    margin: 0 2px;
    font-size: 8px;
    font-weight: bold;  

}
.content-border{
    border-bottom: 1px dashed #222222;
    border-width: 1px;
    margin: 0 2px;
}
.price {
    text-align: end;
    margin-right: 10px;
}
.content__realization{
    text-align: center;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    min-height: 60px;
    padding-bottom: 10px;
}
.content__realization, .content__refund, .content__refund_2, .content__refund_3{
    row-gap: 5px;
}
.content__refund, .content__taxes{
    text-align: center;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}
.content__refund_2, .content__refund_3, .content__item-count{
    padding-top: 10px;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    align-content: center;
}
.content__button_xml, .content__button_dps{
    display: flex;
    margin-left: calc(50% - 90px);
    max-width: 180px;
    justify-content: center;
    padding: 2px 5px;
}
.print{
    padding: 3px 5px;
    text-align: right;
}
.print, .content__button_xml, .content__button_dps, .content__refund_3{
    /*border: 1px solid  rgba(126, 124, 124, 0.3);*/
}
#qrcode{
    width: 120px;
    height: 120px;
    margin: 5px auto;        
}
.flex-basis_0-7{
    flex-basis: 70%;
}
.flex-basis_0-3{
    flex-basis: 25%;
}
.flex-basis_1{
    flex-basis: 100%;
}
.content-h1{
    font-size: 12px;
    width:100%;
    margin:-10px auto;
    text-align: center;
    background-image: linear-gradient( to right,
    rgba(255, 255, 255, 1) 0%,
    rgba(255, 255, 255, 0) 15%,
    rgba(255, 255, 255, 0) 40%,
    #ffffff 40%,
    #ffffff 60%,
    rgba(255, 255, 255, 0) 60%,
    rgba(255, 255, 255, 0) 85%,
    rgb(255, 255, 255,1) 100%
    );

}
.margin_left{
    margin-left: 10px;
}

.link{
    color:aqua;
}
.link:hover{
    text-decoration: underline;
    cursor: pointer;
}   
</style>
<body>
<div class='container'>
    <div class='invoice-container'>
        <div class='content'>
            <div class='print flex-basis_1'>$report</div>
            <div class='content__header flex-basis_1'>
                <p>$name</p>
                <p>$apteka</p>
                <p>$address</p>
            </div>
            <div class='content__realization flex-basis_1 content-border'>
                <h2 class='content-h1'>Реалізація</h2>
                <table width=\"100%\" border=\"0\">
                <tr><td width='50%'>Кількість чеків</td><td align='right'>$orders</td></tr>
                <tr><td width='50%'>Готівка</td><td align='right'>$z1</td></tr>
                <tr><td width='50%'>Безготівка</td><td align='right'>$z2</td></tr>
                <tr><td width='50%'>Безготівка 1</td><td align='right'>$b1</td></tr>
                <tr><td width='50%'>Безготівка 2</td><td align='right'>$b2</td></tr>
                <tr><td width='50%'>Безготівка 3</td><td align='right'>$b3</td></tr>
                <tr><td width='50%'>ОБІГ ПДВ А 20%</td><td align='right'>$z6</td></tr>
                <tr><td width='50%'>ОБІГ ПДВ Б 7%</td><td align='right'>$z7</td></tr>
                <tr><td width='50%'>ОБІГ ПДВ В 0%</td><td align='right'>$z8</td></tr>
                <tr><td width='50%'>ПДВ A 20%</td><td align='right'>$z3</td></tr>
                <tr><td width='50%'>ПДВ Б 7%</td><td align='right'>$z4</td></tr>
                <tr><td width='50%'>ПДВ В 0%</td><td align='right'>$z5</td></tr>";
foreach ($excise_real as $k => $excise) {
    echo "<tr><td width='50%'>АКЦИЗ ".$excise['excise_prc']."%</td><td align='right'>".$excise['excise']."</td></tr>";
}
                
echo           "<tr><td width='50%' style='font-weight: bold;'>Загальна сума податків</td><td align='right'>$s1</td></tr>";
if ($round_up || $round_down) {
    echo "<tr><td width='50%' style='font-weight: bold;'>Заокруглення вгору</td><td align='right'>".Func::fmtmoney($round_up)."</td></tr>";
    echo "<tr><td width='50%' style='font-weight: bold;'>Заокруглення вниз</td><td align='right'>".Func::fmtmoney($round_down)."</td></tr>";
    echo "<tr><td width='50%' style='font-weight: bold;'>Загальна сума</td><td align='right'>$total_sum</td></tr>";
    echo "<tr><td width='50%' style='font-weight: bold;'>Загальна сума (без заокруглення)</td><td align='right'>$summa</td></tr>";
} else {
    echo "<tr><td width='50%' style='font-weight: bold;'>Загальна сума</td><td align='right'>$s2</td></tr>";
}
            echo "</table></div>   
            <div class='content__refund flex-basis_1 content-border'>
                <h2 class='content-h1'>Повернення</h2>
                <table width=\"100%\" border=\"0\">
                <tr><td width='50%'>Кількість чеків</td><td align='right'>$orders_r</td></tr>
                <tr><td width='50%'>Готівка</td><td align='right'>$c1</td></tr>
                <tr><td width='50%'>Безготівка</td><td align='right'>$c2</td></tr>
                <tr><td width='50%'>Безготівка 1</td><td align='right'>$b1_r</td></tr>
                <tr><td width='50%'>Безготівка 2</td><td align='right'>$b2_r</td></tr>
                <tr><td width='50%'>Безготівка 3</td><td align='right'>$b3_r</td></tr>
                <tr><td width='50%'>ОБІГ ПДВ А 20%</td><td align='right'>$z12</td></tr>
                <tr><td width='50%'>ОБІГ ПДВ Б 7%</td><td align='right'>$z13</td></tr>
                <tr><td width='50%'>ОБІГ ПДВ В 0%</td><td align='right'>$z14</td></tr>
                <tr><td width='50%'>ПДВ A 20%</td><td align='right'>$z9</td></tr>
                <tr><td width='50%'>ПДВ Б 7%</td><td align='right'>$z10</td></tr>
                <tr><td width='50%'>ПДВ В 0%</td><td align='right'>$z11</td></tr>";
foreach ($excise_ret as $k => $excise) {
    echo "<tr><td width='50%'>АКЦИЗ ".$excise['excise_prc']."%</td><td align='right'>".$excise['excise']."</td></tr>";

}                
if ($ret_round_up || $ret_round_down) {
    echo "<tr><td width='50%' style='font-weight: bold;'>Заокруглення вгору</td><td align='right'>".Func::fmtmoney($ret_round_up)."</td></tr>";
    echo "<tr><td width='50%' style='font-weight: bold;'>Заокруглення вниз</td><td align='right'>".Func::fmtmoney($ret_round_down)."</td></tr>";
    echo "<tr><td width='50%' style='font-weight: bold;'>Загальна сума</td><td align='right'>$ret_total_sum</td></tr>";
} else {
    echo "<tr><td width='50%' style='font-weight: bold;'>Загальна сума</td><td align='right'>$ret_total_sum</td></tr>";
}
            echo "</table></div>
            <div class='content__refund_2 flex-basis_1 content-border'>
            <table width=\"100%\" border=\"0\">
                <tr><td width='50%'>Службове внесення</td><td align='right'>$s3</td></tr>
                <tr><td width='50%'>Службова видача</td><td align='right'>$s4</td></tr>
                <tr><td width='50%'>Гроші в касі на початок зміни</td><td align='right'>$c4</td></tr>
                <tr><td width='50%'>Гроші в касі</td><td align='right'>$c3</td></tr>
            </table>
            </div>
            <div class='content__refund_3 flex-basis_1 content-border'>
            <table width=\"100%\" border=\"0\">
                <tr><td width='50%'>Номер чеку</td><td align='right'>$localNumber</td></tr>
                <tr><td width='50%'>$date</td><td align='right'></td></tr>
                <tr><td width='50%'>ФН ППРО</td><td align='right'>$fiscal</td></tr>
                <tr><td width='50%'>Податковий номер</td><td align='right'>$fn</td></tr>
                <tr><td width=\"50%\" colspan=\"2\" align=\"center\"><b>$footer</b></td></tr>
            </table>
            </div>
        </div>
    </div>
</body>
</html>";
}
if($report == 'Z_SALE'){
    $pdv_a = 0;
    $pdv_b = 0;
    // code - 0 (наличные) , 1,2,3 - безнаоичные
    
    $payments = Document::getPayments($this->document);
    $products = Document::getProducts($this->document);
    $taxes = Document::getTaxes($this->document);
    $round = Document::getRound($this->document);
    $to_pay = Document::getTotal($this->document);
    
    $time = $this->document->tstamp;
    $date = date('d.m.Y H:i:s', $time);

    echo"
<style>
@page { margin: 0px; }
html { margin: 0px; }

body{
    font-family: DejaVu Sans;
    padding: 2px;
    margin: 0;
    line-height: 6px;
    text-transform: uppercase;
}
.container,.qr__container{
    width: 100%;
    display: flex;
}
.qr__container{
    justify-content: center;
    align-items: center;
}
.invoice-container{
    width: 100%;
    //position: absolute;
    right: 0;
}
.head{
    border-bottom: 1px solid rgba(126, 124, 124, 0.3) ;
    display: flex;
    flex-direction: row;
    padding: 5px;
    justify-content: space-between;
}
.head__cross{
    margin-right: 5px;
}

.content{
    max-height: 89vh;
    overflow-y: scroll;

    display: flex;
    flex-wrap: wrap;
    font-size: 8px;
    //max-width: 450px;
    padding-bottom: 50px;
}
.content__header{
    text-align: center;
    border-width: 1px 1px 0 1px;
    margin: 0 2px;
    font-size: 8px;
    font-weight: bold;  

}
.content-border{
    border-bottom: 1px dashed #222222;
    border-width: 1px;
    margin: 0 2px;
}
.price {
    text-align: end;
    margin-right: 10px;
}
.content__realization{
    text-align: center;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    min-height: 60px;
    padding-bottom: 10px;
}
.content__realization, .content__refund, .content__refund_2, .content__refund_3{
    row-gap: 5px;
}
.content__refund, .content__taxes{
    text-align: center;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}
.content__refund_2, .content__refund_3, .content__item-count{
    padding-top: 10px;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    align-content: center;
}
.content__button_xml, .content__button_dps{
    display: flex;
    margin-left: calc(50% - 90px);
    max-width: 180px;
    justify-content: center;
    padding: 2px 5px;
}
.print{
    padding: 3px 5px;
    text-align: right;
}
.print, .content__button_xml, .content__button_dps, .content__refund_3{
    /*border: 1px solid  rgba(126, 124, 124, 0.3);*/
}
#qrcode{
    width: 120px;
    height: 120px;
    margin: 5px auto;        
}
.flex-basis_0-7{
    flex-basis: 70%;
}
.flex-basis_0-3{
    flex-basis: 25%;
}
.flex-basis_1{
    flex-basis: 100%;
}
.content-h1{
    font-size: 12px;
    width:100%;
    margin:-10px auto;
    text-align: center;
    background-image: linear-gradient( to right,
    rgba(255, 255, 255, 1) 0%,
    rgba(255, 255, 255, 0) 15%,
    rgba(255, 255, 255, 0) 40%,
    #ffffff 40%,
    #ffffff 60%,
    rgba(255, 255, 255, 0) 60%,
    rgba(255, 255, 255, 0) 85%,
    rgb(255, 255, 255,1) 100%
    );

}
.margin_left{
    margin-left: 10px;
}

.link{
    color:aqua;
}
.link:hover{
    text-decoration: underline;
    cursor: pointer;
}   
</style>
<body>
    <div class='container'>
        <div class='invoice-container'>
            <div class='content'>                
                <div class='content__header flex-basis_1'>
                <p>$name</p>
                <p>$apteka</p>
                <p>$address</p>
                </div>
                <div class='content__item-count flex-basis_1 content-border'>";
    $i = 0;
    $discount = 0;
    foreach ($products as $item){

        $i++;
        $a = $item['name'];
        $b = $item['unit_name'];
        $c = $item['amount'];
        $p = $item['price'];
        $l = $item['letters'];
        $discount += $item['sum_discount'];
        $sum = 0;
        echo "<table width=\"100%\" border=\"0\"><tr><td width=\"50%\"><b>$a</b></td><td align=\"right\">$c $b x ".Func::fmtmoney($p)." ($l)</td></tr></table>";
    }
    echo "</div>
                <div class='content__realization flex-basis_1 content-border'>
                    <h2 class='content-h1'>Оплата</h2>";

    echo "<table width=\"100%\" border=\"0\">";
    foreach ($payments as $payment) {
        $sum += $payment['sum'];
        echo "<tr><td width=\"50%\"><b>".$payment['name']."</b></td><td align=\"right\">".Func::fmtmoney($payment['sum'])."</td></tr>";
    }
        echo "<tr><td width=\"50%\"><b>ОБІГ ПДВ</b></td><td align=\"right\">&nbsp;</td></tr>";

        echo "</table></div>";

        echo "<div class='content__refund flex-basis_1 content-border'>";
        echo "<h2 class='content-h1'>Підсумок чеку</h2>";
        echo "<table width=\"100%\" border=\"0\">";

    if ($round) {
        echo "<tr><td width=\"50%\"><b>Заокруглення</b></td><td align=\"right\">".Func::fmtmoney($round)."</td></tr>";
        echo "<tr><td width=\"50%\"><b>Сума до сплати<</b>/td><td align=\"right\">".Func::fmtmoney($to_pay)."</td></tr>";
    } else {
        echo "<tr><td width=\"50%\"><b>Сума</b></td><td align=\"right\">".Func::fmtmoney($to_pay)."</td></tr>";
    }

    if ($discount) {
        echo "<tr><td width=\"50%\"><b>".$payment['name']."</b></td><td align=\"right\">".Func::fmtmoney($payment['sum'])."</td></tr>";
        echo "<tr><td width=\"50%\"><b>Знижка</b></td><td align=\"right\">".Func::fmtmoney($discount)."</td></tr>";
    }

    echo "</table>";
    echo "</div>";
    
    echo "<div class='content__taxes flex-basis_1 content-border'>
                    <h2 class='content-h1'> Податки</h2>";
    echo "<table width=\"100%\" border=\"0\">";
    foreach ($taxes as $k => $v) {
        if ($v['excise']) {
            echo "<tr><td width=\"50%\"><b>АКЦИЗ ".$v['excise_prc']."%</b></td><td align=\"right\">".$v['excise']."</td></tr>";
        }
        echo "<tr><td width=\"50%\"><b>ПДВ ".$v['prc']."%</b></td><td align=\"right\">".$v['sum']."</td></tr>";     
    }           
    echo "</table>";

    $qrcode = $this->QR->render('https://e-cash.e-dorado.com.ua/api/checkinfo/redirect?fn='.$fn);
    echo "      </div>
                <div class='content__refund_3 flex-basis_1'>
                    <table width=\"100%\" border=\"0\">
                        <tr><td width=\"50%\"><b>Номер чеку</b></td><td align=\"right\">$localNumber</td></tr>
                        <tr><td width=\"50%\"><b>$date</b></td><td align=\"right\">&nbsp;</td></tr>
                        <tr><td width=\"50%\"><b>ПДВ ".$v['prc']."%</b></td><td align=\"right\">".$v['sum']."</td></tr>
                    </table>
                    <div class='flex-basis_1 qr__container'><div id='qrcode'><img src=\"$qrcode\" alt=\"QR Code\" width=\"120\" height=\"120\"/></div></div>
                    <table width=\"100%\" border=\"0\">
                        <tr><td width=\"50%\"><b>ФН ППРО</b></td><td align=\"right\"><b>$fiscal</b></td></tr>
                        <tr><td width=\"50%\"><b>Фіскальний чек</b></td><td align=\"right\"><b>$items->local_number</b></td></tr>                    
                        <tr><td width=\"50%\"><b>Податковий номер</b></td><td align=\"right\"><b>$fn</b></td></tr>
                        <tr><td width=\"50%\" colspan=\"2\" align=\"center\"><b>$footer</b></td></tr>
                    </table>
                </div>
            </div>
        </div>";
    echo "
</body>
</html>";
}
//
if($report == 'RETURN') {
    // code - 0 (наличные) , 1,2,3 - безнаоичные
    
    $time = $this->document->tstamp;
    $date = date('d.m.Y H:i:s', $time);

    $payments = Document::getPayments($this->document);
    $products = Document::getProducts($this->document);
    $taxes = Document::getTaxes($this->document);
    $round = Document::getRound($this->document);
    $to_pay = Document::getTotal($this->document);

    echo "
<style>
    body{
        font-family: DejaVu Sans;
        padding: 0;
        margin: 0;
    }
    .container,.qr__container{
        width: 100%;
        display: flex;
    }
    .qr__container{
        justify-content: center;
        align-items: center;
    }
    .invoice-container{
        width: 100%;
        //position: absolute;
        right: 0;
    }
    .head{
        border-bottom: 1px solid rgba(126, 124, 124, 0.3) ;
        display: flex;
        flex-direction: row;
        padding: 10px;
        justify-content: space-between;
    }
    .head__cross{
        margin-right: 5px;
    }

    .content{
        max-height: 89vh;
        overflow-y: scroll;

        display: flex;
        flex-wrap: wrap;
        font-size: 12px;
        //max-width: 450px;
        padding-bottom: 50px;
    }
    .content__header{
        text-align: center;
        border: 1px solid rgba(126, 124, 124, 0.3);
        border-width: 1px 1px 0 1px;
        margin: 0 15px;
        font-weight: bold;

    }
    .content-border{
        border: 1px solid rgba(126, 124, 124, 0.3);
        border-width: 1px 1px 0 1px;
        margin: 0 15px;
    }
    .price {
        text-align: end;
        margin-right: 10px;
    }
    .content__realization{
        text-align: center;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        min-height: 60px;
        padding-bottom: 10px;
    }
    .content__realization, .content__refund, .content__refund_2, .content__refund_3{
        row-gap: 5px;
    }
    .content__refund, .content__taxes{
        text-align: center;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        min-height: 60px;
        padding-bottom: 10px;
    }
    .content__refund_2, .content__refund_3, .content__item-count{
        padding-top: 10px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-content: center;
        min-height: 60px;
        padding-bottom: 10px;
    }
    .content__button_xml, .content__button_dps{
        display: flex;
        margin-left: calc(50% - 90px);
        max-width: 180px;
        margin-top: 5px;
        justify-content: center;
        padding: 2px 5px;
    }
    .print{
        max-width: 60px;
        padding: 3px 5px;
        text-align: right;
        margin: 25px 10px 5px 15px;

    }
    .print, .content__button_xml, .content__button_dps, .content__refund_3{
        border: 1px solid  rgba(126, 124, 124, 0.3);
    }
    #qrcode{
        width: 128px;
        height: 128px;
        margin: 10px auto;        
    }
    .flex-basis_0-7{
        flex-basis: 70%;
    }
    .flex-basis_0-3{
        flex-basis: 25%;
    }
    .flex-basis_1{
        flex-basis: 100%;
    }
    .content-h1{
        font-size: 12px;
        width:100%;
        margin:-10px auto;
        text-align: center;
        background-image: linear-gradient( to right,
        rgba(255, 255, 255, 1) 0%,
        rgba(255, 255, 255, 0) 15%,
        rgba(255, 255, 255, 0) 40%,
        #ffffff 40%,
        #ffffff 60%,
        rgba(255, 255, 255, 0) 60%,
        rgba(255, 255, 255, 0) 85%,
        rgb(255, 255, 255,1) 100%
        );

    }
    .margin_left{
        margin-left: 10px;
    }

    .link{
        color:aqua;
    }
    .link:hover{
        text-decoration: underline;
        cursor: pointer;
    }
</style>
<body>
    <div class='container'>
        <div class='invoice-container'>
            <div class='content'>
                <div class='print flex-basis_1'>$report</div>
                <div class='content__header flex-basis_1'>
                <p>$name</p>
                <p>$apteka</p>
                <p>$address</p>
                </div>
                <div class='content__item-count flex-basis_1 content-border'>";
    $i = 0;
    $discount = 0;
    foreach ($products as $item){

        $i++;
        $a = $item['name'];
        $b = $item['unit_name'];
        $c = $item['amount'];
        $p = $item['price'];
        $l = $item['letters'];
        $discount += $item['sum_discount'];
        $sum = 0;
        echo "<table width=\"100%\" border=\"0\"><tr><td width=\"50%\"><b>$a</b></td><td align=\"right\">$c $b x ".Func::fmtmoney($p)." ($l)</td></tr></table>";
    }
    echo "</div>
                <div class='content__realization flex-basis_1 content-border'>
                    <h2 class='content-h1'>Оплата</h2>";

    echo "<table width=\"100%\" border=\"0\">";
    foreach ($payments as $payment) {
        $sum += $payment['sum'];
        echo "<tr><td width=\"50%\"><b>".$payment['name']."</b></td><td align=\"right\">".Func::fmtmoney($payment['sum'])."</td></tr>";
    }
        echo "<tr><td width=\"50%\"><b>ОБІГ ПДВ</b></td><td align=\"right\">&nbsp;</td></tr>";

        echo "</table></div>";

        echo "<div class='content__refund flex-basis_1 content-border'>";
        echo "<h2 class='content-h1'>Підсумок чеку</h2>";
        echo "<table width=\"100%\" border=\"0\">";

    if ($round) {
        echo "<tr><td width=\"50%\"><b>Заокруглення</b></td><td align=\"right\">".Func::fmtmoney($round)."</td></tr>";
        echo "<tr><td width=\"50%\"><b>Сума до сплати</b></td><td align=\"right\">".Func::fmtmoney($to_pay)."</td></tr>";
    } else {
        echo "<tr><td width=\"50%\"><b>Сума</b></td><td align=\"right\"><b>".Func::fmtmoney($to_pay)."</b></td></tr>";
    }

    if ($discount) {
        echo "<tr><td width=\"50%\"><b>".$payment['name']."</b></td><td align=\"right\">".Func::fmtmoney($payment['sum'])."</td></tr>";
        echo "<tr><td width=\"50%\"><b>Знижка</b></td><td align=\"right\">".Func::fmtmoney($discount)."</td></tr>";
    }

    echo "</table></div>";
    echo "<div class='content__taxes flex-basis_1 content-border'>
                    <h2 class='content-h1'> Податки</h2>";
    echo "<table width=\"100%\" border=\"0\">";
    foreach ($taxes as $k => $v) {
        if ($v['excise']) {
            echo "<tr><td width=\"50%\"><b>АКЦИЗ ".$v['excise_prc']."%</b></td><td align=\"right\">".$v['excise']."</td></tr>";
        }
        echo "<tr><td width=\"50%\"><b>ПДВ ".$v['prc']."%</b></td><td align=\"right\">".$v['sum']."</td></tr>";     
    }           
    echo "</table>";

    $qrcode = $this->QR->render('https://e-cash.e-dorado.com.ua/api/checkinfo/redirect?fn='.$fn);
    echo "      </div>
                <div class='content__refund_3 flex-basis_1 content-border'>
                    <table width=\"100%\" border=\"0\">
                        <tr><td width=\"50%\"><b>Номер чеку</b></td><td align=\"right\">$localNumber</td></tr>
                        <tr><td width=\"50%\"><b>$date</b></td><td align=\"right\">&nbsp;</td></tr>
                        <tr><td width=\"50%\"><b>ПДВ ".$v['prc']."%</b></td><td align=\"right\">".$v['sum']."</td></tr>
                    </table>
                    <div class='flex-basis_1 qr__container'><div id='qrcode'><img src=\"$qrcode\" alt=\"QR Code\" width=\"128\" height=\"128\"/></div></div>
                    <table width=\"100%\" border=\"0\">
                        <tr><td width=\"50%\"><b>ФН ППРО</b></td><td align=\"right\"><b>$fiscal</b></td></tr>
                        <tr><td width=\"50%\"><b>Фіскальний чек</b></td><td align=\"right\"><b>$items->local_number</b></td></tr>                    
                        <tr><td width=\"50%\"><b>Податковий номер</b></td><td align=\"right\"><b>$fn</b></td></tr>
                        <tr><td width=\"50%\" colspan=\"2\" align=\"center\"><b>$footer</b></td></tr>
                    </table>
                </div>
            </div>
        </div>
                
</body>
</html>";
}