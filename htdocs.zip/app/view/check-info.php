<?php

use ASweb\RRO\Server\Shift;
use ASweb\RRO\Server\Document;

$name = $this->rro->org_name;
$ipn = $this->rro->ipn;
$apteka = $this->rro->name;
$address = $this->rro->address;
$fiscal = $this->rro->num_fiscal;
$localNumber = $this->document->local_number;
$fn = $this->document->fiscal_number;

$a = $this->document->request;
$b = base64_decode($a);

$items = json_decode($b);
$report = $items->action_type;
$header = urldecode($_GET['header']);
$footer = urldecode($_GET['footer']);

if ($report == 'Z_REPORT' || $this->document->action_type == 'zReport') {    
    $time = $items->tstamp;
    $date = date('d.m.Y H:i:s', $time);
        
    $items = Shift::getInstance()->getReport2($this->document->rro, $this->document->shift, false, false);
    if ($_GET['test']) {
        print_r($items);
        die();
    }
    
//    $items = json_decode($zReport);
    $cash = $items['real']['pay_form'][0]['sum'];
    $z1 = number_format($cash, 2, '.', '');

    $b1 = $items['real']['pay_form'][1]['sum'];
    $b2 = $items['real']['pay_form'][2]['sum'];
    $b3 = $items['real']['pay_form'][3]['sum'];

    $round_up = $items['real']['pay_form'][0]['round_up'];
    $round_down = $items['real']['pay_form'][0]['round_down'];
    
    $ret_round_up = $items['ret']['pay_form'][0]['round_up'];
    $ret_round_down = $items['ret']['pay_form'][0]['round_down'];

    $credit_card = $b1 + $b2 + $b3;
    $z2 = number_format($credit_card, 2, '.', '');

    $orders = $items['real']['orders_count'];

    $pdv20 = $items['real']['tax'][20]['sum'];
    $z3 = number_format($pdv20, 2, '.', '');

    $pdv7 = $items['real']['tax'][7]['sum'];
    $z4 = number_format($pdv7, 2, '.', '');

    $pdv0 = $items['real']['tax'][0]['sum'];
    $z5 = number_format($pdv0, 2, '.', '');

    $cash_r = $items['ret']['pay_form'][0]['sum'];
    $c1 = number_format($cash_r, 2, '.', '');

    $b1_r = $items['ret']['pay_form'][1]['sum'];
    $b2_r = $items['ret']['pay_form'][2]['sum'];
    $b3_r = $items['ret']['pay_form'][3]['sum'];

    $b1_s = $items['ret']['tax'][20]['sum'];
    $b2_s = $items['ret']['tax'][7]['sum'];
    $b3_s = $items['ret']['tax'][0]['sum'];

    $z9 = number_format($b1_s, 2, '.', '');
    $z10 = number_format($b2_s, 2, '.', '');
    $z11 = number_format($b3_s, 2, '.', '');

    $b1_p = $items['ret']['tax'][20]['turnover'];
    $z12 = number_format($b1_p, 2, '.', '');
    $b2_p = $items['ret']['tax'][7]['turnover'];
    $z13 = number_format($b2_p, 2, '.', '');
    $b3_p = $items['ret']['tax'][0]['turnover'];
    $z14 = number_format($b3_p, 2, '.', '');

    $excise_real = $items['real']['tax']['excise'];
    $excise_ret = $items['ret']['tax']['excise'];
    
    $credit_card_r = $b1_r + $b2_r + $b3_r;
    $c2 = number_format($credit_card_r, 2, '.', '');

    $orders_r = $items['ret']['orders_count'];

    $pdv20_r = $items['real']['tax'][20]['turnover'];
    $z6 = number_format($pdv20_r, 2, '.', '');

    $pdv7_r = $items['real']['tax'][7]['turnover'];
    $z7 = number_format($pdv7_r, 2, '.', '');

    $pdv0_r = $items['real']['tax'][0]['turnover'];
    $z8 = number_format($pdv0_r, 2, '.', '');

    $cash_in_box_start = $items['cash_in_box_start'];
    $c3 = number_format($cash_in_box_start, 2, '.', '');

    $cash_in_box = $items['cash_in_box'];
    $c4 = number_format($cash_in_box, 2, '.', '');

    $service_input = $items['service_input'];
    $s3 = number_format($service_input, 2, '.', '');

    $service_output = $items['service_output'];
    $s4 = number_format($service_output, 2, '.', '');

    $summa = $credit_card + $cash;
    $summa_round = $items['real']['sum'];//$credit_card + round($cash, 1);
    $total_sum = number_format(($summa_round + $round_down - $round_up), 2, '.', '');
    
    $ret_summa_round = $items['ret']['sum'];
    $ret_total_sum = number_format(($ret_summa_round + $ret_round_down - $ret_round_up), 2, '.', '');

    $s2 = number_format($summa, 2, '.', '');
    $s2_round = number_format($summa_round, 2, '.', '');

    $summa_pdf = $pdv20 + $pdv7 + $pdv0;
    foreach ($excise_real as $k => $v) {
        $summa_pdf += $v['sum'];
    }
    
    $s1 = number_format($summa_pdf, 2, '.', '');

    echo "
<style>
    body{
        padding: 0;
        margin: 0;
    }
    .container{
        width: 100vw;
        display: flex;

    }
    .invoice-container{
        min-width: 420px;
        position: absolute;
        right: 0;
    }
    .head{
        border-bottom: 1px solid rgba(126, 124, 124, 0.3) ;
        display: flex;
        flex-direction: row;
        padding: 10px;
        justify-content: space-between;
    }
    .head__cross{
        margin-right: 5px;
    }

    .content{
        max-height: 89vh;
        overflow-y: scroll;

        display: flex;
        flex-wrap: wrap;
        font-size: 12px;
        font-family: Arial, Helvetica, sans-serif;
        max-width: 450px;
        padding-bottom: 50px;
    }
    .content__header{
        text-align: center;
        border: 1px solid rgba(126, 124, 124, 0.3);
        border-width: 1px 1px 0 1px;
        margin: 0 15px;

    }
    .content-border{
        border: 1px solid rgba(126, 124, 124, 0.3);
        border-width: 1px 1px 0 1px;
        margin: 0 15px;
    }
    .price {
        text-align: end;
        margin-right: 10px;
    }
    .content__realization{
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        min-height: 120px;
        padding-bottom: 10px;
    }
    .content__realization, .content__refund, .content__refund_2, .content__refund_3{
        row-gap: 5px;
    }
    .content__refund{
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        min-height: 80px;
        padding-bottom: 10px;
    }
    .content__refund_2, .content__refund_3{
        padding-top: 10px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        min-height: 80px;
        padding-bottom: 10px;
    }
    .content__button_xml, .content__button_dps{
        display: flex;
        margin-left: calc(50% - 90px);
        max-width: 180px;
        margin-top: 5px;
        justify-content: center;
        padding: 2px 5px;
    }
    .print{
        max-width: 60px;
        padding: 3px 5px;
        text-align: right;
        margin: 25px 10px 5px 15px;

    }
    .print, .content__button_xml, .content__button_dps, .content__refund_3{
        border: 1px solid  rgba(126, 124, 124, 0.3);

    }
    .flex-basis_0-7{
        flex-basis: 70%;
    }
    .flex-basis_0-3{
        flex-basis: 25%;
    }
    .flex-basis_1{
        flex-basis: 100%;
    }
    .content-h1{
        font-size: 12px;
        width:100%;
        margin-top:-10px;
        text-align: center;
        background-image: linear-gradient( to right,
        rgba(255, 255, 255, 1) 0%,
        rgba(255, 255, 255, 0) 15%,
        rgba(255, 255, 255, 0) 40%,
        #ffffff 40%,
        #ffffff 60%,
        rgba(255, 255, 255, 0) 60%,
        rgba(255, 255, 255, 0) 85%,
        rgb(255, 255, 255, 1) 100%
        );

    }
    .margin_left{
        margin-left: 10px;
    }

    .link{
        color:aqua;
    }
    .link:hover{
        text-decoration: underline;
        cursor: pointer;
    }
    
    #qrcode {
        width:100%;
    }
    .footer{
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>
<body>
<div class='container'>
    <div class='invoice-container'>
        <div class='content'>
            <div class='print flex-basis_1'>$header</div>
            <div class='print flex-basis_1'>$report</div>
            <div class='content__header flex-basis_1'>
                <p>$name</p>
                <p>$apteka</p>
                <p>$address</p>
            </div>
            <div class='content__realization flex-basis_1 content-border'>
                <h2 class='content-h1'>Реалізація</h2>
                <div class='flex-basis_0-7 margin_left'>Кількість чеків</div><div class='price flex-basis_0-3'>$orders</div>
                <div class='flex-basis_0-7 margin_left'>Готівка</div><div class='price flex-basis_0-3'>$z1</div>
                <div class='flex-basis_0-7 margin_left'>Безготівка</div><div class='price flex-basis_0-3'>$z2</div>
                <div class='flex-basis_0-7 margin_left'>Безготівка 1</div><div class='price flex-basis_0-3'>$b1</div>
                <div class='flex-basis_0-7 margin_left'>Безготівка 2</div><div class='price flex-basis_0-3'>$b2</div>
                <div class='flex-basis_0-7 margin_left'>Безготівка 3</div><div class='price flex-basis_0-3'>$b3</div>
                <div class='flex-basis_0-7 margin_left'>ОБІГ ПДВ А 20%</div><div class='price flex-basis_0-3'>$z6</div>
                <div class='flex-basis_0-7 margin_left'>ОБІГ ПДВ Б 7%</div><div class='price flex-basis_0-3'>$z7</div>
                <div class='flex-basis_0-7 margin_left'>ОБІГ ПДВ В 0%</div><div class='price flex-basis_0-3'>$z8</div>
                <div class='flex-basis_0-7 margin_left'>ПДВ A 20%</div><div class='price flex-basis_0-3'>$z3</div>
                <div class='flex-basis_0-7 margin_left'>ПДВ Б 7%</div><div class='price flex-basis_0-3'>$z4</div>
                <div class='flex-basis_0-7 margin_left'>ПДВ В 0%</div><div class='price flex-basis_0-3'>$z5</div>";
foreach ($excise_real as $k => $excise) {
    echo "<div class='flex-basis_0-7 margin_left'>АКЦИЗ ".$excise['excise_prc']."%</div><div class='price flex-basis_0-3'>".$excise['excise']."</div>";
}
                
echo           "<div class='flex-basis_0-7 margin_left' style='font-weight: bold;'>Загальна сума податків</div><div class='price flex-basis_0-3'>$s1</div>";
if ($round_up || $round_down) {
    echo "<div class='flex-basis_0-7 margin_left' style='font-weight: bold;'>Заокруглення вгору</div><div class='price flex-basis_0-3'>".Func::fmtmoney($round_up)."</div>";
    echo "<div class='flex-basis_0-7 margin_left' style='font-weight: bold;'>Заокруглення вниз</div><div class='price flex-basis_0-3'>".Func::fmtmoney($round_down)."</div>";
    echo "<div class='flex-basis_0-7 margin_left' style='font-weight: bold;'>Загальна сума (без заокруглення)</div><div class='price flex-basis_0-3'>$total_sum</div>";
    echo "<div class='flex-basis_0-7 margin_left' style='font-weight: bold;'>Загальна сума</div><div class='price flex-basis_0-3'>$summa</div>";    
} else {
    echo "<div class='flex-basis_0-7 margin_left' style='font-weight: bold;'>Загальна сума</div><div class='price flex-basis_0-3'>$s2</div>";
}
            echo "</div>   
            <div class='content__refund flex-basis_1 content-border'>
                <h2 class='content-h1'>Повернення</h2>
                <div class='flex-basis_0-7 margin_left'>Кількість чеків</div><div class='price flex-basis_0-3'>$orders_r</div>
                <div class='flex-basis_0-7 margin_left'>Готівка</div><div class='price flex-basis_0-3'>$c1</div>
                <div class='flex-basis_0-7 margin_left'>Безготівка</div><div class='price flex-basis_0-3'>$c2</div>
                <div class='flex-basis_0-7 margin_left'>Безготівка 1</div><div class='price flex-basis_0-3'>$b1_r</div>
                <div class='flex-basis_0-7 margin_left'>Безготівка 2</div><div class='price flex-basis_0-3'>$b2_r</div>
                <div class='flex-basis_0-7 margin_left'>Безготівка 3</div><div class='price flex-basis_0-3'>$b3_r</div>
                <div class='flex-basis_0-7 margin_left'>ОБІГ ПДВ А 20%</div><div class='price flex-basis_0-3'>$z12</div>
                <div class='flex-basis_0-7 margin_left'>ОБІГ ПДВ Б 7%</div><div class='price flex-basis_0-3'>$z13</div>
                <div class='flex-basis_0-7 margin_left'>ОБІГ ПДВ В 0%</div><div class='price flex-basis_0-3'>$z14</div>
                <div class='flex-basis_0-7 margin_left'>ПДВ A 20%</div><div class='price flex-basis_0-3'>$z9</div>
                <div class='flex-basis_0-7 margin_left'>ПДВ Б 7%</div><div class='price flex-basis_0-3'>$z10</div>
                <div class='flex-basis_0-7 margin_left'>ПДВ В 0%</div><div class='price flex-basis_0-3'>$z11</div>";
foreach ($excise_ret as $k => $excise) {
    echo "<div class='flex-basis_0-7 margin_left'>АКЦИЗ ".$excise['excise_prc']."%</div><div class='price flex-basis_0-3'>".$excise['excise']."</div>";

}                
if ($ret_round_up || $ret_round_down) {
    echo "<div class='flex-basis_0-7 margin_left' style='font-weight: bold;'>Заокруглення вгору</div><div class='price flex-basis_0-3'>".Func::fmtmoney($ret_round_up)."</div>";
    echo "<div class='flex-basis_0-7 margin_left' style='font-weight: bold;'>Заокруглення вниз</div><div class='price flex-basis_0-3'>".Func::fmtmoney($ret_round_down)."</div>";
    echo "<div class='flex-basis_0-7 margin_left' style='font-weight: bold;'>Загальна сума</div><div class='price flex-basis_0-3'>$ret_total_sum</div>";
} else {
    echo "<div class='flex-basis_0-7 margin_left' style='font-weight: bold;'>Загальна сума</div><div class='price flex-basis_0-3'>$ret_total_sum</div>";
}
            echo "</div>
            <div class='content__refund_2 flex-basis_1 content-border'>
                <div class='flex-basis_0-7 margin_left'>Службове внесення</div><div class='price flex-basis_0-3'>$s3</div>
                <div class='flex-basis_0-7 margin_left'>Службова видача</div><div class='price flex-basis_0-3'>$s4</div>
                <div class='flex-basis_0-7 margin_left'>Гроші в касі на початок зміни</div><div class='price flex-basis_0-3'>$c4</div>
                <div class='flex-basis_0-7 margin_left'>Гроші в касі</div><div class='price flex-basis_0-3'>$c3</div>
            </div>
            <div class='content__refund_3 flex-basis_1 content-border'>
                <div class='flex-basis_0-7 margin_left'>Номер чеку</div><div class='price flex-basis_0-3'>$localNumber</div>
                <div class='flex-basis_0-7 margin_left'>$date</div><div class='price flex-basis_0-3'></div>
                <div class='flex-basis_0-7 margin_left'>ФН ППРО</div><div class='price flex-basis_0-3'>$fiscal</div>
                <div class='flex-basis_0-7 margin_left'>Податковий номер</div><div class='price flex-basis_0-3'>$fn</div>
                <div class='flex-basis_1 footer'>$footer</div>
            </div>            
        </div>
    </div>
</body>
</html>";
}
if($report == 'Z_SALE'){
    $pdv_a = 0;
    $pdv_b = 0;
    // code - 0 (наличные) , 1,2,3 - безнаоичные
    
    $payments = Document::getPayments($this->document);
    $products = Document::getProducts($this->document);
    $taxes = Document::getTaxes($this->document);
    $round = Document::getRound($this->document);
    $to_pay = Document::getTotal($this->document);
    
    $time = $this->document->tstamp;
    $date = date('d.m.Y H:i:s', $time);

    echo"
<script src='/app/view/js/qrcode.min.js'></script>
<style>
    body{
        padding: 0;
        margin: 0;
    }
    .container,.qr__container{
        width: 100%;
        display: flex;
    }
    .qr__container{
        justify-content: center;
        align-items: center;
    }
    .footer{
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .invoice-container{
        min-width: 420px;
        position: absolute;
        right: 0;
    }
    .head{
        border-bottom: 1px solid rgba(126, 124, 124, 0.3) ;
        display: flex;
        flex-direction: row;
        padding: 10px;
        justify-content: space-between;
    }
    .head__cross{
        margin-right: 5px;
    }

    .content{
        max-height: 89vh;
        overflow-y: scroll;

        display: flex;
        flex-wrap: wrap;
        font-size: 12px;
        font-family: Arial, Helvetica, sans-serif;
        max-width: 450px;
        padding-bottom: 50px;
    }
    .content__header{
        text-align: center;
        border: 1px solid rgba(126, 124, 124, 0.3);
        border-width: 1px 1px 0 1px;
        margin: 0 15px;

    }
    .content-border{
        border: 1px solid rgba(126, 124, 124, 0.3);
        border-width: 1px 1px 0 1px;
        margin: 0 15px;
    }
    .price {
        text-align: end;
        margin-right: 10px;
    }
    .content__realization{
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        min-height: 60px;
        padding-bottom: 10px;
    }
    .content__realization, .content__refund, .content__refund_2, .content__refund_3{
        row-gap: 5px;
    }
    .content__refund, .content__taxes{
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        min-height: 60px;
        padding-bottom: 10px;
    }
    .content__refund_2, .content__refund_3, .content__item-count{
        padding-top: 10px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-content: center;
        min-height: 60px;
        padding-bottom: 10px;
    }
    .content__button_xml, .content__button_dps{
        display: flex;
        margin-left: calc(50% - 90px);
        max-width: 180px;
        margin-top: 5px;
        justify-content: center;
        padding: 2px 5px;
    }
    .print{
        max-width: 60px;
        padding: 3px 5px;
        text-align: right;
        margin: 25px 10px 5px 15px;

    }
    .print, .content__button_xml, .content__button_dps, .content__refund_3{
        border: 1px solid  rgba(126, 124, 124, 0.3);
    }
    #qrcode{
        width: 128px;
        height: 128px;
        margin: 10px auto;        
    }
    .flex-basis_0-7{
        flex-basis: 70%;
    }
    .flex-basis_0-3{
        flex-basis: 25%;
    }
    .flex-basis_1{
        flex-basis: 100%;
    }
    .content-h1{
        font-size: 12px;
        width:100%;
        margin-top:-10px;
        text-align: center;
        background-image: linear-gradient( to right,
        rgba(255, 255, 255, 1) 0%,
        rgba(255, 255, 255, 0) 15%,
        rgba(255, 255, 255, 0) 40%,
        #ffffff 40%,
        #ffffff 60%,
        rgba(255, 255, 255, 0) 60%,
        rgba(255, 255, 255, 0) 85%,
        rgb(255, 255, 255,1) 100%
        );

    }
    .margin_left{
        margin-left: 10px;
    }

    .link{
        color:aqua;
    }
    .link:hover{
        text-decoration: underline;
        cursor: pointer;
    }   
</style>
<body>
    <div class='container'>
        <div class='invoice-container'>
            <div class='content'>
                <div class='print flex-basis_1'>$report</div>
                <div class='content__header flex-basis_1'>
                <p>$name</p>
                <p>$apteka</p>
                <p>$address</p>
                </div>
                <div class='content__item-count flex-basis_1 content-border'>";
    $i = 0;
    $discount = 0;
    foreach ($products as $item){

        $i++;
        $a = $item['name'];
        $b = $item['unit_name'];
        $c = $item['amount'];
        $p = $item['price'];
        $l = $item['letters'];
        $discount += $item['sum_discount'];
        $sum = 0;
        echo"<div class='flex-basis_0-7 margin_left'>$a</div><div class='price flex-basis_0-3'>$c $b x ".Func::fmtmoney($p)." ($l)</div>";
    }
    echo "</div>
                <div class='content__realization flex-basis_1 content-border'>
                    <h2 class='content-h1'>Оплата</h2>";
    foreach ($payments as $payment) {
        $sum += $payment['sum'];
        echo "<div class='flex-basis_0-7 margin_left'>".$payment['name']."</div><div class='price flex-basis_0-3'>".Func::fmtmoney($payment['sum'])."</div>";
    }
        echo "<div class='flex-basis_0-7 margin_left'>ОБІГ ПДВ</div><div class='price flex-basis_0-3'></div>
                </div>
                <div class='content__refund flex-basis_1 content-border'>
                    <h2 class='content-h1'>Підсумок чеку</h2>";                    
    if ($round) {
        echo "<div class='flex-basis_0-7 margin_left'>Заокруглення</div><div class='price flex-basis_0-3'>".Func::fmtmoney($round)."</div>";
        echo "<div class='flex-basis_0-7 margin_left'>Сума до сплати</div><div class='price flex-basis_0-3'>".Func::fmtmoney($to_pay)."</div>";        
    } else {
        echo "<div class='flex-basis_0-7 margin_left'>Сума</div><div class='price flex-basis_0-3'>".Func::fmtmoney($to_pay)."</div>";
    }

    if ($discount) {
        echo "          <div class='flex-basis_0-7 margin_left'>Знижка</div><div class='price flex-basis_0-3'>".Func::fmtmoney($discount)."</div>";
    }

    echo "</div>
                <div class='content__taxes flex-basis_1 content-border'>
                    <h2 class='content-h1'>Податки</h2>";
    foreach ($taxes as $k => $v) {
        if ($v['excise']) {
            echo "          <div class='flex-basis_0-7 margin_left'>АКЦИЗ ".$v['excise_prc']."%</div><div class='price flex-basis_0-3'>".$v['excise']."</div>";
        }
        echo "          <div class='flex-basis_0-7 margin_left'>ПДВ ".$v['prc']."%</div><div class='price flex-basis_0-3'>".$v['sum']."</div>";        
    }                    
    echo "      </div>
                <div class='content__refund_3 flex-basis_1 content-border'>
                    <div class='flex-basis_0-7 margin_left'>Номер чеку</div><div class='price flex-basis_0-3'>$localNumber</div>
                    <div class='flex-basis_0-7 margin_left'>$date</div><div class='price flex-basis_0-3'></div>
                    <div class='flex-basis_1 qr__container'><div id='qrcode'></div></div>
                    <div class='flex-basis_0-7 margin_left'>ФН ППРО</div><div class='price flex-basis_0-3'>$fiscal</div>
                    <div class='flex-basis_0-7 margin_left'>Фіскальний чек</div><div class='price flex-basis_0-3'>$items->local_number</div>
                    <div class='flex-basis_0-7 margin_left'>Податковий номер</div><div class='price flex-basis_0-3'>$fn</div>
                    <div class='flex-basis_1 footer'>$footer</div>   
                </div>
            </div>
        </div>
        <script>
            var qrcode = new QRCode('qrcode', {
                text: 'https://e-cash.e-dorado.com.ua/api/checkinfo/redirect?fn=".$fn."',
                width: 128,
                height: 128,
                colorDark : '#000000',
                colorLight : '#ffffff',
                correctLevel : QRCode.CorrectLevel.H
            });
        </script>
</body>
</html>";
}
//
if($report == 'RETURN') {
    // code - 0 (наличные) , 1,2,3 - безнаоичные
    
    $time = $this->document->tstamp;
    $date = date('d.m.Y H:i:s', $time);

    $payments = Document::getPayments($this->document);
    $products = Document::getProducts($this->document);
    $taxes = Document::getTaxes($this->document);
    $round = Document::getRound($this->document);
    $to_pay = Document::getTotal($this->document);

    echo "
<style>
    body{
        padding: 0;
        margin: 0;
    }
    .container,.qr__container{
        width: 100%;
        display: flex;

    }
    .qr__container{
        justify-content: center;
        align-items: center;
    }
    .footer{
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .invoice-container{
        min-width: 420px;
        position: absolute;
        right: 0;
    }
    .head{
        border-bottom: 1px solid rgba(126, 124, 124, 0.3) ;
        display: flex;
        flex-direction: row;
        padding: 10px;
        justify-content: space-between;
    }
    .head__cross{
        margin-right: 5px;
    }

    .content{
        max-height: 89vh;
        overflow-y: scroll;

        display: flex;
        flex-wrap: wrap;
        font-size: 12px;
        font-family: Arial, Helvetica, sans-serif;
        max-width: 450px;
        padding-bottom: 50px;
    }
    .content__header{
        text-align: center;
        border: 1px solid rgba(126, 124, 124, 0.3);
        border-width: 1px 1px 0 1px;
        margin: 0 15px;

    }
    .content-border{
        border: 1px solid rgba(126, 124, 124, 0.3);
        border-width: 1px 1px 0 1px;
        margin: 0 15px;
    }
    .price {
        text-align: end;
        margin-right: 10px;
    }
    .content__realization{
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        min-height: 60px;
        padding-bottom: 10px;
    }
    .content__realization, .content__refund, .content__refund_2, .content__refund_3{
        row-gap: 5px;
    }
    .content__refund, .content__taxes{
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        min-height: 60px;
        padding-bottom: 10px;
    }
    .content__refund_2, .content__refund_3, .content__item-count{
        padding-top: 10px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-content: center;
        min-height: 60px;
        padding-bottom: 10px;
    }
    .content__button_xml, .content__button_dps{
        display: flex;
        margin-left: calc(50% - 90px);
        max-width: 180px;
        margin-top: 5px;
        justify-content: center;
        padding: 2px 5px;
    }
    .print{
        max-width: 60px;
        padding: 3px 5px;
        text-align: right;
        margin: 25px 10px 5px 15px;

    }
    .print, .content__button_xml, .content__button_dps, .content__refund_3{
        border: 1px solid  rgba(126, 124, 124, 0.3);
    }
    #qrcode{
        width: 128px;
        height: 128px;
        margin: 10px auto;        
    }
    .flex-basis_0-7{
        flex-basis: 70%;
    }
    .flex-basis_0-3{
        flex-basis: 25%;
    }
    .flex-basis_1{
        flex-basis: 100%;
    }
    .content-h1{
        font-size: 12px;
        width:100%;
        margin-top:-10px;
        text-align: center;
        background-image: linear-gradient( to right,
        rgba(255, 255, 255, 1) 0%,
        rgba(255, 255, 255, 0) 15%,
        rgba(255, 255, 255, 0) 40%,
        #ffffff 40%,
        #ffffff 60%,
        rgba(255, 255, 255, 0) 60%,
        rgba(255, 255, 255, 0) 85%,
        rgb(255, 255, 255,1) 100%
        );

    }
    .margin_left{
        margin-left: 10px;
    }

    .link{
        color:aqua;
    }
    .link:hover{
        text-decoration: underline;
        cursor: pointer;
    }

</style>
<body>
    <div class='container'>
        <div class='invoice-container'>
            <div class='content'>
                <div class='print flex-basis_1'>$report</div>
                <div class='content__header flex-basis_1'>
                <p>$name</p>
                <p>$apteka</p>
                <p>$address</p>
                </div>
                <div class='content__item-count flex-basis_1 content-border'>";
    $i = 0;
    $discount = 0;
    $sum = 0;
    foreach ($products as $item){

        $i++;
        $a = $item['name'];
        $b = $item['unit_name'];
        $c = $item['amount'];
        $p = $item['price'];
        $l = $item['letters'];
        $discount += $item['sum_discount'];
        $sum = 0;
        echo"<div class='flex-basis_0-7 margin_left'>$a</div><div class='price flex-basis_0-3'>$c $b x ".Func::fmtmoney($p)." ($l)</div>";
    }
    echo "</div>
                <div class='content__realization flex-basis_1 content-border'>
                    <h2 class='content-h1'>Оплата</h2>";
    foreach ($payments as $payment) {
        $sum += $payment['sum'];
        echo "<div class='flex-basis_0-7 margin_left'>".$payment['name']."</div><div class='price flex-basis_0-3'>".Func::fmtmoney($payment['sum'])."</div>";
    }
        echo "<div class='flex-basis_0-7 margin_left'>ОБІГ ПДВ</div><div class='price flex-basis_0-3'></div>
                </div>
                <div class='content__refund flex-basis_1 content-border'>
                    <h2 class='content-h1'>Підсумок чеку</h2>";                    
    if ($round) {
        echo "<div class='flex-basis_0-7 margin_left'>Заокруглення</div><div class='price flex-basis_0-3'>".Func::fmtmoney($round)."</div>";
        echo "<div class='flex-basis_0-7 margin_left'>Сума до сплати</div><div class='price flex-basis_0-3'>".Func::fmtmoney($to_pay)."</div>";        
    } else {
        echo "<div class='flex-basis_0-7 margin_left'>Сума</div><div class='price flex-basis_0-3'>".Func::fmtmoney($to_pay)."</div>";
    }

    if ($discount) {
        echo "          <div class='flex-basis_0-7 margin_left'>Знижка</div><div class='price flex-basis_0-3'>".Func::fmtmoney($discount)."</div>";
    }

    echo "</div>
                <div class='content__taxes flex-basis_1 content-border'>
                    <h2 class='content-h1'>Податки</h2>";
    foreach ($taxes as $k => $v) {
        if ($v['excise']) {
            echo "          <div class='flex-basis_0-7 margin_left'>АКЦИЗ ".$v['excise_prc']."%</div><div class='price flex-basis_0-3'>".$v['excise']."</div>";
        }
        echo "          <div class='flex-basis_0-7 margin_left'>ПДВ ".$v['prc']."%</div><div class='price flex-basis_0-3'>".$v['sum']."</div>";        
    }                    
    echo "      </div>
                <div class='content__refund_3 flex-basis_1 content-border'>
                    <div class='flex-basis_0-7 margin_left'>Номер чеку</div><div class='price flex-basis_0-3'>$localNumber</div>
                    <div class='flex-basis_0-7 margin_left'>$date</div><div class='price flex-basis_0-3'></div>
                    <div class='flex-basis_1 qr__container'><div id='qrcode'></div></div>
                    <div class='flex-basis_0-7 margin_left'>ФН ППРО</div><div class='price flex-basis_0-3'>$fiscal</div>
                    <div class='flex-basis_0-7 margin_left'>Фіскальний чек</div><div class='price flex-basis_0-3'>$items->local_number</div>
                    <div class='flex-basis_0-7 margin_left'>Податковий номер</div><div class='price flex-basis_0-3'>$fn</div>
                    <div class='flex-basis_1 footer'>$footer</div>
                </div>                
            </div>
        </div>
        <script src='/app/view/js/qrcode.min.js'></script>
        <script>
            var qrcode = new QRCode('qrcode', {
                text: 'https://e-cash.e-dorado.com.ua/api/checkinfo/redirect?fn=".$fn."',                
                width: 128,
                height: 128,
                colorDark : '#000000',
                colorLight : '#ffffff',
                correctLevel : QRCode.CorrectLevel.H
            });
        </script>
</body>
</html>";
}