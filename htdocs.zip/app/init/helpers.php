<?php

use ASweb\HTTP\Url;

$config['url'] = new Url();