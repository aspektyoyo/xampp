<?php
$debug = 0;

// if (Env::is_local()) {
// 	$debug = 1;
// }

if ($debug == 1) {
	error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
	ini_set("display_errors", 1);
} else {
	error_reporting(E_ERROR);
	ini_set("display_errors", 0);		
}