<?php
$controllers = [
	"Main",
];

$api = [
	"Check",
	"Shift",
	"Ping",
	"Authenticate",
	"Tax",
	"Sync",
	"Service",
	"Export",
];

$system_scripts = [
	"thumb",
];

$config['controllers'] = $controllers;
$config['api'] = $api;
$config['system_scripts'] = $system_scripts;