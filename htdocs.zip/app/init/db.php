<?php

use ASweb\Db\Db;

$db = Db::getInstance(Env::db_driver(), Env::db_server(), Env::db_login(), Env::db_pass(), Env::db_base(), Env::db_prefix());
$db->q("set character set utf8");
$db->q("set names utf8"); 
