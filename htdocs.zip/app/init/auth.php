<?php
use ASweb\Auth\Auth;

$public_urls = [
	'authenticate',
];

if (!Auth::is_auth()) {
	Auth::authfromcookie();
}