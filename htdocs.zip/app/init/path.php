<?php
$path = $_SERVER['DOCUMENT_ROOT'];
set_include_path(get_include_path() . PATH_SEPARATOR . implode(PATH_SEPARATOR, array($path, $path."/app", realpath($path."/vendor"), ".")));
ini_set("magic_quotes_gpc", 0);
ini_set("magic_quotes_runtime", 0);

session_start();
