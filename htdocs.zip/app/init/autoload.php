<?php
function asweb_load ($class)
{
	$class = str_replace("\\", "/", $class);
	include_once $class . '.php';
}
spl_autoload_register('asweb_load');

spl_autoload_register(function ($class) {
	$class = str_replace("\\", "/", $class);
	include $class . '.php';
});