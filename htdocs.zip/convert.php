<?php

use ASweb\RRO\Client\Client;
use Model\Apteka;
use Model\Document;
use Model\OfflineNumber;
use Model\Rro;
use Model\Shift;
use Model\User;

require ('app/init/path.php');
require ('env.php');
require ('init/autoload.php');
require ('init/system-scripts.php');
require ("init/debug.php");

function convertDB() {
    $ok = 0;
    $servername = Env::db_server();
    $username = Env::db_login();
    $password = Env::db_pass();
    
    // Create connection
    $conn = new mysqli($servername, $username, $password);
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    $conn->query("USE rro");
    // Convert tables

    $apteka_table = "ALTER TABLE `apteka` ENGINE=InnoDB;";

    $doc_table = "ALTER TABLE `document` ENGINE=InnoDB;";

    $offline_table = "ALTER TABLE `offline_id` ENGINE=InnoDB;";

    $rro_table = "ALTER TABLE `rro` ENGINE=InnoDB;";

    $shift_table = "ALTER TABLE `shift` ENGINE=InnoDB;";

  	$user_table = "ALTER TABLE `user` ENGINE=InnoDB;";

  	$answer_table = "ALTER TABLE `answer` ENGINE=InnoDB;";
  
  	// $time_log_table = "ALTER TABLE `time_log` ENGINE=InnoDB;";
  
  	if ($conn->query($apteka_table) !== TRUE) {
    	echo "<br>error apteka<br>";
    	$ok = -1;
  	}

  	if ($conn->query($doc_table) !== TRUE) {
    	echo "<br>error doc<br>";
    	$ok = -1;
  	}

  	if ($conn->query($rro_table) !== TRUE) {
    	echo "<br>error rro<br>";
    	$ok = -1;
  	}
  
  	if ($conn->query($offline_table) !== TRUE) {
    	echo "<br>error offline<br>";
    	$ok = -1;
  	}
  
  	if ($conn->query($shift_table) !== TRUE) {
    	echo "<br>error shift<br>";
    	$ok = -1;
  	}
  
  	if ($conn->query($user_table) !== TRUE) {
    	echo "<br>error user<br>";
    	$ok = -1;
  	}
  
  	if ($conn->query($answer_table) !== TRUE) {
    	echo "<br>error answer<br>";
    	$ok = -1;
  	}

  	// if ($conn->query($time_log_table) !== TRUE) {
    // 	echo "<br>error timelog<br>";
    // 	$ok = -1;
  	// }
    
  	$conn->close();

	return $ok;
}

if ($_POST['submit']) {  
  $installed = false;

  echo "Конвертация базы данных...";
  
  $status = convertDB();
  if ($status == 0) {
    echo "<font color=\"green\">OK</font>";
  } elseif($status == 2) {
    $installed = true;
    echo "<font color=\"red\">ERROR</font>";
  } else {
    echo "<font color=\"red\">ERROR</font>";
    die();
  }
} else {?>
<div style="margin: 20px auto;">
	<h2>Конвертация базы данных</h2>	
	<br><br>
	<form action="/convert.php" method="post" enctype="multipart/form-data">
		<input type="submit" name="submit" value="Конвертировать" />
	</form>
</div>
<?php
}