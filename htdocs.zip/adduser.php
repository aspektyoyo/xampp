<?php

use Model\User;

require ('app/init/path.php');
require ('env.php');
require ('init/autoload.php');
require ('init/system-scripts.php');
require ("init/debug.php");

function syncDb()
{
  require_once ("init/db.php");

  $ok = true;
  $fn = $_POST['fn'];

  $url = Env::server_url()."/api/sync/adduser?token=apteka911servicetoken&fn=".$fn;
  $curl = curl_init();
  curl_setopt($curl, CURLOPT_FAILONERROR, true);
  curl_setopt($curl, CURLOPT_MAXCONNECTS, 1);
  curl_setopt($curl, CURLOPT_MAXREDIRS, 10);
  curl_setopt($curl, CURLOPT_TIMEOUT, 10);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
  curl_setopt($curl, CURLOPT_URL, $url);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
  $result = curl_exec($curl);
  $info = curl_getinfo($curl);
  curl_close($curl);

  if ($info['http_code'] == 200) {
    $MUser = new User();

    $result = json_decode($result, true);
    if ($result) {
      foreach ($result['users'] as $user) {
        $MUser->delete(["where" => "id = ".$user['id']]);
        $MUser->insert($user);
      }
    }    
  } else {
    $ok = false;
  }

  return $ok;
}

if ($_POST['submit']) {
  $installed = false;

  echo "Синхронизация базы данных...";

  if (syncDB()) {
    echo "<font color=\"green\">OK</font>";
  } else {
    echo "<font color=\"red\">ERROR</font>";
  }  
} else {?>
<div style="margin: 20px auto;">
<h2>Добавить Кассира</h2>
<br>
Введите фискальный номер РРО и нажмите кнопку "Установить"
<br><br>
<form action="/adduser.php" method="post" enctype="multipart/form-data">
	<input type="hidden" name="install" value="1" />
	ФН <input type="text" name="fn" value="" />
	<input type="submit" name="submit" value="Установить" />
</form>
</div>
<?php
}