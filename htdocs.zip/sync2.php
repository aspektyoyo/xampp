<?php

use Model\Document;

require ('app/init/path.php');
require ('env.php');
require ('init/autoload.php');
require ('init/system-scripts.php');
require ("init/debug.php");
require_once ("init/db.php");

$MDocument = new Document();
$MDocument->update(['sync' => 2], ['where' => 'sync = 0']);

echo "sync1 done<br><br>\n";
$d = isset($_GET['date']) ? strtotime($_GET['date']) : 1747353600;

if ($d) {
    $MDocument = new Document();
    $MDocument->update(['sync' => 0], ['where' => 'sync = 2 and tstamp > '.$d]);
    echo "sync2 done<br><br>\n";

    echo "Натисніть <a href=\"/api/service/flush\">Flush</a><br>\n";
} else {
    echo "Wrong date<br><br>\n";
}