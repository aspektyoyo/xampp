<?php

namespace ASweb\Api;

class Api
{    
    public static function call($api, $method, $params)
    {
        $curl = curl_init();

        $port = '';

        if ($_SERVER['SERVER_PORT'] != 80) {
            $port = ':'.$_SERVER['SERVER_PORT'];
        }

        if ($_SERVER['HTTPS']) {
            $schema = 'https://';
        } else {
            $schema = 'http://';
        }

        $host = $_SERVER['HTTP_HOST'];

        if (!strstr($api, 'http')) {
            $api = "http://localhost".$api;//$schema.$host.$api;
        }

        if ($method == 'get') {
            $url = $api;
        } elseif ($method == 'post') {
            $url = $api;
            curl_setopt($curl, CURLOPT_POSTFIELDS, $params);
        }
         
        curl_setopt($curl, CURLOPT_FAILONERROR, true);
        curl_setopt($curl, CURLOPT_MAXCONNECTS, 1);
        curl_setopt($curl, CURLOPT_MAXREDIRS, 10);
        curl_setopt($curl, CURLOPT_TIMEOUT, 10);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        
        $result = curl_exec($curl);
        $info = curl_getinfo($curl);
        curl_close($curl);
        
        if ($info['http_code'] != 200) {
            return false;
        }

        return $result;
    }

    public static function get($api, $params = [])
    {
        $result = self::call($api, 'get', $params);
        return $result;
    }

    public static function post($api, $params) 
    {
        $result = self::call($api, 'post', $params);
        return $result;
    }
}