<?php

namespace ASweb\Db;

use ASweb\Db\Entity;

interface DbResultInterface
{
    public function f(): Entity;
    public function fa(): array;
    public function num_rows(): int;    
}