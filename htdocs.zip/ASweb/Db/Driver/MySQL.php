<?php
namespace ASweb\Db\Driver;
	
use ASweb\Db\DBException;
use ASweb\Db\DBInterface;

class MySQL implements DBInterface
{
	protected $mysqli;
		
	public function __construct($server, $login, $pass, $base)
	{
		$this->mysqli = new \mysqli($server, $login, $pass, $base);
		if ($this->mysqli->connect_error) throw new DBException($this->mysqli->connect_error);
	}
				
	/**
	*	Выполняет запрос SQL. !!! Для многострочных запросов используйте mq()
	* @param type $query
	* @return \ASweb\Db\MySQLResult
	* @throws DBException
	*/
	public function q(string $query)
	{
		$res = $this->mysqli->query($query);
		if ($res == false) throw new DBException($this->mysqli->error);
		return new MySQLResult($res);
	}

	/**
	 * Ограниченная функция!!! Нельзя использовать для запросов Select
	 * @param type $query
	 * @throws DBException
	 */
	public function mq(string $query)
	{
		$res = $this->mysqli->multi_query($query);
		if ($res == false) throw new DBException($this->mysqli->error);
		while ($this->mysqli->next_result())
		{
				
		}
	}

	/**
	 * После Insert получает id вставленного элемента
	 * @return type
	 * @throws DBException
	 */
	public function lastid()
	{
		$ret = $this->mysqli->insert_id;
		if ($ret === false) throw new DBException("No MySQL connection was established<br/>");
		return $ret;
	}

	/**
	 * После Insert получает id вставленного элемента
	 * @return type
	 * @throws DBException
	 */		
	public function getLastid()
	{
		return $this->lastid();
	}
		
	private function __wakeup()
	{
	}
		
	private function __clone()
	{
	}
}
