<?php
namespace ASweb\Db;

interface DBInterface {
	public function q(string $query);
	public function mq(string $query);
	public function lastid();
}
