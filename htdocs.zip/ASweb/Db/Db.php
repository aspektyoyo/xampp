<?php
namespace ASweb\Db;

use ASweb\Db\DBException;

class Db implements DBInterface
{
	private static $instance = null;

	private $driver;
	private $db_prefix;

	private function __construct($driver, $server, $login, $pass, $base, $prefix)
	{
		if ($driver == 'mysqli' || $driver == 'mysql') {
			$this->driver = new \ASweb\Db\Driver\MySQL($server, $login, $pass, $base);			
		} else {
			throw new DBException("Wrong DB Driver");
		}

		$this->db_prefix = $prefix;
	}
					
	public static function getInstance($driver = null, $server = null, $login = null, $pass = null, $base = null, $prefix = null): Db
	{
		if (is_null(self::$instance)) {
			if (is_null($server) || is_null($login) || is_null($base)) {
				throw new DBException("Wrong Server, Login, Pass or Base parameters");
			} else {
				self::$instance = new self($driver, $server, $login, $pass, $base, $prefix);
			}
		}
			
		return self::$instance;
	}

	public function prefix()
	{
		return $this->db_prefix;
	}

	public function q(string $query)
	{
		return $this->driver->q($query);
	}

	public function mq(string $query)
	{
		return $this->driver->mq($query);
	}

	public function lastid()
	{
		return $this->driver->lastid();
	}

	public static function dnq($str)
	{
		return stripslashes($str);
	}

	public static function nq($data)
	{
		$data = str_replace("\\", "\\\\", $data);
		$data = str_replace("'", "\'", $data);
		$data = str_replace('"', '\"', $data);
		$data = str_replace("\x00", "\\x00", $data);
		$data = str_replace("\x1a", "\\x1a", $data);
		$data = str_replace("\r", "\\r", $data);
		$data = str_replace("\n", "\\n", $data);
		return($data); 
	}
}