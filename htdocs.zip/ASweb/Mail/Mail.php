<?php
namespace ASweb\Mail;

use Exception;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

class Mail {
	public static function mailhtml($from, $fromadr, $to, $subj, $text, $files = [], $smtp = [])
	{
		$mail = new PHPMailer(true);

		if (!empty($smtp)) {
			$mail->SMTPDebug = SMTP::DEBUG_SERVER;
    		$mail->isSMTP();
    		$mail->Host       = $smtp['host'];
    		$mail->SMTPAuth   = true;
    		$mail->Username   = $smtp['login'];
    		$mail->Password   = $smtp['pass'];
		}

		$mail->isHTML(true);
		$mail->setFrom($fromadr, $from);
		$mail->addAddress($to);

		$mail->Subject = 'Here is the subject';
		$mail->Body    = 'This is the HTML message body <b>in bold!</b>';
		$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
	
		foreach ($files as $k => $v) {
			$mail->addAttachment($v["tmp_name"], $v["name"]);
		}

		try {
			$mail->send();
			return true;
		} catch (Exception $exception) {
			return false;
		}

		$mail = new PHPMailer(true);
	}
}

