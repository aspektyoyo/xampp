<?php
namespace ASweb\HTTP;

use ASweb\Lang\Lang;

class Url
{	
	public static function page()
	{
		return $_SERVER['SCRIPT_NAME'];
	}

	public static function gvar($dpar = "")
	{
		$s = $_SERVER['QUERY_STRING'].'&'.$dpar;
		$a = explode('&', $s);
		foreach ($a as $v) {
			if (preg_match("/^([^=]+)=(.*)$/", $v, $m)) {
				$gv[$m[1]] = urldecode($m[2]);
			}
		}
		$q = '?';
		foreach ($gv as $k => $v) {
			if ($v != '') {
				$q .= $k.'='.urlencode($v).'&';
			}
		}
		
		return (empty($q) || $q == '?') ? '' : rtrim($q, '&');
	}
	 
	public function mk($url)
	{
		if (count(Lang::$langs) > 1 && Lang::$lang != Lang::$default) {
			$url = "/".Lang::$lang.$url;
		}

		return $url;
	}
}
