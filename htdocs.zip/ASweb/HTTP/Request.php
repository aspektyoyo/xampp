<?php
namespace ASweb\HTTP;

class Request
{	
	private $url;
	private $page;
	private $args;
	private $method;
	private $s; // $_SESSION
	private $p; // $_POST
	private $g; // $_GET
	private $c; // $_COOKIE
	private $j; // Json

	private static $instance = null;
	
	private function __construct()
	{			
		$this->parseUrl(); // Init page and args array

		$this->method = $_SERVER['REQUEST_METHOD'];
		$this->s = $_SESSION;
		$this->p = $_POST;
		$this->g = $_GET;
		$this->c = $_COOKIE;
		$this->j = [];
	}

	private function parseUrl(): void
	{
		$request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
		$query_string = isset($_SERVER['QUERY_STRING']) ? $_SERVER['QUERY_STRING'] : '';

		$diff = 1;
		if (strpos($request_uri, "?")) {
			$diff = 2;
		}			
		$this->page = substr($request_uri, 1, strlen($request_uri) - strlen($query_string)-$diff);
		$this->args = explode("/", $this->page);
	}

	public static function isAjax()
	{
		if ($_SERVER["HTTP_X_REQUESTED_WITH"] == "XMLHttpRequest") {
			return true;
		}

		if (function_exists('apache_request_headers')) {
			$headers = apache_request_headers();
			if ($headers["X-Requested-With"] == "XMLHttpRequest" || $headers["HTTP_X_REQUESTED_WITH"] == "XMLHttpRequest") {
				return true;
			}
		}
		return false;
	}

	public function s(string $var = '')
	{
		if (empty($var)) {
			return $this->s;
		} else {
			if (isset($this->s[$var])) {
				return $this->s[$var];
			} else {
				return null;
			}
		}
	}

	public function p(string $var = '')
	{
		if (empty($var)) {
			return $this->p;
		} else {
			if (isset($this->p[$var])) {
				return $this->p[$var];
			} else {
				return null;
			}
		}
	}

	public function g(string $var = '')
	{
		if (empty($var)) {
			return $this->g;
		} else {
			if (isset($this->g[$var])) {
				return $this->g[$var];
			} else {
				return null;
			}
		}
	}

	public function c(string $var = '')
	{
		if (empty($var)) {
			return $this->c;
		} else {
			if (isset($this->c[$var])) {
				return $this->c[$var];
			} else {
				return null;
			}
		}
	}

	public function j(string $var = '')
	{
		if (empty($var)) {
			return $this->j;
		} else {
			if (isset($this->j[$var])) {
				return $this->j[$var];
			} else {
				return null;
			}
		}
	}

	public function setJson (array $json)
	{
		$this->j = $json;
	}

	public function args()
	{
		return $this->args;
	}

	public function shiftArgs()
	{
		array_shift($this->args);
		$this->page = implode("/", $this->args);
	}

	public function page()
	{
		return $this->page;
	}

	public function url()
	{
		return $this->url;
	}

	public function method()
	{
		return $this->method;
	}

	public function getPage()
	{
		return $this->page;
	}

	public function controller()
	{		
	
		if (empty($this->args[0])) {
			$controller = 'Main';
		} elseif ($this->args[0] == 'api') {
			$controller = ucfirst($this->args[1]);
		} else {
			$controller = ucfirst($this->args[0]);
		}
		
		return $controller;
	}

	public function path()
	{
		return $_SERVER['DOCUMENT_ROOT'];
	}

	public static function getInstance(): Request
    {
        if (static::$instance === null) {
            static::$instance = new static();
        }

        return static::$instance;
	}
	
	public static function redir301(string $url)
    {
        header('HTTP/1.1 301 Moved Permanently');
        header("Location: ".$url);
        exit();
	}
	
	private function __clone()
    {
    }
}
