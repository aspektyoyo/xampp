<?php
namespace ASweb\HTTP;

class Response
{
    private $headers = [];
    private $cache;
    private $cont;

    const HEADER_404 = 'HTTP/1.0 404 Not Found';
    const HEADER_301 = 'HTTP/1.1 301 Moved Permanently';
    const HEADER_TYPE_JSON = 'Content-type: application/json; charset=utf-8';
    const HEADER_IMAGE_JPEG = 'Content-type: image/jpeg';
    const HEADER_IMAGE_PNG = 'Content-Type: image/png';
    const HEADER_IMAGE_GIF = 'Content-Type: image/gif';
    const HEADER_IMAGE_WEBP = 'Content-Type: image/webp';
    const HEADER_IMAGE_SVG = 'Content-Type: image/svg+xml';
    const HEADER_TYPE_CSV = 'Content-Type: text/csv';
    const HEADER_TYPE_XML = 'Content-Type: text/xml';
    const HEADER_CACHE_NOCACHE = 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0';
    const HEADER_CACHE_1_MONTH = '';

    const CACHE_NO_CACHE = 0;
    const CACHE_1_HOUR = 3600;
    const CACHE_1_DAY = 86400;
    const CACHE_1_WEEK = 604800;
    const CACHE_1_MONTH = 18144000;
    const CACHE_1_YEAR = 217728000;

    private static $instance = null;

    private function __construct()
    {
        $this->cache = self::CACHE_1_DAY;
    }

    public function setCache(int $cache)
    {
        $this->cache = $cache;
    }

    public function setHeader(string $value)
    {
        $this->header[$value] = $value;
    }

    public function error404(string $cont)
    {
        $this->setHeader("HTTP/1.1 404 Not Found");      
        $this->setHeader("Status: 404 Not Found");
        $this->cont = $cont;
    }

    public function html(string $cont)
    {        
        $this->setCache(self::CACHE_1_HOUR);
        $this->cont = $cont;
    }

    public function json(string $json)
    {
        $this->setHeader('Content-Type: application/json; charset=utf-8');
        $this->setCache(self::CACHE_NO_CACHE);
        $this->cont = $json;
    }

    public function image(string $type, string $cont)
    {
        if ($type == 'jpeg' || $type == 'jpg') {
            $this->setHeader(self::HEADER_IMAGE_JPEG);
        } elseif ($type == 'webp') {
            $this->setHeader(self::HEADER_IMAGE_WEBP);
        } elseif ($type == 'png') {
            $this->setHeader(self::HEADER_IMAGE_PNG);
        } elseif ($type == 'gif') {
            $this->setHeader(self::HEADER_IMAGE_GIF);
        } elseif ($type == 'svg') {
            $this->setHeader(self::HEADER_IMAGE_SVG);
        }
        
        $this->setCache(self::HEADER_CACHE_1_MONTH);
        $this->cont = $cont;
    }

    public function file(string $filename, string $mime_type, string $cont)
    {
        $this->setCache(self::CACHE_NO_CACHE);
        $this->setHeader('Content-Type: '.$mime_type);
        $this->setHeader('Content-Disposition: attachment; filename="'.$filename.'"');
        $this->cont = $cont;
    }

    public function custom(string $cont, array $headers)
    {
        foreach ($headers as $h) {
            $this->setHeader($h);
        }
        $this->cont = $cont;
    }

    public static function redir301(string $url)
    {
        header(self::HEADER_301);
        header("Location: ".$url);
        exit();
    }

    public static function redir(string $url)
    {
        header("Location: ".$url);
        exit();
    }

    public static function redirJs(string $url, $timeout = 1)
    {
        echo "<script>setTimeout(\"location.href='".$url."';\", ".$timeout.");</script>";
    }    

    public function show(): void
    {
        $this->cache();
        foreach ($this->header as $k => $v) {
            header($v);
        }

        echo $this->cont;
    }

    private function cache()
    {
        if ($this->cache == self::CACHE_NO_CACHE) {
            $this->setHeader("Expires: 0");
            $this->setHeader("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
            $this->setHeader("Cache-Control: no-store, no-cache, must-revalidate");
            $this->setHeader("Cache-Control: post-check=0, pre-check=0", false);
            $this->setHeader("Pragma: no-cache");
        } else {
            $this->setHeader("Cache-control: public");
            $this->setHeader("Expires: " . gmdate("D, d M Y H:i:s", time() + $this->cache) . " GMT");
        }
    }

    public static function getInstance(): Response
    {
        if (static::$instance === null) {
            static::$instance = new static();
        }

        return static::$instance;
    }

    private function __clone()
    {
    }

    private function __wakeup()
    {
    }
}