<?php

namespace ASweb\Time;

class Time
{
    private $_time;
    private static $instance;

    public static function getInstance(): Time
    {
        if (static::$instance === null) {
            static::$instance = new static();
        }

        return static::$instance;
    }

    public function getTime(): int
    {
        return $this->_time;
    }

    public function getTstamp(): int
    {
        return $this->_time;
    }
    
    public function getTimeString(): int
    {
        return intval(date("YmdHmi", $this->_time));
    }

	private function __construct()
    {
		$this->_time = time();
    }

    private function __clone()
    {
    }
    
    public function __wakeup()
    {
        throw new \Exception("Cannot unserialize singleton Time");
    }
}