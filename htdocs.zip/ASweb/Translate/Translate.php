<?php

namespace ASweb\Translate;

use Statickidz\GoogleTranslate;

class Translate {
    public static function translate($source, $target, $text)
    {        
        try {
            $trans = new GoogleTranslate();
            $result = $trans->translate($source, $target, $text);
        } catch (\Exception $e) {
            return false;
        }
        
        return $result;      
    }

    public static function translateField($Translate, $Model, $id, $field, $src_lang, $dst_lang)
    {
        $table = $Model->table;

        $source = $Model->get($id);
        $text = $source->{$field};

        $translate = $Translate->getone(["where" => "`obj_id` = $id and `lang` = '".$dst_lang."' and `table` = '$table'"]);

        if ($translate->cont) { // Уже есть перевод
            return false;
        } else { // Перевести поле и сохранить перевод
            $t = self::translate($src_lang, $dst_lang, $text);
            $Translate->insert([
                "obj_id" => $id,
                "lang" => $dst_lang,
                "table" => $table,
                "field" => $field,
                "cont" => $t,
            ]);
            return true;
        }
    }
}