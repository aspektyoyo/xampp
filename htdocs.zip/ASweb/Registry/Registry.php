<?php
namespace ASweb\Registry;

class Registry
{
    private static $services = [];

    public static function set(string $key, $value)
    {
        self::$services[$key] = $value;
    }

    public static function get(string $key)
    {
        if (!isset(self::$services[$key])) {
            return null;
        }

        return self::$services[$key];
    }
}