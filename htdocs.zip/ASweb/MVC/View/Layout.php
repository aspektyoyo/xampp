<?php
namespace ASweb\MVC\View;

class Layout
{
	protected $layout;
	protected $path;

	public function __construct(string $layout)
	{
		$this->layout = $layout;
	}

	public function setlayout(string $name)
	{
		$this->layout = $name;
	}

	public function render(View $view)
	{
		return $view->render($this->layout);
	}
}