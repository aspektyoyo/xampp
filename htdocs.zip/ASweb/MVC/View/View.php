<?php
namespace ASweb\MVC\View;

class View
{
    protected $path;
    public $page;

    public function __construct(string $basePath)
    {
        $this->path = $basePath;
    }

    public function getPath()
    {
        return $this->path;
    }

    public function setBasePath(string $basePath)
    {
        $this->path = $basePath;
    }

    public function render(string $script)
    {
        if (file_exists($this->path."/".$script)) {
            ob_start();
            require ($this->path."/".$script);
            $view = ob_get_clean();
            return $view;
        } else {
            throw new \Exception("View script $script not found in '".$this->path."'");
        }
    }

    public function error404()
    {
        ob_start();
        require ($this->path."/page/404.php");
        $view = ob_clean();
        return $view;
    }
}