<?php
namespace ASweb\MVC\Model;

use ASweb\Db\DBInterface;

/**
 *	Интерфейс для всех моделей в архитектуре MVC AS-Commerce
 *	@author Alex Suleymanov <alex.suleymanov@gmail.com>
 * 
 */	
interface ModelInterface extends DBInterface{
	public function get(int $id);
	public function getall(array $options = []);
	public function getone(array $options = []);
	public function update(array $data, array $options = []);
	public function insert(array $data);
	public function delete(array $data = []);
	public function last_id();
}

