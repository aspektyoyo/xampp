<?php
namespace ASweb\MVC\Model\Plugin;

use ASweb\Db\Db;
use ASweb\Db\MySQL;

abstract class AbstractPlugin
{
	protected $db;
	protected $db_prefix;
	
	protected $Options;
	
	public function __construct($options = [])
    {
		$this->db = Db::getInstance();
		$this->db_prefix = $this->db->prefix();
		
        if (is_array($options)) {
            $this->setOptions($options);
        }
    }
	
    public function setOptions(array $options)
    {
        $this->Options = $options;
        return $this;
    }

    public function setOption(string $key, $value)
    {
        $this->Options[$key] = $value;
    }

    public function getOption(string $key)
    {
        if (isset($this->Options[$key])) {
            return $this->Options[$key];
        }

        return null;
    }

    public function getOptions(): array
    {
        return $this->Options;
    }

    public function removeOption(string $key): void
    {
        if (null !== $this->getOption($key)) {
            unset($this->Options[$key]);
        }
    }

    public function clearOptions(): void
    {
        $this->Options = [];
    }
}
