<?php
namespace ASweb\MVC\Model\Decorator;

use ASweb\Db\Entity;
use ASweb\MVC\Model\ModelInterface;

interface DecoratorInterface
{	
	public function get(Entity $row): Entity;
	public function getall(array $rows): array;
	public function update(array $data, int $lastid);
	public function insert(array $data, int $lastid);
	public function delete(array $data, array $options);
	
	public function setOptions(array $options);
	public function setOption(string $key, $value): DecoratorInterface;
	public function getOption(string $key);
	public function getOptions();
	public function removeOption(string $key): bool;
	public function clearOptions(): DecoratorInterface;
	public function setModel(ModelInterface $Model): DecoratorInterface;
	public function getModel(): ModelInterface;
}