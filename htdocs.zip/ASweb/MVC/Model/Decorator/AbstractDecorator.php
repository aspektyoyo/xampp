<?php
namespace ASweb\MVC\Model\Decorator;

use ASweb\Db\Db;
use ASweb\Db\Entity;
use ASweb\MVC\Model\ModelInterface;

abstract class AbstractDecorator implements DecoratorInterface
{
	protected $db;
	protected $db_prefix;

    protected $Options = [];
	
	abstract public function get(Entity $row): Entity;
	abstract public function getall(array $rows): array;
	
	public function update(array $data, int $lastid)
	{		
	}
	
	public function insert(array $data, int $lastid)
	{		
	}
	
	public function delete(array $data, array $options)
	{
	}
	
    public function __construct($options = [])
    {
		$this->db = Db::getInstance();
		$this->db_prefix = $this->db->prefix();
		
        if (is_array($options)) {
            $this->setOptions($options);
        }
    }

    public function setOptions(array $options)
    {
        $this->Options = $options;
        return $this;
    }

    public function setOption(string $key, $value): DecoratorInterface
    {
        $this->Options[$key] = $value;
        return $this;
    }

    public function getOption(string $key)
    {
        if (isset($this->Options[$key])) {
            return $this->Options[$key];
        }

        return null;
    }

    public function getOptions()
    {
        return $this->Options;
    }

    public function removeOption(string $key): bool
    {
        if (null !== $this->getOption($key)) {
            unset($this->Options[$key]);
            return true;
        }

        return false;
    }

    public function clearOptions(): DecoratorInterface
    {
        $this->Options = [];
        return $this;
    }

	/**
	 * Устанавливает Модель для декорирования
	 * 
	 * @param ModelInterface $Model
	 * @return DecoratorInterface
	 */
    public function setModel(ModelInterface $Model): DecoratorInterface
    {
        $this->Model = $Model;
        return $this;
    }
	
    /**
     * Возвращает текущую модель
     *
     * @return ModelInterface
     */
    public function getModel(): ModelInterface
    {
        return $this->Model;
    }
	
	
}