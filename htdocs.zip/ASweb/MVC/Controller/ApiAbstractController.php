<?php
namespace ASweb\MVC\Controller;

use ASweb\HTTP\Request;
use ASweb\HTTP\Response;

abstract class ApiAbstractController extends AbstractController
{
    protected $data;

    public function __construct(array $config)
    {
    }

    /**
     * @param Request $request
     * 
     * @return Response
     */
    public function handle(Request $request): Response
    {
        $this->request = $request;
        $this->args = $this->request->args();
        
        $postData = file_get_contents('php://input');
        $json_array = json_decode($postData, true);
        if (!is_array($json_array)) {
            $json_array = [];
        }
        $this->request->setJson($json_array);
        
        $action = $this->route();
        $this->response = Response::getInstance();
        $this->$action();
        return $this->response;
    }

    abstract public function route();

}