<?php
namespace ASweb\MVC\Controller;

use ASweb\HTTP\Request;
use ASweb\HTTP\Response;
use ASweb\MVC\App;
use ASweb\MVC\View\View;

abstract class AbstractController
{
    /**
     * @var Request
     */
    protected $request;

    /**
     * @var Response
     */
    protected $response;

    /**
     * @var View
     */
    protected $view;
        
    /**
     * @var array
     */
    protected $args;

    public function __construct(array $config)
    {
        $viewPath = App::path().'/app/view';

        $this->view = new View($viewPath);

        foreach ($config as $k => $v) {
            $this->view->{$k} = $this->{$k} = $v;
        }    
    }

    /**
     * @param Request $request
     * 
     * @return Response
     */
    public function handle(Request $request): Response
    {
        $this->request = $request;
        $this->view->args = $this->args = $this->request->args();
            
        $action = $this->route();
        $this->response = Response::getInstance();
        $this->$action();
        return $this->response;
    }

    //abstract public function route();

}