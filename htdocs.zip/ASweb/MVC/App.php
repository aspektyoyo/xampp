<?php
namespace ASweb\MVC;

use ASweb\HTTP\Request;
use ASweb\HTTP\Response;

class App
{
    protected static $instance = null;
    
    private $controller;
    private $config;

    private function __construct(array $config)
    {
        $this->config = $config;
    } 

    public static function getInstance(array $config): App
    {
        if (is_null(self::$instance)) {
            self::$instance = new self($config);
        } 

        return self::$instance;
    }

    public function run(Request $request): Response
    {
        if ($request->args()[0] == 'api' && in_array($request->controller(), $this->config['api'])) {
            $controller = "Controller\\Api\\".$request->controller();
        } elseif (in_array($request->controller(), $this->config['controllers'])) {
            $controller = "Controller\\".$request->controller();
        } else {
            $controller = "Controller\\Page";
        }

        $this->controller = new $controller ($this->config);  
        $response = $this->controller->handle($request); 
        return $response;
    }

    public static function path()
    {
        return $_SERVER['DOCUMENT_ROOT'];
    }
    
    private function __clone()
    {
    }

    private function __wakeup()
    {
    }
}