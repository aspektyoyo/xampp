<?php
namespace ASweb\Lang;

class Lang
{
    public static $default;
    public static $lang;
    public static $id;
    public static $intname;
    public static $langs;
}