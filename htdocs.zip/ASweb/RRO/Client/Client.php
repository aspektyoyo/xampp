<?php

namespace ASweb\RRO\Client;

use Env;
use ASweb\RRO\Server\RRO;
use ASweb\RRO\Client\Response;
use ASweb\RRO\Exception\Error;
use ASweb\RRO\Exception\Offline;
use Exception;
use Model\Answer;
use Model\Document;
use Model\OfflineNumber;

class Client
{
    const METHOD_PING = 'ping';
    const METHOD_TO_ONLINE = 'toOnline';
    const METHOD_AUTH = 'auth';
    const METHOD_OPEN = 'openShift';
    const METHOD_ZREPORT = 'zReport';
    const METHOD_XREPORT = 'xReport';
    const METHOD_SERVICE_INPUT = 'ServiceInput';
    const METHOD_SERVICE_OUTPUT = 'ServiceOutput';
    const METHOD_SALE = 'sale';
    const METHOD_RETURN = 'saleReturn';
    const METHOD_SEND_CHECK = 'send';
    const METHOD_GET_OFFLINE_IDS = 'getOfflineIds';
    const METHOD_INSTALL = 'install';

    public static function get (string $endpoint, array $request = []): string
    {
        $ch = curl_init(Env::server_url().$endpoint."?token=".RRO::getInstance()->getToken());
        
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FAILONERROR, true);
        curl_setopt($ch, CURLOPT_MAXCONNECTS, 1);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        
        $result = curl_exec($ch);
        curl_close($ch);

        return $result;
    }

    public static function send (int $check_id, string $type, array $request, $from_db = false): Response
    {
        if ($from_db == false) {
            $request['tstamp'] = RRO::getInstance()->getTime();
            //Если предыдущие документы не отослались, то вся передача не удалась. Значит нет связи с сервером
            if (!self::sendPrevious($check_id)) {
                throw new Offline('Предыдущие документы не отослались');
            }
        }

        $request['md5'] = md5(base64_encode(json_encode($request, JSON_UNESCAPED_UNICODE)).RRO::getInstance()->getTime());        
        $json_data = json_encode($request);
        
        $url = Env::server_url().self::get_url($type)."?token=".RRO::getInstance()->getToken();
        $ch = curl_init($url);
        
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FAILONERROR, true);
        curl_setopt($ch, CURLOPT_MAXCONNECTS, 1);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        if (isset($_GET['timeout']) && $_GET['timeout']) {
            curl_setopt($ch, CURLOPT_TIMEOUT, intval($_GET['timeout']));
        }
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
  
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
        $result = curl_exec($ch);
        curl_close($ch);

        if($result === false) {
            RRO::getInstance()->toOffline();
            throw new Offline('Нет связи с сервером');
        } else {        
            RRO::getInstance()->toOnline();
            $Answer = new Answer();
            $Answer->insert ([
                "tstamp" => time(),
                "request" => $json_data,
                "answer" => $result,
            ]);

            if (json_decode($result, true)) {
                $server_response = json_decode($result, true);
                $response = new ArrayResponse(json_decode($result, true));

                // Если на сервере чек сохранен в офлайн цепочку, то отмечаем этот Оффлайн Id как использованый
                if ($server_response['is_offline'] && $server_response['ORDERNUM']) {
                    RRO::getInstance()->useOfflineFN((string) $server_response['ORDERNUM']);
                }

                // Сохраняем новые Оффлайн Id с сервера
                if (count($server_response['offline_ids'])) {
                    try {
                        $OfflineId = new OfflineNumber();
                        $OfflineId->delete(["where" => "rro = ".RRO::getInstance()->getId()]);
                        foreach ($server_response['offline_ids'] as $off_id) {
                            $OfflineId->insert([
                                "rro" => RRO::getInstance()->getId(),
                                "fn" => $off_id,
                                "used" => 0,
                                "use_tstamp" => 0,
                            ]);
                        }
                    } catch (Exception $e) {

                    }

                    RRO::getInstance()->useOfflineFN((string) $response->response()['ORDERNUM']);

                    if ($server_response['ERROR']) {
                        if ($server_response['ERROR'] == 'Check Duplicate' && $check_id) {
                            RRO::getInstance()->useOfflineFN((string) $server_response['ORDERNUM']);
                            RRO::getInstance()->saveCheck($check_id, $server_response['ORDERNUM'], 1);
                        }
                        throw new Offline($server_response['ERROR']);
                    }
                }

                RRO::getInstance()->saveState($response->is_offline);
            } else {
                throw new Offline('Нет связи с сервером');
            }
        }
        return $response;
    }
    
    public static function sendPrevious(int $check_id): bool
    {
        $MDocument = new Document();
        $documents_to_send = $MDocument->getall(["where" => "`rro` = ".RRO::getInstance()->getId()." and `sync` = 0 and id != ".$check_id, "order" => "id asc"]);        
        if (count($documents_to_send)) {
            foreach ($documents_to_send as $check) {
                try {
                    $request = json_decode(base64_decode($check->request), true);
                    
                    if ($request) {
                        $request['fn'] = $check->fiscal_number;
                        $request['is_offline'] = $check->is_offline;
                        $request['action'] = $check->action_type;
                        $request['tstamp'] = $check->tstamp;
                        $request['time_string'] = $check->time_string;
                    } else {
                        $request = [];
                        continue;
                    }
                    
                    $result = Client::send($check->id, $check->action_type, $request, true)->response();
                    if ($result["ORDERNUM"]) {
                        $MDocument->save(
                            [
                                "sync" => 1,
                            ], $check->id);
                    } else {                        
                        throw new Offline("Передача предыдущих чеков не удалась");
                    }
                } catch (Offline $e) {
                    if ($_GET['force']) {
                        $MDocument->save(
                            [
                                "sync" => 1,
                                "error" => 1,
                            ], $check->id);
                        continue;
                    } else {
                        return false;
                    }
                } catch (Error $e) {
                    // Если на сервере такой чек уже есть, то отмечаем его как sync=1
                    if ($e->getMessage() == "Check Duplicate") {
                        $MDocument->save(
                            [
                                "sync" => 1,
                                "error" => 1,
                            ], $check->id);
                    }
                    continue;
                }
            }
        }
        return true;
    }

    public static function checkFn (string $token, string $local_number): string
    {
        $fn = '';
        $url = Env::server_url()."/api/export/json"."?local_number=".$local_number."&token=".RRO::getInstance()->getToken();
        $ch = curl_init($url);
        
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FAILONERROR, true);
        curl_setopt($ch, CURLOPT_MAXCONNECTS, 1);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);        
        $result = curl_exec($ch);
        curl_close($ch);

        if($result === false) {
            throw new Offline('Нет связи с сервером');
        } else {
            if (json_decode($result, true)) {
                $server_response = json_decode($result, true);
                $fn = (string) $server_response[0]['fn'];
                return $fn;
            } else {
                return "";
            }
        }

        return $fn;
    }

    public static function get_url (string $type): string
    {        
        $urls = [
            'auth' => '/api/authenticate',
            'ping' => '/api/shift/ping',
            'toOnline' => '/api/check/toOnline',
            'getOfflineIds' => '/api/shift/getOfflineIds',
            'xReport' => '/api/shift/xReport',
            'openShift' => '/api/check/open-shift',
            'zReport' => '/api/check/zReport',            
            'ServiceInput' => '/api/check/service-input',
            'ServiceOutput' => '/api/check/service-output',
            'sale' => '/api/check/sale',
            'saleReturn' => '/api/check/sale-return',
            'send' => '/api/check/send-to-customer',
        ];

        return strval($urls[$type]);
    }
}