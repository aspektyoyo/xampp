<?php

namespace ASweb\RRO\Client;

use Func;
use ASweb\RRO\Server\RRO;
use ASweb\RRO\Client\Document;

class Response
{
    public $shift_state = 0;
    public $last_num_fiscal = '';
    public $is_offline = false;
    public $SERVER_TIME = '';
    public $OPEN_SESSION_TIME  = '';
    public $start_offline_time = '';
    public $ERROR = null;
    public $ORDERNUM = '';
    public $MAC = '';
    public $local_number = 0;
            
    protected $response = [];

    public function __construct(string $fn = '')
    {
        if ($fn) {
            $this->ORDERNUM = $fn;
        }
    }

    protected function checkUrl(): string
    {
        // $url = ($this->ORDERNUM) ? 'https://cabinet.tax.gov.ua/cashregs/check?id='.$this->ORDERNUM.'&date='.date("Ymd", RRO::getInstance()->getTime()) : "";
        $url = ($this->ORDERNUM) ? 'https://e-cash.e-dorado.com.ua/api/checkinfo/redirect?fn='.$this->ORDERNUM : "";
        return $url;
    }

    public function response()
    {
        $this->response["ORDERNUM"] = $this->ORDERNUM;
        $this->response["ORDERDATE"] = Func::fmt_date(RRO::getInstance()->getTime());
        $this->response["ORDERTIME"] = Func::fmt_time(RRO::getInstance()->getTime());
        $this->response["is_offline"] = RRO::getInstance()->isOffline();
        $this->response["shift_state"] = RRO::getInstance()->isShiftOpened();
        $this->response["last_local_number"] = RRO::getInstance()->getLastLocalNumber();
        $this->response["link"] = $this->checkUrl();
        $this->response["ERROR"] = $this->ERROR;

        return $this->response;        
    }

    public function __toString()
    {
        return (string) json_encode($this->response(), JSON_UNESCAPED_UNICODE);
    }
}