<?php

namespace ASweb\RRO\Client;

class ArrayResponse extends Response
{   
    public function __construct(array $response)
    {
        $this->response = $response;
        parent::__construct((string) $response['ORDERNUM']);
    }
}