<?php

namespace ASweb\RRO\Client;

class ErrorResponse extends Response
{
    public $shift_state = 0;
    public $last_num_fiscal = '';
    public $is_offline = false;
    public $SERVER_TIME = '';
    public $OPEN_SESSION_TIME  = '';
    public $start_offline_time = '';
    public $ERROR = null;
    public $ORDERNUM = '';
    public $ORDERDATE = '';
    public $ORDERTIME = '';
    public $MAC = '';
    public $local_number = 0;
            
    public function __construct(string $error, string $fn = '')
    {
        $this->ERROR = $error;
        parent::__construct($fn);
    }
}