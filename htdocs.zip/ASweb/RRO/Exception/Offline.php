<?php

namespace ASweb\RRO\Exception;

class Offline extends \Exception
{
    
}