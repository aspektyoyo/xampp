<?php

namespace ASweb\RRO\Exception;

class Error extends \Exception
{
    
}