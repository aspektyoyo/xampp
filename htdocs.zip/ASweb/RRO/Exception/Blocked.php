<?php

namespace ASweb\RRO\Exception;

class Blocked extends \Exception
{
    
}