<?php

namespace ASweb\RRO\Service;

use Model\Document;

class ClearBase
{
    public static function clear(int $rro)
    {
        $Document = new Document();
        $Document->delete(["where" => "rro = $rro and tstamp < ".(time() - 5 * 86400)." and sync = 1"]);        
    }
}