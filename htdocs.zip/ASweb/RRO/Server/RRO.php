<?php
namespace ASweb\RRO\Server;

use Env;
use Func;
use ASweb\Auth\Auth;
use ASweb\Db\DBException;
use ASweb\Db\Entity;
use ASweb\Time\Time;
use Model\OfflineNumber;

use Model\Rro as ModelRRO;
use ASweb\RRO\Client\Client;
use Model\User as ModelUser;
use ASweb\RRO\Client\Document;
use ASweb\RRO\Client\Response;
use Model\Shift as ModelShift;
use ASweb\RRO\Server\Shift as Shift;
use Model\Document as ModelDocument;
use ASweb\RRO\Server\Document as ServerDocument;
use Model\OfflineSession as ModelOfflineSession;
use ASweb\RRO\Server\OfflineSession as OfflineSession;

class RRO
{
    private static $instance = null;
    private $_Shift;
    private $_OfflineSession;
    private $_Time;

    private $_token;

    private $RRO;
    private $user;

    public function isBussy(): int
    {
        if ($this->RRO->bussy) {
            return 1;
        } else {
            return 0;
        }
    }

    public function isOnline(): int
    {
        if ($this->RRO->offline == 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public function isNoInternet(): int
    {
        if ($this->RRO->no_internet) {
            return 1;
        } else {
            return 0;
        }
    }

    public function isOffline(): int
    {
        if ($this->RRO->offline || $this->RRO->no_internet) {
            return 1;
        } else {
            return 0;
        }
    }

    public function setOffline (int $offline)
    {
        $this->RRO->no_internet = $offline;
        $this->RRO->offline = $offline;
    }

    public function setNoInternet (int $no_internet)
    {
        $this->RRO->no_internet = $no_internet;
    }

    public function isBlocked(): int
    {
        $timer36 = $this->RRO->timer36 + time() - $this->RRO->timer_updated;
        $timer168 = $this->RRO->timer168 + time() - $this->RRO->timer_updated;
        
        if ($this->RRO->offline && ($timer36 > 129600 || $timer168 > 604800)) {
            return 1;
        } else {
            return 0;
        }
    }
    
    public function endTransaction()
    {
        $this->setBussy(0);
    }

    public function startTransaction()
    {
        $this->setBussy(0);
    }

    private function setBussy(int $status)
    {
        if (Env::is_test())
        {
            return;
        }

        $ModelRRO = new ModelRRO();
        $id = $this->getId();
        $ModelRRO->save([
            "bussy" => $status,
        ], $id);
    }

    public function toOffline()
    {
        $this->RRO->no_internet = 1;
        $ModelRRO = new ModelRRO();
        $id = $this->getId();
        $ModelRRO->save([
            "no_internet" => 1,
            "last_online" => RRO::getInstance()->getTime(),
        ], $id);

        $response['error'] = "Нет связи с сервером";
        return $response;
    }

    public function toOnline()
    {       
        // Переводим РРО в режим "Есть интернет". Не путать с Онлайн (есть связь с налоговой)!!!
        $this->RRO->no_internet = 0;

        $ModelRRO = new ModelRRO();
        $id = $this->getId();
        $ModelRRO->save([
            "no_internet" => 0,
        ], $id);

        $response = ["status" => "to online local"];
        return $response;
    }

    public function getTime(): int
    {
        return Time::getInstance()->getTime();
    }

    public function getTimeString(): int
    {
        return Time::getInstance()->getTimeString();
    }

    public function getToken()
    {
        return $this->_token;
    }

    public function getId(): int
    {
        return intval($this->RRO->id);
    }

    public function getFN()
    {
        return $this->RRO->num_fiscal;
    }

    public function getINN()
    {
        return $this->user->inn;
    }

    public function getTin()
    {
        return $this->RRO->tin;        
    }

    public function getDI()
    {
        return $this->RRO->di;
    }

    public function getUserId()
    {
        return (int) $this->user->id;
    }

    public function getLocalNumber()
    {
        return intval($this->getLastLocalNumber() + 1);
    }

    public function getLastCheck(array $request): array
    {
        return $this->_Shift->getLastCheck($request);
    }

    public function getLastFiscalNumber(): string
    {
        $ModelDocument = new ModelDocument();
        $fiscal_number = (string) $ModelDocument->getone(['where' => "`rro` = ".RRO::getInstance()->getId(), "order" => "local_number desc"])->fiscal_number;
        
        return $fiscal_number;
    }
    
    public function getLastLocalNumber(): int
    {
        $ModelDocument = new ModelDocument();
        $fiscal_number = (int) $ModelDocument->getone(['where' => "`rro` = ".RRO::getInstance()->getId(), "order" => "local_local_number desc"])->local_local_number;
        
        return $fiscal_number;
    }
// ------ Shift Functions -------------------------------------------------------

    public function openShift()
    {
        $shift_number = intval(RRO::getInstance()->getlastShiftNumber() + 1);
        if (!RRO::getInstance()->isShiftOpened()) {
            $Shift = new ModelShift();
            $Shift->insert([
                "rro" => RRO::getInstance()->getId(),
                "opened" => 1,
                "open_tstamp" => Time::getInstance()->getTstamp(),
                "cashier" => RRO::getInstance()->getUserId(),
                "balance_open" => RRO::getInstance()->getLastShiftBalance(),
                "shift_number" => $shift_number,
            ]);

            $this->RRO->shift = $shift_number;
            $this->RRO->shift_opened = 1;
            $ModelRRO = new ModelRRO();
            $ModelRRO->save([
                "shift" => $shift_number,
                "shift_opened" => 1,
            ], RRO::getInstance()->getId());
        }        
    }

    public function closeShift(Entity $check)
    {
        if (RRO::getInstance()->isShiftOpened()) {
            $report = Shift::getInstance()->getReport2();
            
            $Shift = new ModelShift();
            $Shift->save([
                "opened" => 0,
                "close_tstamp" => Time::getInstance()->getTstamp(),
                "balance_close" => round($report["cash_in_box"], 2),
                ], RRO::getInstance()->getCurrentShiftId()
            );

            $request = json_decode(base64_decode($check->request), true);
            $request['report'] = $report;
            $Document = new ModelDocument();
            $Document->save([
                "request" => base64_encode(json_encode($request))
            ], $check->id);

            $this->RRO->shift = 0;
            $this->RRO->shift_opened = 0;
            $ModelRRO = new ModelRRO();
            $ModelRRO->save([
                "shift" => 0,
                "shift_opened" => 0,
            ], RRO::getInstance()->getId());

            $ModelDocument = new ModelDocument();
            $fn = '';
            $action = Client::METHOD_OPEN;
            $tstamp = Time::getInstance()->getTstamp();
            $time_string = Time::getInstance()->getTimeString();
            $is_offline = 1;
            $sent = 0;
            $deleted = 3;
            $local_local_number = 0;
            $request = [];

            // Сохраняем Документ
            $ModelDocument->insert([
                "rro" => RRO::getInstance()->getId(),
                "shift" => RRO::getInstance()->getCurrentShiftNumber(),
                "action_type" => $action,
                "fiscal_number" => $fn,
                "name" => "",
                "tstamp" => $tstamp,                
                "time_string" => $time_string,
                "sent" => $sent,
                "request" => base64_encode(json_encode($request)),
                "response" => "",
                "xml" => "",
                "hash" => "",
                "is_offline" => $is_offline,
                "url" => '',
                "local_number" => 0,
                "local_local_number" => $local_local_number,
                "md5" => md5(base64_encode(json_encode($request)).Time::getInstance()->getTstamp()),
                "last" => 1,
                "is_deleted" => $deleted,
            ]);
        }        
    }

    public function getShiftBalance(int $shift_id): float
    {
        $Shift = new ModelShift();        
        $shift = $Shift->getone(["where" => "rro = ".RRO::getInstance()->getId()." and shift_number = ".$shift_id]);
        
        return round(floatval($shift->balance_close), 2);
    } 

    public function getShiftOpenTime(): int
    {
        return (int) $this->currentShift->open_tstamp;
    }

    public function getOfflineStartTime(): int
    {
        return (int) $this->RRO->last_online;
    }

    public function getlastShift()
    {
        return $this->lastShift;
    }

    public function isShiftOpened(): int
    {
        return (int) $this->currentShift->opened;
        //$this->RRO->shift_opened;
    }
    
    public function getCurrentShiftNumber(): int
    {
        return (int) $this->RRO->shift;
    }

    public function getTimerDuplicate(): int
    {
        return (int) $this->RRO->timer_duplicate;
    }

    public function getCurrentShift()
    {
        return $this->currentShift;
    }

    public function getLastShiftBalance(): float
    {
        return round(floatval($this->lastShift->balance_close), 2);
    }   

    public function getCurrentShiftId(): int
    {
        return (int) $this->currentShift->id;
    }

    public function lastShiftId(): int
    {
        return (int) $this->lastShift->id;
    }

    public function getlastShiftNumber(): int
    {
        return (int) $this->lastShift->shift_number;
    }

//---- Offline Session --------------------------------
    public function getOfflineNumber(): string
    {
        return $this->_OfflineSession->getOfflineNumber();
    }

    public function getOfflineFN(): string
    {
        $OfflineNumber = new OfflineNumber();
        $fn = (string) $OfflineNumber->getone(["where" => "`used` = 0 and rro = ".RRO::getInstance()->getId(), "order" => "id desc"])->fn;
        $this->useOfflineFN($fn);
        return $fn;
    }

    public function useOfflineFN(string $fn)
    {
        $OfflineNumber = new OfflineNumber();
        $OfflineNumber->update([
            "used" => 1,
            "use_tstamp" => RRO::getInstance()->getTime(),
        ], ["where" => "`fn` = '".$fn."'"]);
    }

    public function getOfflineDocuments(): array
    {
        return $this->_OfflineSession->getOfflineDocuments();
    }

    public function signAccessToken(): string
    {
        return $this->RRO->token;
    }

//---- Save ----------------------------------------------
    public static function saveRequest (string $action, array $request): int
    {
        $ModelDocument = new ModelDocument();
        $local_number = RRO::getInstance()->getLocalNumber();
        $request['tstamp'] = RRO::getInstance()->getTime();
        $request['is_offline'] = RRO::getInstance()->isOffline();

        $ModelDocument->update([
            "last" => 0,
        ], ["where" => "`rro` = ".RRO::getInstance()->getId()]);
        
        // Сохраняем Документ
        $ModelDocument->insert([
            "rro" => RRO::getInstance()->getId(),
            "user" => (int) RRO::getInstance()->getUserId(),
            "shift" => RRO::getInstance()->getCurrentShiftNumber(),
            "action_type" => $action,
            "fiscal_number" => (string) $request['fn'],
            "name" => "",
            "tstamp" => RRO::getInstance()->getTime(),
            "time_string" => RRO::getInstance()->getTimeString(),
            "sync" => 0,
            "request" => base64_encode(json_encode($request, JSON_UNESCAPED_UNICODE)),
            "response" => "",
            "xml" => "",
            "hash" => "",
            "is_offline" => RRO::getInstance()->isOffline(),
            "url" => '',
            "local_number" => $local_number,
            "local_local_number" => (int) $request['local_number'],
            "md5" => md5(base64_encode(json_encode($request, JSON_UNESCAPED_UNICODE)).RRO::getInstance()->getTime()),
            "last" => 1,
        ]);

        $id = $ModelDocument->last_id();

        return $id;
    }

    public static function saveCheck (int $check_id, string $fn, int $sent): int
    {
        $ModelDocument = new ModelDocument();
        $check = $ModelDocument->get($check_id);
        $request['tstamp'] = RRO::getInstance()->getTime();
        $request['is_offline'] = RRO::getInstance()->isOffline();

        $ModelDocument->update([
            "last" => 0,
        ], ["where" => "`rro` = ".RRO::getInstance()->getId()]);
        
        // Сохраняем Документ
        $ModelDocument->save([
            "fiscal_number" => $fn,
            "tstamp" => RRO::getInstance()->getTime(),
            "time_string" => RRO::getInstance()->getTimeString(),
            "sync" => $sent,
            "is_offline" => RRO::getInstance()->isOffline(),
        ], $check_id);

        return $check->local_number;
    }

    public static function saveState(int $is_offline)
    {
        $MRRO = new ModelRRO();
        $MRRO->save([
            "offline" => $is_offline,
        ], RRO::getInstance()->getId());        
    }
// ------------------------------------------------------------
    public function authByToken (string $token): bool
	{			
		$User = new ModelUser();
        $this->_token = $token;

		$this->user = $User->getone(["where" => "`token` = '".$this->_token."'"]);
		if ($this->user) {
            Auth::setToken($this->_token);

            $this->init();
			return true;
		} else {
			return false;
		}
	}
	
    public function init()
    {
        $Rro = new ModelRRO();
        $this->RRO = $Rro->get($this->user->rro);

        $ModelShift = new ModelShift();
        $this->lastShift = $ModelShift->getone(["where" => "`rro` = ".RRO::getInstance()->getId(), "order" => "id desc"]);
        $this->currentShift = $ModelShift->getone(["where" => "`opened` = 1 and `rro` = ".RRO::getInstance()->getId(), "order" => "id desc"]);
    }

    public static function getInstance(): RRO
    {
        if (static::$instance === null) {
            static::$instance = new static();
        }

        return static::$instance;
    }    
    
	private function __construct()
    {
		
    }

    private function __clone()
    {
    }
    
    public function __wakeup()
    {
        throw new \Exception("Cannot unserialize singleton RRO");
    }
}