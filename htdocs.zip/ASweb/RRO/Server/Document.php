<?php

namespace ASweb\RRO\Server;

use ASweb\Db\Entity;
use ASweb\RRO\Client\Client;

class Document
{
    public static function getTaxes(Entity $check)
    {
        $taxes = [];

        $request = json_decode(base64_decode($check->request), true);
        $products = $request['products'];
        
        foreach ($products as $prod) {
            $k = $prod['excise_prc']."_".$prod['tax_prc'];
            if (!isset($taxes[$k])) {
                $taxes[$k] = [
                    'excise_prc' => 0,
                    'excise' => 0,
                    'prc' => 0,
                    'turnover' => 0,
                    'sum' => 0,
                ];
            }

            if (floatval($prod['excise_prc']) > 0) {
                $excise = (float) $prod['excise'];                
                $sum = round(floatval($prod['cost'] + $prod['sum_discount'] - $excise), 2);
                $t = round(($sum * $prod['tax_prc'] / (100 + $prod['tax_prc'])), 2);

                $taxes[$k]['excise_prc'] = round((float) $prod['excise_prc']);
                $taxes[$k]['excise'] += round($excise, 2);
                $taxes[$k]['prc'] = round($prod['tax_prc']);
                $taxes[$k]['turnover'] += round($sum, 2);
                $taxes[$k]['sum'] += round($t, 2);                
            } else {
                $sum = round(floatval($prod['cost'] + $prod['sum_discount']), 2);
                $t = round(($sum * $prod['tax_prc'] / (100 + $prod['tax_prc'])), 2);

                $taxes[$k]['prc'] = round($prod['tax_prc']);
                $taxes[$k]['turnover'] += round($sum, 2);
                $taxes[$k]['sum'] += round($t, 2);
            }
        }

        return $taxes;
    }

    public static function getProducts(Entity $check)
    {
        $products = [];
        $request = json_decode(base64_decode($check->request), true);

        foreach ($request['products'] as $k => $p) {
            $oldprice = round(floatval($p['price']), 2);
            $discount = round(floatval($p['sum_discount']), 2);
            $cost = floatval($p['cost']) + floatval($p['sum_discount']);
            $num = round(floatval($p['amount']), 3);
            $price = $cost / $num;
            $p['cost'] = round($cost, 2);
            $p['price'] = round($price, 2);
            $p['oldprice'] = $oldprice;
            $p['discount'] = $discount;
            $products[] = $p;
        }
        
        return $products;
    }

    public static function getSum(Entity $check): float
    {
        if ($check->action_type == Client::METHOD_SERVICE_INPUT || $check->action_type == Client::METHOD_SERVICE_OUTPUT) {
            $request = json_decode(base64_decode($check->request), true);
            $sum = (float) $request['sum'];
            return round($sum, 2);
        }

        $request = json_decode(base64_decode($check->request), true);
        $sum = (float) $request['total_sum'];

        return round($sum, 2);
    }

    public static function getPayments(Entity $check): array
    {
        $payments = [];
        $request = json_decode(base64_decode($check->request), true);
        $payments = $request['payments'];

        if (!isset($payments) || empty($payments)) {
            return [];
        }

        foreach ($payments as $k => $payment) {
            $sum = round(floatval($payment['sum']), 2);
            $round_in_request = (float) $payment['sum_round'];

            if ((int) $payment['code'] == 0 && $round_in_request) {
                $payments[$k]['sum'] = round($payment['sum'], 2);
                if ($round_in_request > 0) {
                    $payments[$k]['round_up'] = abs($round_in_request);
                    $payments[$k]['round_down'] = 0;
                } else {
                    $payments[$k]['round_up'] += 0;
                    $payments[$k]['round_down'] += abs($round_in_request);
                }
            } elseif ((int) $payment['code'] == 0) {
                $s = round($sum, 2);

                if ($payment['noround'] == 1) {
                    $r = 0;
                } else {
                    $r = $s >= 0.1 ? round(round($sum, 1) - $s, 2) : round(0.1 - $s, 2);
                }
            
                if ($r > 0) {
                    $payments[$k]['round_up'] += round(abs($r), 2);
                    $payments[$k]['round_down'] += 0;
                } else {
                    $payments[$k]['round_up'] += 0;
                    $payments[$k]['round_down'] += round(abs($r), 2);
                }

                if ($payment['noround'] == 1) { 
                    $payments[$k]['sum'] = round($sum, 2);
                } else {
                    $payments[$k]['sum'] = ($sum >= 0.1) ? round($sum, 1) : 0.1;
                }
            } else {
                $payments[$k]['sum'] = round($sum, 2);
            }
        }

        return $payments;
    }

    public static function getTotal(Entity $check): float
    {
        $total = 0;
        $payments = static::getPayments($check);
        foreach ($payments as $k => $v) {
            $total += $v['sum'];
        }

        return round($total, 2);
    }

    public static function getTurnover(Entity $check): float
    {
        $turnover = 0;
        $taxes = static::getTaxes($check);
        foreach ($taxes as $k => $v) {
            $turnover += $v['turnover'];
        }

        return $turnover;
    }

    public static function getRound(Entity $check): float
    {
        $round = 0;
        $payments = static::getPayments($check);
        foreach ($payments as $k => $v) {
            $round += ($v['round_up'] + $v['round_down']);
        }

        return round($round, 2);
    }

    public static function getDiscount(Entity $check): float
    {
        $request = json_decode(base64_decode($check->request), true);
        $products = $request['products'];
        $discount = 0;

        foreach ($products as $prod) {
            $discount += (float) $prod['sum_discount'];
        }
        
        return round($discount, 2);
    }

    public static function getProdNum(Entity $check): int
    {
        $request = json_decode(base64_decode($check->request), true);
        $prod_num = count($request['products']);

        return $prod_num;
    }
}