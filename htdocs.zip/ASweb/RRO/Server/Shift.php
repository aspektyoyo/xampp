<?php
namespace ASweb\RRO\Server;

use Func;
use ASweb\RRO\Server\RRO;
use ASweb\RRO\Client\Client;
use Model\Document as ModelDocument;
use Model\Shift as ModelShift;

class Shift
{
    private static $instance = null;
    
    public function getReport2(int $rro = 0, int $shift = 0, bool $only_sent = false, bool $admin = false): array
    {
        $shift_number = ($shift > 0) ? $shift : RRO::getInstance()->getCurrentShiftNumber();        
        $rro_id = ($rro > 0) ? $rro : RRO::getInstance()->getId();             
        $open_balance = RRO::getInstance()->getShiftBalance($shift_number - 1);
        
        $Document = new ModelDocument();
        
        if ($only_sent) {
            $docs = $Document->getall([
                "where" => "`shift` = ".$shift_number." and `sent` = 1 and (action_type = '".Client::METHOD_SALE."' or action_type = '".Client::METHOD_RETURN."' or action_type = '".Client::METHOD_SERVICE_INPUT."' or action_type = '".Client::METHOD_SERVICE_OUTPUT."') and rro = ".$rro_id." and is_deleted = 0",
                "order" => "id"
            ]);
        } else {
            $docs = $Document->getall([
                "where" => "`shift` = ".$shift_number." and (action_type = '".Client::METHOD_SALE."' or action_type = '".Client::METHOD_RETURN."' or action_type = '".Client::METHOD_SERVICE_INPUT."' or action_type = '".Client::METHOD_SERVICE_OUTPUT."') and rro = ".$rro_id." and is_deleted = 0",
                "order" => "id"
            ]);
        }
        
        $numbers = [];
        foreach ($docs as $k => $v) {
            if (in_array($v->local_local_number, $numbers)) {
                unset($docs[$k]);
            } else {
                $numbers[] = $v->local_local_number;
            }            
        }

        $report = [
            "cash_in_box" => round($open_balance, 2),
            "real" => [
                "sum" => 0,
                "orders_count" => 0,
                "pay_form" => [
                    0 => [
                        "pay_form_code" => "0",
                        "pay_form_name" => "ГОТIВКА",
                        "sum" => 0,
                        "round_up" => 0,
                        "round_down" => 0,
                    ],
                    1 => [
                        "pay_form_code" => "1",
                        "pay_form_name" => "БЕЗГОТІВКА.1",
                        "sum" => 0
                    ],
                    2 => [
                        "pay_form_code" => "2",
                        "pay_form_name" => "БЕЗГОТІВКА.2",
                        "sum" => 0
                    ],
                    3 => [
                        "pay_form_code" => "3",
                        "pay_form_name" => "БЕЗГОТІВКА.3",
                        "sum" => 0
                    ]
                ],
                "tax" => [
                    20 => [
                        "name" => "ПДВ 20%",
                        "letter" => "А",
                        "prc" => 20,
                        "turnover" => 0,
                        "sum" => 0,
                        "excise" => [

                        ],
                    ],
                    7 => [
                        "name" => "ПДВ 7%",
                        "letter" => "Б",
                        "prc" => 7,
                        "turnover" => 0,
                        "sum" => 0,
                        "excise" => [

                        ],
                    ],
                    0 => [
                        "name" => "ПДВ 0%",
                        "letter" => "В",
                        "prc" => 0,
                        "turnover" => 0,
                        "sum" => 0,
                        "excise" => [

                        ],
                    ],
                    'excise' => [

                    ],
                ],                
            ],
            "ret" => [
                "sum" => 0,
                "orders_count" => 0,
                "pay_form" => [
                    0 => [
                        "pay_form_code" => "0",
                        "pay_form_name" => "ГОТIВКА",
                        "sum" => 0,
                        "round_up" => 0,
                        "round_down" => 0,
                    ],
                    1 => [
                        "pay_form_code" => "1",
                        "pay_form_name" => "БЕЗГОТІВКА.1",
                        "sum" => 0
                    ],
                    2 => [
                        "pay_form_code" => "2",
                        "pay_form_name" => "БЕЗГОТІВКА.2",
                        "sum" => 0
                    ],
                    3 => [
                        "pay_form_code" => "3",
                        "pay_form_name" => "БЕЗГОТІВКА.3",
                        "sum" => 0
                    ]
                ],
                "tax" => [
                    20 => [
                        "name" => "ПДВ 20%",
                        "letter" => "А",
                        "prc" => 20,
                        "turnover" => 0,
                        "sum" => 0,
                        "excise" => [

                        ],
                    ],
                    7 => [
                        "name" => "ПДВ 7%",
                        "letter" => "Б",
                        "prc" => 7,
                        "turnover" => 0,
                        "sum" => 0,
                        "excise" => [

                        ],
                    ],
                    0 => [
                        "name" => "ПДВ 0%",
                        "letter" => "В",
                        "prc" => 0,
                        "turnover" => 0,
                        "sum" => 0,
                        "excise" => [

                        ],
                    ],
                    'excise' => [

                    ],
                ],                
            ],
            "service_input" => 0,
            "service_output" => 0,
            "cash_in_box_start" => round($open_balance, 2),
        ];
  
        foreach ($docs as $doc) {
            $doctype = $doc->action_type;
            //$doc = json_decode(base64_decode($doc->request), true);

            if ($doctype == Client::METHOD_SALE) {
                $payments = Document::getPayments($doc);
                $taxes = Document::getTaxes($doc);

                $report['real']['orders_count']++;

                foreach ($taxes as $tax_key => $tax) {
                    if ($tax['excise_prc']) {
                        $report['real']['tax']['excise'][$tax['excise_prc']]['excise'] += round($tax['excise'], 2);
                        $report['real']['tax']['excise'][$tax['excise_prc']]['excise_prc'] = $tax['excise_prc'];
                        $report['real']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['excise'] += round($tax['excise'], 2);
                        $report['real']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['excise_prc'] = $tax['excise_prc'];
                        $report['real']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['tax_turnover'] += round($tax['turnover'], 2);
                        $report['real']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['tax_sum'] += round($tax['sum'], 2); 
                    }

                    $report['real']['tax'][$tax['prc']]['turnover'] += round($tax['turnover'], 2);
                    $report['real']['tax'][$tax['prc']]['sum'] += round($tax['sum'], 2);                 
                }
                
                foreach ($payments as $payform) {                    
                    $report['real']['pay_form'][$payform['code']]['round_up'] += round(abs($payform['round_up']), 2);
                    $report['real']['pay_form'][$payform['code']]['round_down'] += round(abs($payform['round_down']), 2);
                    $report['real']['pay_form'][$payform['code']]['sum'] += round($payform['sum'], 2);
                    $report['real']['sum'] += round($payform['sum'], 2);
                    if ($payform['code'] == 0) {
                        $report["cash_in_box"] += round($payform['sum'], 2);
                    }
                }
            }

            if ($doctype == Client::METHOD_RETURN) {
                $payments = Document::getPayments($doc);
                $taxes = Document::getTaxes($doc);

                $report['ret']['orders_count']++;

                foreach ($taxes as $tax_key => $tax) {
                    if ($tax['excise_prc']) {
                        $report['ret']['tax']['excise'][$tax['excise_prc']]['excise'] += round($tax['excise'], 2);
                        $report['ret']['tax']['excise'][$tax['excise_prc']]['excise_prc'] = $tax['excise_prc'];
                        $report['ret']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['excise'] += round($tax['excise'], 2);
                        $report['ret']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['excise_prc'] = $tax['excise_prc'];
                        $report['ret']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['tax_turnover'] += round($tax['turnover'], 2);
                        $report['ret']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['tax_sum'] += round($tax['sum'], 2); 
                    }

                    $report['ret']['tax'][$tax['prc']]['turnover'] += round($tax['turnover'], 2);
                    $report['ret']['tax'][$tax['prc']]['sum'] += round($tax['sum'], 2);                 
                }
                
                foreach ($payments as $payform) {                    
                    $report['ret']['pay_form'][$payform['code']]['round_up'] += round(abs($payform['round_up']), 2);
                    $report['ret']['pay_form'][$payform['code']]['round_down'] += round(abs($payform['round_down']), 2);
                    $report['ret']['pay_form'][$payform['code']]['sum'] += round($payform['sum'], 2);
                    $report['ret']['sum'] += round($payform['sum'], 2);
                    if ($payform['code'] == 0) {
                        $report["cash_in_box"] -= round($payform['sum'], 2);
                    }
                }
            }

            if ($doctype == Client::METHOD_SERVICE_INPUT) {
                $sum = (float) json_decode(base64_decode($doc->request), true)['sum'];                
                $report["service_input"] += round($sum, 2);
                $report["cash_in_box"] += round($sum, 2);
            }

            if ($doctype == Client::METHOD_SERVICE_OUTPUT) {
                $sum = (float) json_decode(base64_decode($doc->request), true)['sum'];
                $report["service_output"] += round($sum, 2);
                $report["cash_in_box"] -= round($sum, 2);
            }
        }

        return $report;
    }

    public function getBalance(): float
    {
        $balance = 0;
        if (RRO::getInstance()->isShiftOpened() == 1) {
            $report = $this->getReport2(RRO::getInstance()->getId(), RRO::getInstance()->getCurrentShiftNumber());
            $balance = $report['cash_in_box'];
        } else {
            $balance = RRO::getInstance()->getLastShiftBalance();
        }

        return $balance;
    }

    public function getReport(int $rro = 0, int $shift = 0): array
    {
        $payforms = [0, 1, 2, 3];

        $taxes = [
            0 => [
                "name" => "ПДВ А 20%",
                "letter" => "А",
                "prc" => 20,
            ],
            1 => [
                "name" => "ПДВ 7%",
                "letter" => "Б",
                "prc" => 7,
            ],
            2 => [
                "name" => "БЕЗ ПДВ",
                "letter" => "В",
                "prc" => 0,
            ],
            3 => [
                "name" => "Звільнений від оподаткування",
                "letter" => "-Н",
                "prc" => 0,
            ],
        ];

        $shift_number = ($shift > 0) ? $shift : RRO::getInstance()->getCurrentShiftNumber();
        $rro_id = ($rro > 0) ? $rro : RRO::getInstance()->getId();
        $open_balance = ($shift > 0) ? RRO::getInstance()->getShiftBalance($shift) : RRO::getInstance()->getLastShiftBalance();

        $Document = new ModelDocument();
        $docs = $Document->getall([
            "where" => "`shift` = ".$shift_number." and (action_type = '".Client::METHOD_SALE."' or action_type = '".Client::METHOD_RETURN."' or action_type = '".Client::METHOD_SERVICE_INPUT."' or action_type = '".Client::METHOD_SERVICE_OUTPUT."') and rro = ".$rro_id,
            "order" => "id"
        ]);

        $report = [
            "cash_in_box" => round($open_balance, 2),
            "real" => [
                "sum" => 0,
                "orders_count" => 0,
                "pay_form" => [
                    0 => [
                        "pay_form_code" => "0",
                        "pay_form_name" => "ГОТIВКА",
                        "sum" => 0,
                        "round_up" => 0,
                        "round_down" => 0,
                    ],
                    1 => [
                        "pay_form_code" => "1",
                        "pay_form_name" => "БЕЗГОТІВКА.1",
                        "sum" => 0
                    ],
                    2 => [
                        "pay_form_code" => "2",
                        "pay_form_name" => "БЕЗГОТІВКА.2",
                        "sum" => 0
                    ],
                    3 => [
                        "pay_form_code" => "3",
                        "pay_form_name" => "БЕЗГОТІВКА.3",
                        "sum" => 0
                    ]
                ],
                "tax" => [
                    20 => [
                        "name" => "ПДВ 20%",
                        "letter" => "А",
                        "prc" => 20,
                        "turnover" => 0,
                        "sum" => 0,
                        "excise" => [

                        ],
                    ],
                    7 => [
                        "name" => "ПДВ 7%",
                        "letter" => "Б",
                        "prc" => 7,
                        "turnover" => 0,
                        "sum" => 0,
                        "excise" => [

                        ],
                    ],
                    0 => [
                        "name" => "ПДВ 0%",
                        "letter" => "В",
                        "prc" => 0,
                        "turnover" => 0,
                        "sum" => 0,
                        "excise" => [

                        ],
                    ],
                    'excise' => [

                    ],
                ],                
            ],
            "ret" => [
                "sum" => 0,
                "orders_count" => 0,
                "pay_form" => [
                    0 => [
                        "pay_form_code" => "0",
                        "pay_form_name" => "ГОТIВКА",
                        "sum" => 0,
                        "round_up" => 0,
                        "round_down" => 0,
                    ],
                    1 => [
                        "pay_form_code" => "1",
                        "pay_form_name" => "БЕЗГОТІВКА.1",
                        "sum" => 0
                    ],
                    2 => [
                        "pay_form_code" => "2",
                        "pay_form_name" => "БЕЗГОТІВКА.2",
                        "sum" => 0
                    ],
                    3 => [
                        "pay_form_code" => "3",
                        "pay_form_name" => "БЕЗГОТІВКА.3",
                        "sum" => 0
                    ]
                ],
                "tax" => [
                    20 => [
                        "name" => "ПДВ 20%",
                        "letter" => "А",
                        "prc" => 20,
                        "turnover" => 0,
                        "sum" => 0,
                        "excise" => [

                        ],
                    ],
                    7 => [
                        "name" => "ПДВ 7%",
                        "letter" => "Б",
                        "prc" => 7,
                        "turnover" => 0,
                        "sum" => 0,
                        "excise" => [

                        ],
                    ],
                    0 => [
                        "name" => "ПДВ 0%",
                        "letter" => "В",
                        "prc" => 0,
                        "turnover" => 0,
                        "sum" => 0,
                        "excise" => [

                        ],
                    ],
                    'excise' => [

                    ],
                ],                
            ],
            "service_input" => 0,
            "service_output" => 0,
            "cash_in_box_start" => round($open_balance, 2),
        ];
  
        foreach ($docs as $doc) {
            $doctype = $doc->action_type;
            //$doc = json_decode(base64_decode($doc->request), true);

            if ($doctype == Client::METHOD_SALE) {                
                $payments = Document::getPayments($doc);
                $taxes = Document::getTaxes($doc);

                if ($_GET['test']) {
                    $sum = $sum2 = 0;
                    foreach ($payments as $k => $v) {
                        $sum += $v['sum'];
                    }   

                    foreach ($taxes as $k => $v) {
                        $sum2 += $v['turnover'];
                    }
                    echo $sum." --- ".$sum2."\n\n";
                    if ($sum != $sum2) {
                        print_r($payments);
                        print_r($taxes); 
                        print_r($doc);   
                    }
                    
                }

                $report['real']['orders_count']++;

                foreach ($taxes as $tax_key => $tax) {
                    if ($tax['excise_prc']) {
                        $report['real']['tax']['excise'][$tax['excise_prc']]['excise'] += round($tax['excise'], 2);
                        $report['real']['tax']['excise'][$tax['excise_prc']]['excise_prc'] = $tax['excise_prc'];
                        $report['real']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['excise'] += round($tax['excise'], 2);
                        $report['real']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['excise_prc'] = $tax['excise_prc'];
                        $report['real']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['tax_turnover'] += round($tax['turnover'], 2);
                        $report['real']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['tax_sum'] += round($tax['sum'], 2); 
                    }

                    $report['real']['tax'][$tax['prc']]['turnover'] += round($tax['turnover'], 2);
                    $report['real']['tax'][$tax['prc']]['sum'] += round($tax['sum'], 2);                 
                }
                
                foreach ($payments as $payform) {                    
                    $report['real']['pay_form'][$payform['code']]['round_up'] += round(abs($payform['round_up']), 2);
                    $report['real']['pay_form'][$payform['code']]['round_down'] += round(abs($payform['round_down']), 2);
                    $report['real']['pay_form'][$payform['code']]['sum'] += round($payform['sum'], 2);
                    $report['real']['sum'] += round($payform['sum'], 2);
                    if ($payform['code'] == 0) {
                        $report["cash_in_box"] += round($payform['sum'], 2);
                    }
                }
            }

            if ($doctype == Client::METHOD_RETURN) {
                $payments = Document::getPayments($doc);
                $taxes = Document::getTaxes($doc);

                $report['ret']['orders_count']++;

                foreach ($taxes as $tax_key => $tax) {
                    if ($tax['excise_prc']) {
                        $report['ret']['tax']['excise'][$tax['excise_prc']]['excise'] += round($tax['excise'], 2);
                        $report['ret']['tax']['excise'][$tax['excise_prc']]['excise_prc'] = $tax['excise_prc'];
                        $report['ret']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['excise'] += round($tax['excise'], 2);
                        $report['ret']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['excise_prc'] = $tax['excise_prc'];
                        $report['ret']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['tax_turnover'] += round($tax['turnover'], 2);
                        $report['ret']['tax'][$tax['prc']]['excise'][$tax['excise_prc']]['tax_sum'] += round($tax['sum'], 2); 
                    }

                    $report['ret']['tax'][$tax['prc']]['turnover'] += round($tax['turnover'], 2);
                    $report['ret']['tax'][$tax['prc']]['sum'] += round($tax['sum'], 2);                 
                }
                
                foreach ($payments as $payform) {                    
                    $report['ret']['pay_form'][$payform['code']]['round_up'] += round(abs($payform['round_up']), 2);
                    $report['ret']['pay_form'][$payform['code']]['round_down'] += round(abs($payform['round_down']), 2);
                    $report['ret']['pay_form'][$payform['code']]['sum'] += round($payform['sum'], 2);
                    $report['ret']['sum'] += round($payform['sum'], 2);
                    if ($payform['code'] == 0) {
                        $report["cash_in_box"] -= round($payform['sum'], 2);
                    }
                }
            }

            if ($doctype == Client::METHOD_SERVICE_INPUT) {
                $sum = round((float) json_decode(base64_decode($doc->request), true)['sum'], 2);                
                $report["service_input"] += round($sum, 2);
                $report["cash_in_box"] += round($sum, 2);
            }

            if ($doctype == Client::METHOD_SERVICE_OUTPUT) {
                $sum = round((float) json_decode(base64_decode($doc->request), true)['sum'], 2);
                $report["service_output"] += round($sum, 2);
                $report["cash_in_box"] -= round($sum, 2);
            }
        }

        if ($report["cash_in_box"] < 0.01) {
            $report["cash_in_box"] = 0;
        }

        $report["cash_in_box"] = round($report["cash_in_box"], 2);
        
        return $report;
    }
    
    public function checkFn(int $rro = 0, int $shift = 0, bool $only_sent = false, bool $admin = false): void
    {
        $shift_number = ($shift > 0) ? $shift : RRO::getInstance()->getCurrentShiftNumber();        
        $rro_id = ($rro > 0) ? $rro : RRO::getInstance()->getId();                     
        $Document = new ModelDocument();
        
        $docs = $Document->getall([
            "where" => "`shift` = ".$shift_number." and (action_type = '".Client::METHOD_SALE."' or action_type = '".Client::METHOD_RETURN."' or action_type = '".Client::METHOD_SERVICE_INPUT."' or action_type = '".Client::METHOD_SERVICE_OUTPUT."') and rro = ".$rro_id." and is_deleted = 0",
            "order" => "id"
        ]);

        foreach ($docs as $k => $doc) {
            if ($doc->fiscal_number == '') {
                $fn = Client::checkFn(RRO::getInstance()->getToken(), $doc->local_local_number);
                if ($fn) {
                    $Document->save([
                        "fiscal_number" => $fn,
                    ], $doc->id);
                }                
            }
        }
    }

    public static function getInstance(): Shift
    {
        if (static::$instance === null) {
            static::$instance = new static();
        }

        return static::$instance;
    }
  
	private function __construct()
    {
    }

    private function __clone()
    {
    }
    
    public function __wakeup()
    {
        throw new \Exception("Cannot unserialize singleton Shift");
    }
}