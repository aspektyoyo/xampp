<?php
namespace ASweb\Auth;
	
use ASweb\Db\Db;
use ASweb\MVC\Model\ModelInterface;

class AuthAdmin
{
	private $Storage;
	static $_secret = 0;

	public function __construct(ModelInterface $Storage)
	{
		$this->Storage = $Storage;
	}
				
	public static function is_auth(): bool
	{
		if ($_SESSION['adminid'] && $_SESSION['adminsecret'] == static::$_secret) {
			return true;
		} else {
			return false;	
		}
	}
			
	public static function is_admin(): bool
	{
		return (defined("ASWEB_ADMIN")) ? true : false;
	}

	public function authfromcookie()
	{
		$userid = (int) $_COOKIE['adminid'];
		$secret = (int) $_COOKIE['adminsecret'];

		if ($this->Storage) {
			$user = $this->Storage->getone(['where' => "`id` = '".$userid."' and `secret` = '".Db::nq($secret)."'"]);
		}

		if ($user->id) {
			$_SESSION['adminid'] = $user->id;
			$_SESSION['adminname'] = $user->name;
			$_SESSION['admintype'] = $user->name;
			$_SESSION['admingroup'] = $user->usergroup;
			$_SESSION['adminlevel'] = ($user->level) ? $user->level : 0;
			static::$_secret = $_SESSION['adminsecret'] = ($user->secret) ? $user->secret : 0;
			
			setcookie("adminid", $user->id, time()+60*60*24*3000);
			setcookie("adminname", $user->name, time()+60*60*24*3000);
			setcookie("adminlevel", $user->level, time()+60*60*24*3000);
			setcookie("adminsecret", $user->secret, time()+60*60*24*3000);
			setcookie("admintype", $user->type, time()+60*60*24*3000);
			setcookie("admingroup", $user->usergroup, time()+60*60*24*3000);
			
			return true;
		} else {
			return false;
		}
	}	
		
	public static function mkpass()
	{
		return md5(time());
	}

	public function auth (string $login = '', string $pass = ''): bool
	{		
		// Проверить, если ли пользователь в базе, Если нет, то зарегистрировать его, если есть, то получить данные о нем.
		if ($this->Storage) {
			$user = $this->Storage->getone(array("where" => "`login` = '".Db::nq($login)."' and `pass` = '".Db::nq($pass)."'"));
		}
			
		if ($user->id) { // Пользователь получен
			$_SESSION['adminid'] = $user->id;
			$_SESSION['adminname'] = $user->name;
			$_SESSION['adminlevel'] = ($user->level) ? $user->level : 0;
			$_SESSION['admintype'] = $user->name;
			$_SESSION['admingroup'] = $user->usergroup;
			static::$_secret = $_SESSION['adminsecret'] = ($user->secret) ? $user->secret : 0;
			
			setcookie("adminid", $user->id, time()+60*60*24*3000);
			setcookie("adminname", $user->name, time()+60*60*24*3000);
			setcookie("adminlevel", $user->level, time()+60*60*24*3000);
			setcookie("adminsecret", $user->secret, time()+60*60*24*3000);
			return true;
		} else {
			return false;
		}			
	}
		
	public static function logoff()
	{
		unset($_SESSION['adminid']);
		unset($_SESSION['adminname']);
		unset($_SESSION['adminlevel']);
		unset($_SESSION['adminsecret']);
		unset($_SESSION['admingroup']);
		unset($_SESSION['admintype']);
		self::$_secret = 0;

		setcookie("adminid", null, -1, "/");
		setcookie("adminname", null, -1, "/");
		setcookie("adminlevel", null, -1, "/");
		setcookie("adminsecret", null, -1, "/");
		setcookie("admintype", null, -1, "/");
		setcookie("admingroup", null, -1, "/");
	}
		
	public static function userid(): int
	{
		return isset($_SESSION['adminid']) ? intval($_SESSION['adminid']) : 0;
	}
		
	public static function username(): string
	{
		return isset($_SESSION['adminname']) ? $_SESSION['adminname'] : '';
	}
		
	public static function userlevel(): int
	{
		return isset($_SESSION['adminlevel']) ? $_SESSION['adminlevel'] : 0;
	}
		
	public static function usersecret(): int
	{
		return isset($_SESSION['adminsecret']) ? intval($_SESSION['adminsecret']) : 0;
	}

	public static function usertype(): string
	{
		return isset($_SESSION['admintype']) ? $_SESSION['admintype'] : '';
	}

	public static function usergroup(): int
	{
		return isset($_SESSION['admingroup']) ? $_SESSION['admingroup'] : 0;
	}
}