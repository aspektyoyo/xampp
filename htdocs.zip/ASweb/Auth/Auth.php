<?php

namespace ASweb\Auth;
	
use Model\Rro;
use Model\User;
use ASweb\Db\Db;
use Model\Shift;
use Model\OfflineSession;
use ASweb\RRO\Server\Rro as ServerRro;
use ASweb\RRO\Server\Shift as ServerShift;
use ASweb\RRO\Server\OfflineSession as ServerOfflineSession;

class Auth
{
	public $Rro;
	public $Shift;
	public $OfflineSession;

	private static $_token;

	private static $instance;

    public static function getInstance(): Auth
    {
        if (static::$instance === null) {
            static::$instance = new static();
        }

        return static::$instance;
    }
					
	public static function setToken($token)
	{
		static::$_token = $token;
	}

	public static function token()
	{
		return static::$_token;
	}

	public function authByToken (string $token): bool
	{			
		$User = new User();
		$Rro = new Rro();
		$Shift = new Shift();
		$OfflineSession = new OfflineSession();

		$user = $User->getone(["where" => "`token` = '".$token."'"]);
		if ($user) {
			$rro = $Rro->getone(["where" => "`user` = ".$user->id]);
			$shift = $Shift->getone(["where" => "`rro` = ".$rro->id, "order" => "id desc"]);
			$OfflineSession = $OfflineSession->getone(["where" => "`rro` = ".$rro->id, "order" => "id desc"]);
			return true;
		} else {
			return false;
		}
	}
			
	private function __construct()
    {
		
    }

    private function __clone()
    {
    }
    
    public function __wakeup()
    {
        throw new \Exception("Cannot unserialize singleton Auth");
    }

}