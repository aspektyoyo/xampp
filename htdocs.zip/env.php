<?php

class Env
{
	const DOCKER = 'docker';
	const LOCAL = 'local';
	const SERVER = 'server';

    // Database
    private static $db_driver  = ["docker" => "mysqli", "local" => "mysqli", "server" => "mysqli"];
    private static $db_server  = ["docker" => "127.0.0.1", "local" => "localhost", "server" => "localhost"];
    private static $db_login   = ["docker" => "root", "local" => "root", "server" => "root"];
    private static $db_pass	   = ["docker" => "root", "local" => "", "server" => ""];
    private static $db_base	   = ["docker" => "rro", "local" => "rro", "server" => "rro"];
    private static $db_prefix  = ["docker" => "", "local" => "", "server" => ""];
    private static $signBA     = 'https://euss.sengine.com.ua/public/api/v1';
    private static $fso_url    = ["docker" => 'cabinet.tax.gov.ua:9443', "local" => 'cabinet.tax.gov.ua:9443', "server" => 'cabinet.tax.gov.ua:9443'];
	private static $test 	   = 1;
	private static $server_url = "https://e-cash.e-dorado.com.ua";

    public static function site() {
		if ($_SERVER['SERVER_PORT'] == "8080" || $_SERVER['SERVER_PORT'] == "8081") {
			return self::DOCKER;
		} elseif(self::is_local()) {
			return self::LOCAL;
		} else {
			return self::SERVER;
		}
	}
	
	public static function is_test() {
		return (self::$test || $_GET['test'] == 1) ? true : false;
	}
	
	public static function is_local() {
		return (empty($_SERVER['SERVER_ADDR']) || $_SERVER['SERVER_ADDR'] == '127.0.0.1' || $_SERVER['SERVER_NAME'] == 'localhost' || isset($_GET['local'])) ? true : false;
	}

	public static function db_driver()
	{
		return (!empty(static::$db_driver[static::site()])) ? static::$db_driver[static::site()] : null;
	}
	
	public static function db_server()
	{
		return (!empty(static::$db_server[static::site()])) ? static::$db_server[static::site()] : null;
	}
	
	public static function db_login()
	{
		return (!empty(static::$db_login[static::site()])) ? static::$db_login[static::site()] : null;
	}
	
	public static function db_pass()
	{
		return (!empty(static::$db_pass[static::site()])) ? static::$db_pass[static::site()] : null;
	}
	
	public static function db_base()
	{
		return (!empty(static::$db_base[static::site()])) ? static::$db_base[static::site()] : null;
	}
	
	public static function db_prefix()
	{
		return (!empty(static::$db_prefix[static::site()])) ? static::$db_prefix[static::site()] : null;
	}

	public static function fso_url()
	{
		return (!empty(static::$fso_url[static::site()])) ? static::$fso_url[static::site()] : null;
	}

	public static function path()
	{
		return rtrim($_SERVER['DOCUMENT_ROOT'], "/");
	}

    public static function signBaseAddress()
    {
        return static::$signBA;
    }

	public static function server_url()
	{
		return static::$server_url;
	}
}
