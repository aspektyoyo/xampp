<?php

use Model\Document;

require ('app/init/path.php');
require ('env.php');
require ('init/autoload.php');
require ('init/system-scripts.php');
require ("init/debug.php");
require_once ("init/db.php");

$MDocument = new Document();
$MDocument->update(['sync' => 2], ['where' => 'sync = 0']);

echo "Done";