<?php
use ASweb\MVC\App;
use ASweb\HTTP\Request;
use ASweb\Db\DBException;

try {
	if (version_compare(phpversion(), '7.1', '>=')) {
		ini_set( 'serialize_precision', 14 );
	}

	date_default_timezone_set('Europe/Kiev');

	$config = [];
	require ('app/init/path.php');
	require ('env.php');
	require ('init/autoload.php');
	require ('init/system-scripts.php');
	require ("init/debug.php");	
	$request = Request::getInstance();

    error_reporting(0);
	if (in_array(strtolower($request->controller()), $system_scripts)) {
		require ("app/scripts/".strtolower($request->controller()).".php");
		exit();
	}

	require ("init.php");
	
	$app = App::getInstance($config);
	$response = $app->run($request);
	$response->show();
	exit();
} catch(DBException $e) {
	echo "<font color=red>DBException!</font><br />";
	echo $e->getMessage()."<br />";
	echo "in file: ".$e->getFile()."<br />";
	echo "at line: ".$e->getLine()."<br />";
	echo "Trace: <br />";
	$trace = $e->getTrace(); 
	foreach ($trace as $k => $v) {
		echo "<font color=\"green\">".$k." -> </font>";
		foreach ($v as $kk => $vv) {
			echo $kk." -> ";
			if (is_array($vv)) {
				print_r($vv);
			} else {
				echo $vv;
			}
			echo "<br />";
		}
		echo "<br />";
	}
	echo "<br />";
} catch(Exception $e) {
	echo "<font color=red>Exception!</font><br />";
	echo $e->getMessage()."<br />";
	echo "in file: ".$e->getFile()."<br />";
	echo "at line: ".$e->getLine()."<br />";
	echo "<br />";
	echo "Trace: <br />";
	$trace = $e->getTrace(); 
	foreach ($trace as $k => $v) {
		echo "<font color=\"green\">".$k." -> </font>";
		foreach ($v as $kk => $vv) {
			echo $kk." -> ";
			if (is_array($vv)) {
				print_r($vv);
			} else {
				echo $vv;
			}
			echo "<br />";
		}
		echo "<br />";
	}
	echo "<br />";
} catch(Error $e) {
	echo "<font color=red>Fatal Error!</font><br />";
	echo $e->getMessage()."<br />";
	echo "in file: ".$e->getFile()."<br />";
	echo "at line: ".$e->getLine()."<br />";
	echo "<br />";
	echo "Trace: <br />";
	$trace = $e->getTrace(); 
	foreach ($trace as $k => $v) {
		echo "<font color=\"green\">".$k." -> </font>";
		foreach ($v as $kk => $vv) {
			echo $kk." -> ";
			if (is_array($vv)) {
				print_r($vv);
			} else {
				echo $vv;
			}
			echo "<br />";
		}
		echo "<br />";
	}
	echo "<br />";
}