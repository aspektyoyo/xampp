<?php

require ('app/init/path.php');
require ('env.php');
require ('init/autoload.php');
require ('init/system-scripts.php');
require ("init/debug.php");

function repairDB() {
    $ok = 0;
    $servername = Env::db_server();
    $username = Env::db_login();
    $password = Env::db_pass();
     
    // Create connection
    $conn = new mysqli($servername, $username, $password);
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
   
    $conn->query("USE rro");
    // Repair tables
    $tables = ['apteka', 'document', 'user', 'rro', 'offline_id', 'shift', 'answer'];
    $conn->query("REPAIR TABLE ".implode(",", $tables));

    return $ok;
}

if ($_POST['submit']) {
    repairDB();
    echo "<h2>БД восстановлена</h2>";
    die();
} else {?>
<div style="margin: 20px auto;">
<h2>Восстановление БД</h2>
<br>
Нажмите Восстановить. Данные не будут при этом утеряны
<br><br>
<form action="/repair.php" method="post" enctype="multipart/form-data">
	<input type="submit" name="submit" value="Восстановить" />
</form>

<?php
}