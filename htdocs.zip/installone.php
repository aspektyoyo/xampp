<?php

use ASweb\RRO\Client\Client;
use Model\Apteka;
use Model\Document;
use Model\OfflineNumber;
use Model\Rro;
use Model\Shift;
use Model\User;

require ('app/init/path.php');
require ('env.php');
require ('init/autoload.php');
require ('init/system-scripts.php');
require ("init/debug.php");

function syncDb()
{
  require_once ("init/db.php");

  $ok = true;
  $fn = $_POST['fn'];

  $url = Env::server_url()."/api/sync/installone?token=apteka911servicetoken&fn=".$fn;
  $curl = curl_init();
  curl_setopt($curl, CURLOPT_FAILONERROR, true);
  curl_setopt($curl, CURLOPT_MAXCONNECTS, 1);
  curl_setopt($curl, CURLOPT_MAXREDIRS, 10);
  curl_setopt($curl, CURLOPT_TIMEOUT, 10);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
  curl_setopt($curl, CURLOPT_URL, $url);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
  $result = curl_exec($curl);
  $info = curl_getinfo($curl);
  curl_close($curl);

  if ($info['http_code'] == 200) {
    $MRRO = new Rro();
    $MShift = new Shift();
    $MDocument = new Document();
    $MOfflineIds = new OfflineNumber();
    $MUser = new User();

    $result = json_decode($result, true);

    if(!$result) {
      return false;
    }
    
    foreach ($result['users'] as $user) {
      $MUser->delete(["where" => "id = ".$user['id']]);
      $MUser->insert($user);
    }

    foreach ($result['rro'] as $rro) {
      $rro['timer_updated'] = time();
      $MRRO->delete(["where" => "id = ".$rro['id']]);
      $MShift->delete(["where" => "rro = ".$rro['id']]);
      $MDocument->delete(["where" => "rro = ".$rro['id']]);
      $MOfflineIds->delete(["where" => "rro = ".$rro['id']]);
      
      $MRRO->insert($rro);
    }

    foreach ($result['shifts'] as $shift) {      
      $MShift->insert($shift);
    }

    foreach ($result['documents'] as $document) {
      $rro['sync'] = 1;
      $MDocument->insert($document);
    }

    foreach ($result['offlineids'] as $id) {
      $MOfflineIds->insert($id);
    }
  } else {
    $ok = false;
  }

  return $ok;
}

if ($_POST['submit']) {
  $installed = false;

  echo "Синхронизация базы данных...";

  if (syncDB()) {
    echo "<font color=\"green\">OK</font>";
  } else {
    echo "<font color=\"red\">ERROR</font>";
  }  
} else {?>
<div style="margin: 20px auto;">
<h2>Добавить Фискальный регистратор</h2>
<br>
Введите фискальный номер и нажмите кнопку "Установить"
<br><br>
<form action="/installone.php" method="post" enctype="multipart/form-data">
	<input type="hidden" name="install" value="1" />
	ФН <input type="text" name="fn" value="" />
	<input type="submit" name="submit" value="Установить" />
</form>
</div>
<?php
}